import React, { useEffect, useRef, useState } from "react";
import StatesContext from "./StatesContext";
import { io } from "socket.io-client";
import { ChatBubbleLeftIcon, HomeIcon } from "@heroicons/react/24/solid";
import { BiSolidDashboard } from "react-icons/bi";
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import InsertPhotoIcon from '@mui/icons-material/InsertPhoto';

import contact from '../assets/paymentwhite.png'
import history from '../assets/history.png'
import settings from '../assets/settings.png'
import wallet from '../assets/wallet.png'
import market from '../assets/market.png'


const OverAllStates = (props) => {

    let x = localStorage.getItem('darkMode');
    x = x === null ? true : x === 'true';

    const [walletConnected, setwalletConnected] = useState(false)
    const [contactOpen, setcontactOpen] = useState(false)
    const [isDarkMode, setisDarkMode] = useState(x);
    const [userData, setuserData] = useState('')
    const [NotificationOpen, setNotificationOpen] = useState(false)
    const [fvrtUpdated, setfvrtUpdated] = useState(false)
    const [onlineUsers, setOnlineUsers] = useState([]);
    const [isApprovedFailed, setisApprovedFailed] = useState(false)
    const [usersCount, setusersCount] = useState(0)
    const [allHistory, setallHistory] = useState('')
    const [chatHistoryOpen, setchatHistoryOpen] = useState(false)
    const [createServiceOpen, setcreateServiceOpen] = useState(false)
    const [connectAction, setconnectAction] = useState('')
    const [notConntedOpen, setnotConntedOpen] = useState(false)
    const [error, seterror] = useState('')
    const [success, setsuccess] = useState('')
    const [search, setsearch] = useState('')

    const defaultData = [
        {
            img: market,
            title: 'Market-place',
            route: '/'

        },
        {
            icon: <BiSolidDashboard
                className='text-white text-[23px] lg:text-[29px] xl:text-[33px] 2xl:text-[38px]'
            />,
            title: 'Dashboard',
            route: '/dashboard'
        },
        {
            img: contact,
            title: 'Crypto Payment'
        },

        {
            icon: <HomeIcon
                className='text-white h-[23px] lg:h-[29px] xl:h-[33px] 2xl:h-[38px]'
            />,
            title: 'Home',
            route: '/home'
        },
        {
            icon: <ChatBubbleLeftIcon
                className={`h-[23px] lg:h-[29px] xl:h-[33px] 2xl:h-[38px] ${chatHistoryOpen ? 'text-[#0C8CE9]' : 'text-white'}`}
            />,
            title: 'Chat'
        },
        {
            img: wallet,
            title: 'Wallets',
            route: '/wallets'

        },
        {
            img: history,
            title: 'History',
            route: '/history'
        },
        {
            img: settings,
            title: 'Settings',
            route: '/settings'

        },
    ]

    const [data, setdata] = useState(defaultData)

    //Notifications
    const [notifications, setnotifications] = useState('')
    const [frinendList, setfrinendList] = useState('')
    const [notificationOpenStates, setNotificationOpenStates] = useState();
    const [notificationQuery, setnotificationQuery] = useState('')
    const [isComponentOpen, setisComponentOpen] = useState(false)
    const [isApproved, setisApproved] = useState('')

    // ContactStates
    const [allFriends, setallFriends] = useState()
    const [filteredFriends, setfilteredFriends] = useState('')
    const [lastMessage, setlastMessage] = useState('')
    const [allConversations, setallConversations] = useState('')
    const [chatOpen, setchatOpen] = useState(false)
    const [isComingFromChat, setisComingFromChat] = useState(false)


    // Dashboard
    const [unreadMessages, setunreadMessages] = useState(0)
    const [paymentApprovals, setpaymentApprovals] = useState(0)
    const [announcements, setannouncements] = useState(0)

    useEffect(() => {

        if (isDarkMode) {
            localStorage.setItem('darkMode', 'true')
        } else {
            localStorage.setItem('darkMode', 'false')
        }

    }, [isDarkMode])


    const socketRef = useRef(null);

    const backend_url = import.meta.env.VITE_API_IS_DEVELOPMENT === 'true' ? 'ws://localhost:4000' : 'wss://backend.paycat.app'

    useEffect(() => {
        socketRef.current = io(`${backend_url}`);

        return () => {
            if (socketRef.current) {
                socketRef.current.disconnect();
                socketRef.current = null;
            }
        };
    }, []);


    useEffect(() => {
        if (userData && userData.isAdmin) {
            setdata((prev) => {
                // Check if the "Admin Orders" entry is already in the state.
                const isAdminOrdersEntryExists = prev.some(
                    (item) => item.route === '/admin/orders'
                );

                if (!isAdminOrdersEntryExists) {
                    // Add the "Admin Orders" entry only if it doesn't exist.
                    return [
                        {
                            icon: (
                                <AdminPanelSettingsIcon className='text-white h-[23px] lg:h-[29px] xl:h-[33px] 2xl:h-[38px]' />
                            ),
                            title: 'Admin Orders',
                            route: '/admin/orders',
                        },
                        {
                            icon: (
                                <InsertPhotoIcon className='text-white h-[23px] lg:h-[29px] xl:h-[33px] 2xl:h-[38px]' />
                            ),
                            title: 'Home Sliders',
                            route: '/admin/sliders',
                        },
                        ...prev,
                    ];
                } else {
                    // If it already exists, return the previous state.
                    return prev;
                }
            });
        }
    }, [userData]);

    const resetState = () => {
        setNotificationOpen(false);
        setnotifications('');
        setfrinendList('');
        setNotificationOpenStates('');
        setnotificationQuery('');
        setallFriends('');
        setfilteredFriends('');
        setunreadMessages(0);
        setpaymentApprovals(0);
        setannouncements(0);
        setwalletConnected(false)
        setcontactOpen(false)
        setuserData('logged out!')
        setfvrtUpdated(true)
        setallConversations('')
        setchatHistoryOpen(false)
        setchatOpen(false)
    };


    return (
        <StatesContext.Provider
            value={{
                walletConnected, setwalletConnected,
                contactOpen, setcontactOpen,
                isDarkMode, setisDarkMode,
                userData, setuserData,
                frinendList, setfrinendList,
                allFriends, setallFriends,
                filteredFriends, setfilteredFriends,
                NotificationOpen, setNotificationOpen,
                fvrtUpdated, setfvrtUpdated,
                onlineUsers, setOnlineUsers,
                socketRef,
                notifications, setnotifications,
                unreadMessages, setunreadMessages,
                paymentApprovals, setpaymentApprovals,
                announcements, setannouncements,
                notificationOpenStates, setNotificationOpenStates,
                notificationQuery, setnotificationQuery,
                resetState,
                isComponentOpen, setisComponentOpen,
                isApproved, setisApproved,
                isApprovedFailed, setisApprovedFailed,
                usersCount, setusersCount,
                allHistory, setallHistory,
                chatHistoryOpen, setchatHistoryOpen,
                createServiceOpen, setcreateServiceOpen,
                connectAction, setconnectAction,
                lastMessage, setlastMessage,
                allConversations, setallConversations,
                notConntedOpen, setnotConntedOpen,
                error, seterror,
                success, setsuccess,
                search, setsearch,
                data,
                chatOpen, setchatOpen,
                isComingFromChat, setisComingFromChat

            }}>
            {props.children}
        </StatesContext.Provider>
    )
}
export default OverAllStates;