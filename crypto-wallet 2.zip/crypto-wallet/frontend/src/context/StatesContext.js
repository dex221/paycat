import { createContext } from "react";
const StatesContext = createContext();
export default StatesContext;