import { configureStore } from '@reduxjs/toolkit'
import { ContactApi } from '../helpers/contactApi';
import { ConversationApi } from '../helpers/conversationApi';
import { NotificationsApi } from '../helpers/notificationApi';
import { ServiceApi } from '../helpers/ServiceApi';
import { UserApi } from '../helpers/userApi';
import { OrdersApi } from '../helpers/OrderApi';
import { HomesliderApi } from '../helpers/homeSliderApi';


const store = configureStore({
    reducer: {
        [ContactApi.reducerPath]: ContactApi.reducer,
        [ConversationApi.reducerPath]: ConversationApi.reducer,
        [NotificationsApi.reducerPath]: NotificationsApi.reducer,
        [ServiceApi.reducerPath]: ServiceApi.reducer,
        [UserApi.reducerPath]: UserApi.reducer,
        [OrdersApi.reducerPath]: OrdersApi.reducer,
        [HomesliderApi.reducerPath]: HomesliderApi.reducer,

    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(ContactApi.middleware).concat(ConversationApi.middleware).concat(NotificationsApi.middleware).concat(ServiceApi.middleware).concat(UserApi.middleware).concat(OrdersApi.middleware).concat(HomesliderApi.middleware)
})

export default store;