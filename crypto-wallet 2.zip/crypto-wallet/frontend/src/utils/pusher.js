import Pusher from 'pusher-js';
import { BACKEND_URL } from '../constants/constants';

const token = sessionStorage.getItem('Token');

export const pusherClient = new Pusher(
  'd46d44d05a93008861a1',
  {
    channelAuthorization: {
      endpoint: `${BACKEND_URL}/api/pusher/auth`,
      transport: 'ajax',
      headers: {
        'Authorization': `Bearer ${token}`
      },
    },
    cluster: 'eu',

  }
);

