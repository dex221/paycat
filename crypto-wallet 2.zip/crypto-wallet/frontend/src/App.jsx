import React, { useContext, useEffect, useState, useRef } from 'react'
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import Conversation from './pages/Conversation'
import StatesContext from './context/StatesContext'
import Settings from './pages/Settings'
import History from './pages/History'
import Wallets from './pages/Wallets'
import { BACKEND_URL } from './constants/constants'
import StartUp from './components/StartUp'
import ProtectedRoute from './routes/ProtectedRoutes'
import { useAccount, useConnect, useDisconnect } from 'wagmi'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';

import { useMediaQuery } from '@mui/material'
import MarketPlace from './pages/MarketPlace'
import ServiceSellerProfile from './pages/ServiceSellerProfile'
import MyServices from './pages/MyServices'
import Orders from './pages/Orders'
import AdminOrders from './pages/admin/AdminOrders'
import PrivateRoute from './routes/PrivateRoute'
import HomeSliders from './pages/admin/HomeSliders'
import WalletsModel from './components/Modals/WalletsModel'

const App = () => {

  const context = useContext(StatesContext)
  const { setwalletConnected, walletConnected, isDarkMode, setuserData, userData, error, seterror, success, setsuccess, setOnlineUsers, socketRef, isApprovedFailed, setisApprovedFailed, resetState, isApproved, setisApproved } = context
  const navigate = useNavigate()
  const smallerthen640 = useMediaQuery('(max-width:640px)')

  const { disconnect } = useDisconnect();



  useEffect(() => {
    checkLoggedUser();
    if (window.ethereum) {

      // Add event listener for account changes
      window.ethereum.on('accountsChanged', handleAccountChange);
    }
    // Remove the event listener when the component unmounts
    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', handleAccountChange);
      }
    };
  }, []);

  const handleAccountChange = () => {
    if (sessionStorage.getItem('Token')) {
      sessionStorage.removeItem('Token');
      disconnect()
      resetState()
      navigate('/')
    }
  }


  const checkLoggedUser = async () => {
    if (sessionStorage.getItem('Token')) {
      try {

        const token = sessionStorage.getItem('Token');

        if (token != '') {
          const response = await fetch(`${BACKEND_URL}/api/me`, {
            method: 'Get',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
          });
          let { success, user } = await response.json();

          if (success && user) {
            setwalletConnected(true)
            setuserData(user)

          } else {
            setuserData('No User Found')
          }
        }
      } catch (err) {
        console.error(err);
      }
    } else {
      setuserData('No User Found')
    }
  };

  useEffect(() => {

    if (userData && userData.walletAddress) {

      //Active Users
      socketRef.current.emit("new-user-add", userData.walletAddress);
      socketRef.current.on("get-users", (users) => {
        setOnlineUsers(users);
      });

      const handleFocus = () => {
        socketRef.current.emit("new-user-add", userData.walletAddress);
      };

      const handleBlur = () => {
        if (userData && userData.walletAddress) {
          socketRef.current.emit("offline");
        }
      };

      window.addEventListener("focus", handleFocus);
      window.addEventListener("blur", handleBlur);

      return () => {
        if (userData && userData.walletAddress) {

          window.removeEventListener("focus", handleFocus);
          window.removeEventListener("blur", handleBlur);
        }
      };
    }
  }, [userData])

  useEffect(() => {
    const handleScroll = (e) => {
      const scrollableHeight = e.target.scrollHeight - e.target.clientHeight;
      if (e.target.scrollTop === scrollableHeight) {
        e.preventDefault();
      }
    };

    document.body.addEventListener('scroll', handleScroll);

    return () => {
      document.body.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {

    if (isApproved) {
      toast.success('Payment transferred successfully!', {
        position: smallerthen640 ? 'top-center' : "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        toastClassName: "rounded-lg",
        className: 'text-[16px] mt-[75px] mx-auto md:mt-0 w-[320px] h-full rounded-md relative z-50',
        style: { borderRadius: '15px' },
      });
      setisApproved(false)
    }

  }, [isApproved])

  useEffect(() => {

    if (error) {
      toast.error(error, {
        position: smallerthen640 ? 'top-center' : "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        toastClassName: "rounded-lg",
        className: 'text-[16px] mt-[75px] mx-auto md:mt-0 w-[320px] h-full rounded-md relative z-50',
        style: { borderRadius: '15px' },
      });
      seterror('')
    }

    if (success) {
      toast.success(success, {
        position: smallerthen640 ? 'top-center' : "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        toastClassName: "rounded-lg",
        className: 'text-[16px] mt-[75px] mx-auto md:mt-0 w-[320px] h-full rounded-md relative z-50',
        style: { borderRadius: '15px' },
      });
      setsuccess('')
    }

  }, [error, success])

  useEffect(() => {

    if (isApprovedFailed) {
      toast.error('Insufficient tokens to proceed!', {
        position: smallerthen640 ? 'top-center' : "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
        toastClassName: "rounded-lg",
        className: 'text-[16px] mt-[75px] mx-auto md:mt-0 w-[320px] h-full rounded-md relative z-50',
        style: { borderRadius: '15px' },
      });
      setisApprovedFailed(false)
    }

  }, [isApprovedFailed])



  if (sessionStorage.getItem('Token')) {
    if (!userData) return <StartUp />
  }

  return (
    <div className={`max-w-[100vw] overflow-hidden transition-all duration-700 ${isDarkMode && 'dark'}`}>

      <ToastContainer />
      <div>

        <Routes>

          <Route path='/' element={<MarketPlace />} />
          <Route path='/home' element={<Home />} />
          <Route path='/user/:id' element={<ServiceSellerProfile />} />

          <Route element={<ProtectedRoute />} >
            <Route path='/dashboard' element={<Dashboard />} />
            <Route path='/conversation/:id' element={<Conversation />} />
            <Route path='/settings' element={<Settings />} />
            <Route path='/history' element={<History />} />
            <Route path='/wallets' element={<Wallets />} />
            <Route path='/services' element={<MyServices />} />
            <Route path='/orders' element={<Orders />} />
          </Route>

          <Route element={<PrivateRoute />} >
            <Route path='/admin/orders' element={<AdminOrders />} />
            <Route path='/admin/sliders' element={<HomeSliders />} />
          </Route>

        </Routes>

      </div>

    </div>
  )
}

export default App