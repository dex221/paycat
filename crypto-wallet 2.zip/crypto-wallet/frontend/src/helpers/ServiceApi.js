import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const ServiceApi = createApi({
    reducerPath: 'Service Api',
    baseQuery,
    tagTypes: ['Service'],
    endpoints: (builder) => ({

        createService: builder.mutation({
            query: ({ images, title, category, paymentCoin, price, country, desc }) => {
                return {
                    url: `/service/create`,
                    method: 'Post',
                    body: { images, title, category, paymentCoin, price, country, desc }
                }
            },
            invalidatesTags: ['Service']
        }),

        getAllServices: builder.query({
            query: ({ page, filters }) => {
                return {
                    url: `/services?category=${filters.categories}&country=${filters.country}&paymentCoin=${filters.coins}&title=${filters.search}&page=${page}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),

        getCoinsPriceUSD: builder.query({
            query: () => {
                return {
                    url: `/tokens/price`,
                    method: 'Get',
                }
            }
        }),

        getAllServicesOfUser: builder.query({
            query: ({ userId, page, resultPerPage = '' }) => {
                return {
                    url: `/service/${userId}?page=${page}&resultPerPage=${resultPerPage}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),
        getSimilarServices: builder.query({
            query: ({ userId, page, serviceId }) => {
                return {
                    url: `/similar-services?userId=${userId}&page=${page}&serviceId=${serviceId}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),

        getSimilarCategory: builder.query({
            query: ({ userId, page, category }) => {
                return {
                    url: `/similar-services/category?userId=${userId}&page=${page}&categories=${category}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),

        deleteService: builder.mutation({
            query: (serviceId) => {
                return {
                    url: `/service/${serviceId}`,
                    method: 'Delete',
                }
            },
            invalidatesTags: ['Service']
        }),

        updateService: builder.mutation({
            query: ({ images, title, category, paymentCoin, price, country, desc, id }) => {
                return {
                    url: `/service/${id}`,
                    method: 'Put',
                    body: { images, title, category, paymentCoin, price, country, desc }
                }
            },
            invalidatesTags: ['Service']
        }),


        createReviews: builder.mutation({
            query: ({ ratedTo, serviceId, rating, comment }) => {
                return {
                    url: `/review/create`,
                    method: 'Post',
                    body: { ratedTo, serviceId, rating, comment }
                }
            },
            invalidatesTags: ['Service']
        }),
        getReviews: builder.query({
            query: ({ serviceId, page }) => {
                return {
                    url: `/reviews?serviceId=${serviceId}&page=${page}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),
        getReviewCheck: builder.query({
            query: ({ bookedBy, serviceId }) => {
                return {
                    url: `/review/check?bookedBy=${bookedBy}&serviceId=${serviceId}`,
                    method: 'Get',
                }
            },
            providesTags: ['Service']
        }),

        createView: builder.mutation({
            query: (serviceId) => {
                return {
                    url: `/view`,
                    method: 'Put',
                    body: { serviceId }
                }
            },
            invalidatesTags: ['Service']
        }),
        createLike: builder.mutation({
            query: (serviceId) => {
                return {
                    url: `/like`,
                    method: 'Put',
                    body: { serviceId }
                }
            },
            invalidatesTags: ['Service']
        }),

        // admin
        deleteServiceAdmin: builder.mutation({
            query: (serviceId) => {
                return {
                    url: `/service/${serviceId}`,
                    method: 'Delete',
                }
            },
            invalidatesTags: ['Service']
        }),

        reviewByUserId: builder.query({
            query: (userId) => {
                return {
                    url: `/review?userId=${userId}`,
                    method: 'Get',
                }
            },
        }),
    })
});

export const {

    useCreateServiceMutation,
    useGetAllServicesQuery,
    useGetCoinsPriceUSDQuery,
    useGetAllServicesOfUserQuery,
    useDeleteServiceMutation,
    useUpdateServiceMutation,
    useGetSimilarServicesQuery,
    useGetSimilarCategoryQuery,

    useCreateReviewsMutation,
    useGetReviewsQuery,
    useGetReviewCheckQuery,
    useCreateViewMutation,
    useCreateLikeMutation,

    //admin
    useDeleteServiceAdminMutation,
    useReviewByUserIdQuery

} = ServiceApi