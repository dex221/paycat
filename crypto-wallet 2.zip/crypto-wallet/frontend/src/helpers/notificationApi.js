import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const NotificationsApi = createApi({
    reducerPath: 'Notification Api',
    baseQuery,
    tagTypes: ['History'],
    endpoints: (builder) => ({

        userNotifications: builder.query({
            query: (id) => {
                return {
                    url: `/notifications/${id}`,
                    method: 'Get',
                }
            },
        }),

        notificationsSeen: builder.mutation({
            query: (id) => {
                return {
                    url: `/notifications/seen/${id}`,
                    method: 'Get',
                }
            },
        }),
        notificationsDelete: builder.mutation({
            query: (createdAt) => {
                return {
                    url: `/notification/delete`,
                    method: 'Delete',
                    body : {createdAt}
                }
            },
        }),

        notificationTypeReadUpdate: builder.mutation({
            query: (id) => {
                return {
                    url: `/notifications/type/read/${id}`,
                    method: 'Get',
                }
            },
        }),
        addPaymentNotifications: builder.mutation({
            query: ({ amount, id, tokenName }) => {
                return {
                    url: `/notifications/payments`,
                    method: 'Post',
                    body: { amount, id, tokenName }
                }
            },
        }),
        updatePaymentNotifications: builder.mutation({
            query: ({ senderId, createdAt, amount , tokenName}) => {
                return {
                    url: `/notifications/payments/update`,
                    method: 'Post',
                    body: { senderId, createdAt, amount , tokenName }
                }
            },
            invalidatesTags: ['History']
        }),
        getHistory: builder.query({
            query: (id) => {
                return {
                    url: `/history/${id}`,
                    method: 'Get',
                }
            },
            providesTags: ['History']
        }),
        getHistoryMonthly: builder.query({
            query: (id) => {
                return {
                    url: `/history/monthly/${id}`,
                    method: 'Get',
                }
            },
            providesTags: ['History']
        }),

        gettotalHistoryGraph: builder.query({
            query: (activeTime) => {
                return {
                    url: `/history?activeTime=${activeTime}`,
                    method: 'Get',
                }
            },
            providesTags: ['History']
        }),

        addScheduleNotification: builder.mutation({
            query: ({ senderId, amount, DeadlinesNo, sheduleDate, tokenName }) => {
                return {
                    url: `/notifications/schedule`,
                    method: 'Post',
                    body: { senderId, amount, DeadlinesNo, sheduleDate, tokenName }
                }
            },
        })

    })
});

export const {

    useUserNotificationsQuery,
    useNotificationsSeenMutation,
    useNotificationTypeReadUpdateMutation,
    useAddPaymentNotificationsMutation,
    useUpdatePaymentNotificationsMutation,
    useGetHistoryQuery,
    useGetHistoryMonthlyQuery,
    useAddScheduleNotificationMutation,
    useNotificationsDeleteMutation,
    useGettotalHistoryGraphQuery

} = NotificationsApi