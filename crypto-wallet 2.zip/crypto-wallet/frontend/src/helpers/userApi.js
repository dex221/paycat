import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const UserApi = createApi({
    reducerPath: 'USer Api',
    baseQuery,
    endpoints: (builder) => ({

        userDeatils: builder.query({
            query: (id) => {
                return {
                    url: `/user/${id}`,
                    method: 'Get',
                }
            },
        }),

  

    })
});

export const {

    useUserDeatilsQuery,


} = UserApi