import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const HomesliderApi = createApi({
    reducerPath: 'Home Slider Api',
    baseQuery,
    tagTypes: ['Slider'],
    endpoints: (builder) => ({

        createSliderImage: builder.mutation({
            query: ({ type, imgUrl }) => {
                return {
                    url: `/slider/create`,
                    method: 'Post',
                    body: { type, imgUrl },
                }
            },
            invalidatesTags: ['Slider']
        }),
        allSliderImages: builder.query({
            query: (type) => {
                return {
                    url: `/sliders?type=${type}`,
                    method: 'Get',
                }
            },
            providesTags: ['Slider']
        }),
        updateSliderImage: builder.mutation({
            query: ({ imgUrl, id }) => {
                return {
                    url: `/slider/${id}`,
                    method: 'Put',
                    body: { imgUrl },
                }
            },
            invalidatesTags: ['Slider']
        }),
        deleteSliderImage: builder.mutation({
            query: (id) => {
                return {
                    url: `/slider/${id}`,
                    method: 'Delete',
                }
            },
            invalidatesTags: ['Slider']
        }),


    })
});

export const {

    useCreateSliderImageMutation,
    useAllSliderImagesQuery,
    useDeleteSliderImageMutation,
    useUpdateSliderImageMutation

} = HomesliderApi