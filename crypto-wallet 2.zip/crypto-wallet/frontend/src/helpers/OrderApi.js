import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const OrdersApi = createApi({
    reducerPath: 'Orders Api',
    baseQuery,
    tagTypes: ['Orders'],
    endpoints: (builder) => ({

        createOrders: builder.mutation({
            query: ({
                country,
                receivedBy,
                serviceId,
                payment,
                email,
                number,
                address,
                paymentCoin,
                title,
                orderId
            }) => {
                return {
                    url: `/orders/create`,
                    method: 'Post',
                    body: {
                        country,
                        receivedBy,
                        serviceId,
                        payment,
                        email,
                        number,
                        address,
                        paymentCoin,
                        title,
                        orderId
                    }
                }
            },
            invalidatesTags: ['Orders']
        }),

        allOrders: builder.query({
            query: ({
                userId,
                serviceType
            }) => {
                return {
                    url: `/orders?serviceType=${serviceType}&userId=${userId}`,
                    method: 'Get',
                }
            },
            providesTags: ['Orders']
        }),

        updateOrderStatus: builder.mutation({
            query: ({
                orderId,
                status
            }) => {
                return {
                    url: `/order/status`,
                    method: 'Put',
                    body: { orderId, status }
                }
            },
            invalidatesTags: ['Orders']
        }),

        //admin

        allOrdersAdmin: builder.query({
            query: () => {
                return {
                    url: `/admin/orders`,
                    method: 'Get',
                }
            },
            providesTags: ['Orders']
        }),
        updateOrderAdmin: builder.mutation({
            query: (orderId) => {
                return {
                    url: `/admin/orders`,
                    method: 'Put',
                    body: {
                        orderId
                    }
                }
            },
            invalidatesTags: ['Orders']
        }),

    })
});

export const {

    useCreateOrdersMutation,
    useAllOrdersQuery,
    useUpdateOrderStatusMutation,

    //admin
    useAllOrdersAdminQuery,
    useUpdateOrderAdminMutation

} = OrdersApi