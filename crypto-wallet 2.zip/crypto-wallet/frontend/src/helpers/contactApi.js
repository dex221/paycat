import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const ContactApi = createApi({
    reducerPath: 'Contact Api',
    baseQuery,
    tagTypes: ['Contact'],
    endpoints: (builder) => ({

        addFriend: builder.mutation({
            query: (walletAddress) => {
                return {
                    url: `/contact/add`,
                    method: 'Post',
                    body: { walletAddress },
                }
            },
            invalidatesTags: ['Contact']
        }),

        allFriends: builder.query({
            query: (id) => {
                return {
                    url: `/friends/${id}`,
                    method: 'Get',
                }
            },
            providesTags: ['Contact']
        }),
        getconversationId: builder.mutation({
            query: (id) => {
                return {
                    url: `/conversation/retrive/${id}`,
                    method: 'Post',
                }
            },
            invalidatesTags: ['Contact']
        }),
        allConversationsHistory: builder.query({
            query: (id) => {
                return {
                    url: `/conversation-history/${id}`,
                    method: 'Get',
                }
            },
        }),

        updateFriendsFvrt: builder.mutation({
            query: ({ updateduserId, updatedIsFavrt }) => {
                return {
                    url: `/friends/fvrt`,
                    method: 'Post',
                    body: { updateduserId, updatedIsFavrt }
                }
            },
        }),

    })
});

export const {

    useAddFriendMutation,
    useAllFriendsQuery,
    useUpdateFriendsFvrtMutation,
    useAllConversationsHistoryQuery,
    useGetconversationIdMutation

} = ContactApi