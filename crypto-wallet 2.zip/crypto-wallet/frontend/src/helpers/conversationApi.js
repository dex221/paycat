import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import { BACKEND_URL } from '../constants/constants'

const baseQuery = fetchBaseQuery({
    baseUrl: `${BACKEND_URL}/api`,
    prepareHeaders: (headers, { getState }) => {
        const token = sessionStorage.getItem('Token');
        if (token) {
            headers.set('Authorization', `Bearer ${token}`);
        }
        return headers;
    },
});

export const ConversationApi = createApi({
    reducerPath: 'Conversation Api',
    baseQuery,
    tagTypes: ['Message'],
    endpoints: (builder) => ({

        allConversation: builder.query({
            query: (id) => {
                return {
                    url: `/conversation/${id}`,
                    method: 'Get',
                }
            },
        }),

        sendMessage: builder.mutation({
            query: ({ id, document = '', message = '', image = '', userId, filename = '' }) => {
                return {
                    url: `/send/message/${id}/${userId}`,
                    method: 'Post',
                    body: { message, image, document, filename }
                }
            },
            invalidatesTags: ['Message']
        }),

        recentDeals: builder.query({
            query: (id) => {
                return {
                    url: `/recent-deals/${id}`,
                    method: 'Get',
                }
            },
            providesTags: ['Message']
        }),



    })
});

export const {

    useAllConversationQuery,
    useSendMessageMutation,
    useRecentDealsQuery,

} = ConversationApi