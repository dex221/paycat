import React, { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import StatesContext from '../context/StatesContext';

const PrivateRoute = () => {
  const context = useContext(StatesContext);
  const { userData } = context;

  if (userData && userData.isAdmin) {
    return <Outlet />;
  } else {
    return <Navigate to="/dashboard" />;
  }
};

export default PrivateRoute;
