import React, { useContext, useEffect, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import { motion } from 'framer-motion';

import StatesContext from '../context/StatesContext'
import Graph from '../components/Graph'
import EditProfile from '../components/EditProfile'
import { useNavigate } from 'react-router-dom';
import ImageWithNestedDivs from '../components/ImageWithNestedDivs';
import { useRecentDealsQuery } from '../helpers/conversationApi';
import { CircularProgress } from '@mui/material';
import { useGetHistoryMonthlyQuery } from '../helpers/notificationApi';

const Dashboard = () => {

    const context = useContext(StatesContext)
    const {
        contactOpen, isDarkMode,
        userData,
        setNotificationOpen,
        notifications, unreadMessages, setunreadMessages,
        paymentApprovals, setpaymentApprovals,
        announcements, setannouncements,
        setnotificationQuery,
        chatHistoryOpen,

    } = context

    const [editProfileOpen, seteditProfileOpen] = useState(false)
    const [showGraph, setshowGraph] = useState(true)
    const [isLargeScreen, setisLargeScreen] = useState(false)
    const [isSmallScreen, setisSmallScreen] = useState(false)

    const { data, isFetching } = useRecentDealsQuery((userData && userData._id) || '')
    const { data: monthHistory, isFetching: historyLoading, refetch } = useGetHistoryMonthlyQuery((userData && userData._id) || '')

    useEffect(() => {

        setshowGraph(false)
        setTimeout(() => {
            setshowGraph(true)
        }, 100);

    }, [contactOpen, chatHistoryOpen])

    useEffect(() => {
        const handleScreenSizeChange = () => {
            setisLargeScreen(window.matchMedia('(min-width: 1450px)').matches);
            setisSmallScreen(window.matchMedia('(min-width: 1100px)').matches);

        };

        // Initial check
        handleScreenSizeChange();

        // Add event listener to update state when the screen size changes
        window.addEventListener('resize', handleScreenSizeChange);

        // Clean up the event listener when the component is unmounted
        return () => {
            window.removeEventListener('resize', handleScreenSizeChange);
        };
    }, []);

    useEffect(() => {
        if (notifications) {

            let unread = 0
            let approval = 0
            let announcements = 0

            notifications.forEach((notification) => {
                switch (notification.type) {
                    case 'Unread':
                        unread++;
                        break;
                    case 'approvals':
                        approval++;
                        break;
                    case 'announcements':
                        announcements++;
                        break;
                    default:
                        break;
                }
            })

            setunreadMessages(unread)
            setpaymentApprovals(approval)
            setannouncements(announcements);
        }

    }, [notifications])

    useEffect(() => {
        refetch()
    }, [])

    let IsOpened = false
    if (chatHistoryOpen) {
        IsOpened = true
    } else if (contactOpen) {
        IsOpened = true
    }

    return (
        <div className=' mt-[100px] md:mt-0 mb-[50px] md:mb-0 max-w-[1540px] mx-auto'>

            <div className=' md:m-[25px] px-[20px] md:px-0'>
                <div className={`grid grid-cols-1 mx-auto lg:w-full  flex-wrap gap-[15px] ${contactOpen ? 'w-full' : 'sm:w-[90%] md:w-[80%] '} ${isSmallScreen && IsOpened && 'lg:grid-cols-2'}  ${isSmallScreen && !IsOpened && 'lg:grid-cols-3'} ${!isLargeScreen && IsOpened ? 'xl:grid-cols-2' : 'xl:grid-cols-3'}`}>
                    <div className='relative py-[20px] 2xl:py-[28px] px-[15px] flex flex-col lg:flex-row items-center gap-[20px] sm:gap-[12px]'
                        style={{
                            border: '1px solid rgba(217, 217, 217, 0.50)',
                            boxShadow: '0px 0px 4px 0px #D9D9D9',
                            background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                        }}
                    >

                        <img src={userData.image} alt="" className='h-[150px] lg:h-[110px] xl:h-[160px]  w-[150px] lg:w-[110px] xl:w-[160px] object-cover rounded-full border border-[#0C8CE9]' />
                        <div>
                            <h2 className='text-[#FFF3F3] text-center lg:text-start font-bold text-[20px] 2xl:text-[24px]'>
                                Welcome back !
                            </h2>
                            <h6 className='text-[16px] text-center lg:text-left 2xl:text-[20px] break-words font-bold text-[#0C8CE9] mt-[5px]'>
                                {userData.name.length > 30 ? `${userData.name.substring(0, 30)}...` : userData.name}
                            </h6>
                            <div className='mt-[20px] sm:mt-[20px] pb-[10px] sm:pb-0'>
                                <button
                                    className='w-[150px] 2xl:w-[170px] h-[29px] 2xl:h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] 2xl:text-[14px] font-bold rounded-[10px] text-white'
                                    onClick={() => seteditProfileOpen(true)}
                                >
                                    Edit my profile
                                </button>
                            </div>
                        </div>

                        {editProfileOpen && (
                            <EditProfile seteditProfileOpen={seteditProfileOpen} />
                        )}

                    </div>
                    <div className='pt-[30px] pb-[20px] sm:pb-[15px] 2xl:pt-[44px] px-[20px] sm:px-[33px] 2xl:px-[38px]'
                        style={{
                            border: '1px solid rgba(217, 217, 217, 0.50)',
                            boxShadow: '0px 0px 4px 0px #D9D9D9',
                            background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                        }}
                    >
                        <h1 className='text-[#FFF3F3] font-bold text-[20px] 2xl:text-[24px]'>
                            What you missed
                        </h1>
                        <div className='grid grid-cols-3 mt-[15px] gap-[15px] 2xl:gap-[30px]'>
                            <div
                                className='rounded-[10px] border border-[#0C8CE9] min-h-[100px] flex flex-col justify-between bg-[#020F32] pt-[10px] pb-[11px] px-[15px] 2xl:px-[10px] cursor-pointer'
                                onClick={() => {
                                    setnotificationQuery('approvals')
                                    setNotificationOpen(true)
                                }}
                            >
                                <h2 className='text-center text-[24px] sm:text-[32px] font-bold text-white'>
                                    {paymentApprovals}
                                </h2>
                                <p className='text-[12px] lg:text-[10px] xl:text-[12px] text-center font-normal text-white leading-[14px] 2xl:leading-[17px]'>
                                    Payment approval
                                </p>
                            </div>
                            <div className='rounded-[10px] border border-[#0C8CE9] min-h-[100px] flex flex-col justify-between bg-[#020F32] pt-[10px] pb-[11px] px-[15px] 2xl:px-[10px] cursor-pointer'
                                onClick={() => {
                                    setnotificationQuery('Unread')
                                    setNotificationOpen(true)
                                }}
                            >
                                <h2 className='text-center text-[24px] sm:text-[32px] font-bold text-white'>
                                    {unreadMessages}
                                </h2>
                                <p className='text-[12px] lg:text-[10px] xl:text-[12px] text-center font-normal text-white leading-[14px] 2xl:leading-[17px]'>
                                    Unread message
                                </p>
                            </div>
                            <div className='rounded-[10px] border border-[#0C8CE9] min-h-[100px] flex flex-col justify-between bg-[#020F32] pt-[10px] pb-[11px] px-[15px] 2xl:px-[10px] cursor-pointer'
                                onClick={() => {
                                    setnotificationQuery('announcements')
                                    setNotificationOpen(true)
                                }}                            >
                                <h2 className='text-center text-[24px] sm:text-[32px] font-bold text-white'>
                                    {announcements}
                                </h2>
                                <p className='text-[12px] lg:text-[10px] xl:text-[12px] text-center font-normal text-white leading-[14px] 2xl:leading-[17px] break-words'>
                                    PayCat Announcements
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className={`pt-[30px] 2xl:pt-[44px] px-[20px] sm:px-[38px] min-h-[200px] pb-[20px] ${isSmallScreen && !isLargeScreen && (contactOpen || chatHistoryOpen) && 'hidden'}`}
                        style={{
                            border: '1px solid rgba(217, 217, 217, 0.50)',
                            boxShadow: '0px 0px 4px 0px #D9D9D9',
                            background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                        }}
                    >
                        <h1 className='text-[#FFF3F3] font-bold text-[20px] 2xl:text-[24px]'>
                            Recently dealt with...
                        </h1>
                        {isFetching ? (
                            <div className='flex justify-center mt-[40px]'>
                                <CircularProgress sx={{ color: 'white' }} />
                            </div>
                        ) : (

                            <div>
                                {data && data.recentDeals ? (
                                    <div className='mt-[15px]'>
                                        <ImageWithNestedDivs images={data.recentDeals.members} />
                                    </div>
                                ) : (
                                    <div>
                                        <h2 className='text-center text-white text-[12px] font-semibold mt-[50px]'>
                                            No chattings yet!
                                        </h2>
                                    </div>
                                )}

                            </div>
                        )}
                    </div>

                </div>
                {
                    showGraph && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0, y: 200 }}
                            transition={{ duration: 0.7, ease: 'easeInOut' }}
                            viewport={{ once: true }}
                            className='w-full sm:w-[90%] md:w-[80%] mx-auto lg:w-full  mt-[15px] p-[20px]'
                            style={{
                                opacity: 0,
                                boxShadow: '0px 0px 4px 0px #D9D9D9',
                                background: !isDarkMode && 'rgba(2, 15, 50,0.7)'
                            }}
                        >
                            {historyLoading ? (
                                <div className='flex justify-center items-center h-[350px]'>
                                    <CircularProgress sx={{ color: 'white' }} />
                                </div>
                            ) : (
                                <div>
                                 <Graph rawData={monthHistory.history} />
                                </div>
                            )}
                        </motion.div>
                    )
                }

            </div >
        </div >
    )
}

export default Layout(Dashboard)