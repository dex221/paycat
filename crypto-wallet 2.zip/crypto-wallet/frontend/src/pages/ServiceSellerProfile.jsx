import React, { useContext, useEffect, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import { CircularProgress, Rating, useMediaQuery } from '@mui/material'
import MarketplaceCard from '../components/MarketplaceCard'
import ServiceDetail from '../components/Modals/ServiceDetail'
import StatesContext from '../context/StatesContext'
import { useUserDeatilsQuery } from '../helpers/userApi'
import { useNavigate, useParams } from 'react-router-dom'
import { useGetAllServicesOfUserQuery, useGetCoinsPriceUSDQuery, useReviewByUserIdQuery } from '../helpers/ServiceApi'
import { useGetconversationIdMutation } from '../helpers/contactApi'
import ReviewSlider from '../components/sliders/ReviewSlider'


const ServiceSellerProfile = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, contactOpen, chatHistoryOpen, userData, walletConnected, setconnectAction, setnotConntedOpen } = context

    const { id } = useParams()
    const navigate = useNavigate()

    const [page, setpage] = useState(1)
    const [serviceData, setserviceData] = useState('')
    const [serviceDetailOpen, setserviceDetailOpen] = useState(false)
    const [isCardClicked, setisCardClicked] = useState(false)

    const smallerthen640 = useMediaQuery('(max-width:640px)')

    const { data, isFetching } = useUserDeatilsQuery(id)
    const { data: servicesData, isFetching: serviceLoading } = useGetAllServicesOfUserQuery({ userId: id, page })
    const { data: CoinsPrice, isFetching: CoinPriceLoading } = useGetCoinsPriceUSDQuery()
    const {data:reviewData , isLoading} = useReviewByUserIdQuery(id)
    const [createAndGetConvoId, res] = useGetconversationIdMutation()

    const handleClick = () => {
        if (walletConnected) {
            createAndGetConvoId(id)
        } else {
            setconnectAction(`Chat`)
            setnotConntedOpen(true)
        }
    }

    useEffect(() => {
        // Function to handle the scrolling behavior
        const handleScrollLock = () => {
            if (serviceDetailOpen) {
                // Disable scrolling on the body element
                document.body.style.overflow = 'hidden';
            } else {
                // Enable scrolling on the body element
                document.body.style.overflow = 'unset';
            }
        };

        // Call the function when the state changes
        handleScrollLock();

        // Clean up the effect to re-enable scrolling when the component unmounts
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [serviceDetailOpen]);

    useEffect(() => {

        if (res.status === 'fulfilled') {
            navigate(`/conversation/${res.data.conversationId} `, {
                state: {
                    name: data.user.name,
                    image: data.user.image,
                    walletAddress: data.user.walletAddress,
                    id: data.user._id,
                    fromChat: true
                }
            })
        }

    }, [res])

    useEffect(() => {

        if (isCardClicked) {
            setisCardClicked(false)
            setserviceDetailOpen(false)
            setTimeout(() => {
                setserviceDetailOpen(true)
            }, 400);
        }

    }, [isCardClicked])

    return (
        <div className='px-[30px] pt-[80px] pb-[30px] sm:py-[40px] max-w-[1540px] mx-auto'>

            {serviceDetailOpen && (
                <ServiceDetail setserviceDetailOpen={setserviceDetailOpen} serviceData={serviceData} setserviceData={setserviceData} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} setisCardClicked={setisCardClicked} />
            )}

            {isFetching || isLoading ? (
                <div className='flex justify-center mt-[200px] xl:mt-[250px]'>
                    <CircularProgress sx={{ color: isDarkMode && 'white' }} />
                </div>
            ) : (

                <div>
                    <div className='flex justify-center'>
                        <img src={data?.user?.image} alt="" className='rounded-full h-[100px] sm:h-[150px] w-[100px] sm:w-[150px] border-[2px] border-[#5E8BFA]' />
                    </div>
                    <h2 className={` font-semibold dark:text-white text-center text-[16px]  sm:text-[17px] mt-[15px]`}>
                        {data.user?.name}
                    </h2>
                    <h6 className='dark:text-white text-[11px] sm:text-[13px] text-center'>
                        {data.user?.walletAddress}
                    </h6>
                    <div className='flex justify-center mt-[5px]'>
                        <div className='flex items-center gap-[4px]'>
                            <Rating name="read-only" value={data.user.ratings} readOnly precision={0.5}
                                style={{
                                    color: '#9747FF',
                                    fontSize: smallerthen640 ? '22px' : '27px'

                                }}
                                sx={{
                                    '& .MuiRating-iconEmpty': {
                                        color: '#9747FF',  // Change color of non-active star
                                        borderColor: '#9747FF !important', // Change border color of non-active star
                                    },
                                }}
                            />
                            <h2 className='text-[10px] dark:text-white  font-light text-right '

                            >
                                ({data.user.totalReviews} rates)

                            </h2>
                        </div>
                    </div>

                    <div className='flex justify-center'>
                        <button
                            className='w-[250px] sm:w-[280px] disabled:cursor-not-allowed mt-[15px] h-[30px] sm:h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] sm:text-[14px] font-bold rounded-[10px] text-white'
                            onClick={() => handleClick()}
                            disabled={res.isLoading || (userData && userData._id === id)}

                        >
                            {res.isLoading ? <CircularProgress size={20} sx={{ color: 'white' }} /> : 'CHAT NOW'}
                        </button>
                    </div>

                    <ReviewSlider data={reviewData} />

                    <h2 className='dark:text-white text-center sm:text-left font-bold text-[18px] sm:text-[20px]  mt-[70px]'>
                        Services offered by {data.user.name}
                    </h2>


                    {serviceLoading ? (
                        <div className='flex justify-center items-center mt-[100px]'>
                            <CircularProgress sx={{ color: isDarkMode && 'white' }} />
                        </div>
                    ) : (
                        <div
                            className={`grid grid-cols-1 sm:grid-cols-2  ${contactOpen || chatHistoryOpen ? 'xl:grid-cols-3 lg:grid-cols-2' : 'xl:grid-cols-4 lg:grid-cols-3'} 2xl:grid-cols-4 gap-[40px] xl:gap-[45px] 2xl:gap-[60px] mt-[30px]`}
                        >
                            {servicesData.services.map((item, i) => (
                                <div key={i}>
                                    <div onClick={() => {
                                        setserviceDetailOpen(true)
                                        setserviceData(item)
                                    }} className='relative z-10'>
                                        <MarketplaceCard serviceData={item} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} />
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    <div className='flex justify-center mt-[20px]'>
                        {!isFetching && servicesData && servicesData.resultPerPage < servicesData.filteredServicesCount && (

                            <Pagination color='primary' size='medium'
                                count={Math.ceil(servicesData.totalServicesCount / servicesData.resultPerPage)}
                                page={page}
                                onChange={(event, value) => setpage(value)}
                                onClick={() => window.scrollTo(0, 0)}
                                sx={{
                                    '& .MuiPaginationItem-icon, & .MuiPaginationItem-root': {
                                        color: 'white',
                                        border: '1px solid #0C8CE9',
                                        borderRadius: '50px',
                                        backgroundColor: '#122758'
                                    },
                                }}

                            />
                        )}
                    </div>

                    {!isFetching && servicesData && servicesData.services.length === 0 && (
                        <div className='mt-[180px] pb-[60px] lg:pb-0  xl:mt-[200px]'>
                            <p className="text-center text-[12px] underline underline-offset-8 dark:text-gray-400 ">
                                No services found
                            </p>
                        </div>
                    )}

                </div>
            )
            }
        </div >
    )
}

export default Layout(ServiceSellerProfile)