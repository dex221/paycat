import React, { useContext, useState } from 'react'
import Layout from '../../components/Hoc/Layout'
import StatesContext from '../../context/StatesContext'
import { CircularProgress, IconButton } from '@mui/material'
import { useAllSliderImagesQuery, useCreateSliderImageMutation, useDeleteSliderImageMutation, useUpdateSliderImageMutation } from '../../helpers/homeSliderApi'
import DeleteIcon from '@mui/icons-material/Delete';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';

const investmentType = ['Slider 1', 'Slider 2']


const HomeSliders = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, setsuccess } = context
    const [loading, setloading] = useState(false)
    const [updateLoading, setupdateLoading] = useState(false)
    const [activeIndex, setactiveIndex] = useState('')

    const [activeType, setactiveType] = useState('Slider 1')

    const { data, isLoading } = useAllSliderImagesQuery(activeType)
    const [createSlider, res] = useCreateSliderImageMutation()
    const [deleteSlider] = useDeleteSliderImageMutation()
    const [updateSlider, updateRes] = useUpdateSliderImageMutation()

    const CloudinaryUploader = async (file, update) => {

        if (update) {
            setupdateLoading(true)
        } else {
            setloading(true)
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('upload_preset', 'ojipiz6u');
        const rqst = await fetch(`https://api.cloudinary.com/v1_1/${import.meta.env.VITE_API_CLOUD_NAME}/auto/upload`, {
            method: 'POST',
            body: formData,
        })

        setloading(false)
        setupdateLoading(false)

        const res = await rqst.json()

        if (update) {

            updateSlider({ imgUrl: res.secure_url, id: update })

        } else {

            createSlider({ type: activeType, imgUrl: res.secure_url })
        }


    };


    const handleImageChnage = (e, update) => {

        const reader = new FileReader()
        reader.onload = () => {
            if (reader.readyState === 2) {
                let img = reader.result
                CloudinaryUploader(img, update)
            }
        }
        reader.readAsDataURL(e.target.files[0])
    }

    return (
        <div className='px-[30px] pb-[30px] pt-[70px]  max-w-[1540px] mx-auto'>

            <div className='flex justify-center'>
                <div className='flex justify-center bg-gray-600 items-center h-[52px] px-[7px] rounded-[15px]'
                    style={{
                        background: isDarkMode && 'rgba(255, 255, 255, 0.04)'
                    }}
                >
                    <div className='flex'>
                        {investmentType.map((item, i) => (
                            <div key={i} >
                                <div className={` w-[95px] `} onClick={() => setactiveType(item)}>
                                    <button className={`rounded-[6px] w-full text-[14px] font-medium h-[34px] ${activeType === item ? 'bg-[#5E5EFA66] text-white' : ' text-[#93A4BD]'} `}
                                        style={{
                                            boxShadow: activeType === item && '0px 5px 13px 0px rgba(137, 126, 255, 0.27)',
                                            border: activeType === item && '1px solid #5E5EFA'
                                        }}
                                    >
                                        {item}
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className='bg-gray-600 items-center min-h-[200px] p-[15px] rounded-[15px] border border-gray-400 w-full sm:w-[400px] mx-auto mt-[30px]'
                style={{
                    background: isDarkMode && 'rgba(255, 255, 255, 0.04)'
                }}
            >
                <div className='flex justify-end'>
                    <label>
                        <div id='image'
                            className='w-[60px] h-[30px] cursor-pointer flex justify-center items-center bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] font-bold rounded-[10px] text-white'
                        >
                            {(loading || res.isLoading) ?  <CircularProgress sx={{ color: 'white' }} size={17} /> : 'Create'}
                        </div>
                        {!loading && (
                            <input
                                type="file"
                                htmlFor="image"
                                className='hidden'
                                accept=".jpg, .jpeg, .png, .gif"
                                onChange={(e) => {
                                    handleImageChnage(e)
                                    setactiveIndex(i)
                                }}
                            />
                        )}
                    </label>
                </div>

                {isLoading ? (
                    <div className='flex justify-center mt-[40px]'>
                        <CircularProgress sx={{ color: 'white' }} size={28} />
                    </div>
                ) : (
                    <div>
                        {data.slider.length > 0 ? (
                            <div className='my-[20px] space-y-[20px]'>
                                {data.slider.map((item, i) => (
                                    <div key={i} className='flex justify-between items-center'>
                                        <img src={item.imgUrl} alt="" className='h-[50px] w-[90px] object-cover rounded-[10px]' />
                                        <div className='flex items-center gap-[5px]'>

                                            <label>
                                                <div id='image'
                                                    className='cursor-pointer'
                                                >
                                                    {(updateLoading || updateRes.isLoading) && activeIndex === i ? <CircularProgress sx={{ color: 'white' }} size={17} /> : <EditOutlinedIcon sx={{ color: 'white', fontSize: '22px' }} />}

                                                </div>
                                                {!updateLoading && (
                                                    <input
                                                        type="file"
                                                        htmlFor="image"
                                                        className='hidden'
                                                        accept=".jpg, .jpeg, .png, .gif"
                                                        onChange={(e) => {
                                                            let update = item._id
                                                            handleImageChnage(e, update)
                                                            setactiveIndex(i)
                                                        }}
                                                    />
                                                )}
                                            </label>
                                            <IconButton
                                                onClick={() => deleteSlider(item._id)}
                                            >
                                                <DeleteIcon sx={{ color: 'white', fontSize: '22px' }} />
                                            </IconButton>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className='mt-[45px] text-center text-white text-[12px]'>
                                No images found
                            </p>
                        )}
                    </div>
                )}

            </div>

        </div>
    )
}

export default Layout(HomeSliders)