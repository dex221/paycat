import React, { useContext, useEffect, useState } from 'react'
import Layout from '../../components/Hoc/Layout'
import StatesContext from '../../context/StatesContext'
import { useAllOrdersAdminQuery, useUpdateOrderAdminMutation, useUpdateOrderStatusMutation } from '../../helpers/OrderApi'
import { CircularProgress } from '@mui/material'
import OrderDetails from '../../components/Modals/OrderDetails'
import { BNB_CONTRACT_ABI, BNB_CONTRACT_ADDRESS, BUSD_ADRESS, ETH_CONTRACT_ABI, ETH_CONTRACT_ADDRESS, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../../constants/constants'
import { prepareWriteContract, waitForTransaction, writeContract } from 'wagmi/actions'
import { useNetwork } from 'wagmi'


const investmentType = ['Booked', 'Received']
const tableHead = ['Serial No', 'Service Title', 'Status', 'Details', 'Actions']

const AdminOrders = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, setsuccess, seterror } = context

    const { chain } = useNetwork()

    const [open, setopen] = useState(false)
    const [orderData, setorderData] = useState('')
    const [activeIndex, setactiveIndex] = useState('')

    const [loading, setloading] = useState(false)
    const [showIndex, setsetshowIndex] = useState()
    const [secondLoading, setsecondLoading] = useState(false)

    const { data, isLoading, isFetching } = useAllOrdersAdminQuery()
    const [updateOrder, res] = useUpdateOrderAdminMutation()

    const handleOpenDropDown = (index) => {
        if (showIndex >= 0) {
            setsetshowIndex()
        } else {
            setsetshowIndex(index)
        }
    }

    const handleAdminDispute = async (e, item, i) => {

        try {

            setsecondLoading(true)

            const activeToken = item.paymentCoin

            if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
                if (chain && chain.id === 97) {
                    seterror('Switch you network to Ethereum')
                    setsecondLoading(false)
                    return
                }
            } else {
                if (chain && chain.id !== 97) {
                    seterror('Switch you network to BNB Smart Chain')
                    setsecondLoading(false)
                    return
                }
            }

            let tokenAddress = '';
            let contractAddress
            let contractAbi

            switch (activeToken) {
                case 'WBTC':
                    tokenAddress = WBTC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'ETH':
                    tokenAddress = WBTC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'BSUD':
                    tokenAddress = BUSD_ADRESS
                    contractAddress = BNB_CONTRACT_ADDRESS
                    contractAbi = BNB_CONTRACT_ABI
                    break;
                case 'USDT':
                    tokenAddress = USDT_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'BNB':
                    tokenAddress = WBNB_ADDRESS
                    contractAddress = BNB_CONTRACT_ADDRESS
                    contractAbi = BNB_CONTRACT_ABI
                    break;
                case 'USDC':
                    tokenAddress = USDC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                default:
                    break;
            }

            const { request } = await prepareWriteContract({
                address: contractAddress,
                abi: contractAbi,
                functionName: 'disputeToAdmin',
                args: [item.bookedBy.walletAddress, item.receivedBy.walletAddress, tokenAddress, item.orderId],
            })

            const { hash } = await writeContract(request)

            await waitForTransaction({
                confirmations: 1,
                hash
            })

            updateOrder(item._id)

        } catch (error) {
            seterror('An error occured try again later')
        } finally {
            setsecondLoading(false)
        }

    }

    const handleDispute = async (e, item, i) => {

        try {

            setloading(true)
            setactiveIndex(i)

            const activeToken = item.paymentCoin

            if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
                if (chain && chain.id === 97) {
                    seterror('Switch you network to Ethereum')
                    setloading(false)
                    return
                }
            } else {
                if (chain && chain.id !== 97) {
                    seterror('Switch you network to BNB Smart Chain')
                    setloading(false)
                    return
                }
            }

            let tokenAddress = '';
            let contractAddress
            let contractAbi

            switch (activeToken) {
                case 'WBTC':
                    tokenAddress = WBTC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'ETH':
                    tokenAddress = WBTC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'BSUD':
                    tokenAddress = BUSD_ADRESS
                    contractAddress = BNB_CONTRACT_ADDRESS
                    contractAbi = BNB_CONTRACT_ABI
                    break;
                case 'USDT':
                    tokenAddress = USDT_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                case 'BNB':
                    tokenAddress = WBNB_ADDRESS
                    contractAddress = BNB_CONTRACT_ADDRESS
                    contractAbi = BNB_CONTRACT_ABI
                    break;
                case 'USDC':
                    tokenAddress = USDC_ADDRESS
                    contractAddress = ETH_CONTRACT_ADDRESS
                    contractAbi = ETH_CONTRACT_ABI
                    break;
                default:
                    break;
            }

            let functionName = 'disputeToBuyer'
            if (item.status === 'delivered') {
                functionName = 'disputeToSeller'
            }

            const { request } = await prepareWriteContract({
                address: contractAddress,
                abi: contractAbi,
                functionName,
                args: [item.bookedBy.walletAddress, item.receivedBy.walletAddress, tokenAddress, item.orderId],
            })

            const { hash } = await writeContract(request)

            await waitForTransaction({
                confirmations: 1,
                hash
            })

            updateOrder(item._id)

        } catch (error) {
            seterror('An error occured try again later')
        } finally {
            setloading(false)
        }

    }

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setsuccess(`Order updated successfully`)
            setactiveIndex('')
            setsetshowIndex()
        }

    }, [res])


    return (
        <div className='px-[30px] pb-[30px] pt-[70px]  max-w-[1540px] mx-auto'>

            {open && (
                <OrderDetails setopen={setopen} orderData={orderData} />
            )}

            <div className='w-full xl:w-[95%] mx-auto mt-[40px]'>
                <div className='flex flex-col items-center w-full p-[15px] rounded-[10px]'
                    style={{
                        border: '1px solid rgba(217, 217, 217, 0.50)',
                        boxShadow: '0px 0px 4px 0px #D9D9D9',
                        background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                    }}
                >
                    <div className="relative rounded-[10px] overflow-x-auto w-full max-h-[400px]"

                    >
                        <table className="w-full">
                            <thead className="text-[14px] font-medium text-[#87909C]" style={{ background: 'rgba(255, 255, 255, 0.04)' }}>
                                <tr className='border-b-[0.5px] border-gray-700'>
                                    {tableHead.map((item, i) => (
                                        <th scope="col" className={`py-[16px] px-[30px] text-center`} key={i}>
                                            {item}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className='w-full'>
                                {!isLoading && data.orders.length > 0 && data.orders.map((item, i) => (
                                    <tr
                                        style={{
                                            background: 'rgba(255, 255, 255, 0.04)'
                                        }}
                                        key={i}
                                    >
                                        <td className="text-white text-center py-[15px] text-[16px] font-medium">
                                            {i + 1}
                                        </td>
                                        <td className="text-white text-center py-[15px] text-[16px] font-medium">
                                            {item.title.length > 25 ? `${item.title.substring(0, 25)}...` : item.title}
                                        </td>
                                        <td className={`${item.status === 'processing' ? 'text-yellow-500' : item.status === 'delivered' ? 'text-blue-500' : 'text-green-500'} text-center capitalize py-[15px] text-[16px] font-medium `}>
                                            {item.status}
                                        </td>
                                        <td className="text-white text-center py-[15px] text-[16px] font-medium">
                                            <button
                                                className='px-[10px] py-[5px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] font-bold rounded-[10px] text-white'
                                                onClick={() => {
                                                    setorderData(item)
                                                    setopen(true)
                                                }}
                                            >
                                                Show Details
                                            </button>
                                        </td>
                                        <td className="text-white text-center py-[15px] text-[16px] font-medium">

                                            <div className='relative flex justify-center'
                                            >
                                                <button
                                                    onClick={() => handleOpenDropDown(i)}

                                                    data-dropdown-toggle="dropdown"
                                                    className="w-[95px] h-[45px] rounded-[12px] text-[#05C34F] flex ml-[-13px] items-center justify-center text-[12px] font-medium"
                                                    type="button"
                                                    style={{
                                                        background: 'rgba(5, 195, 79, 0.10)'
                                                    }}
                                                >
                                                    Dispute
                                                    <svg className="w-[8px] h-[8px] ml-[10px]" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4" />
                                                    </svg>
                                                </button>
                                                {showIndex === i && (
                                                    <div className="absolute z-10 top-[50px] right-0 lg:right-[28px] bg-slate-800 rounded-[12px] w-[190px]"
                                                    >
                                                        <div className="p-[15px] space-y-[15px]">
                                                            <button
                                                                className='text-[13px] text-white h-[35px]  w-full rounded-[8px]'
                                                                style={{
                                                                    background: 'linear-gradient(134deg, #5E5EFA 0%, #3A3ADD 100%)'
                                                                }}
                                                                onClick={(e) => handleAdminDispute(e, item, i)}
                                                            >

                                                                {(secondLoading && activeIndex === i) ? <CircularProgress sx={{ color: 'white' }} size={18} /> : 'Dispute Admin'}
                                                            </button>
                                                            <button
                                                                style={{
                                                                    background: 'linear-gradient(134deg, #5E5EFA 0%, #3A3ADD 100%)'
                                                                }}
                                                                onClick={(e) => handleDispute(e, item, i)}
                                                                className='text-[13px] text-white h-[35px] w-full rounded-[8px]'>
                                                                {(loading && activeIndex === i) ? <CircularProgress sx={{ color: 'white' }} size={18} /> : `Dispute ${item.status === 'processing' ? 'Buyer' : 'Seller'}`}
                                                            </button>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </td>

                                    </tr>
                                ))}
                                <tr
                                    style={{
                                        background: 'rgba(255, 255, 255, 0.04)',
                                    }}
                                >
                                    {isLoading && (
                                        <td colSpan={'6'} className="py-[85px] text-center">
                                            <CircularProgress sx={{ color: 'white' }} />
                                        </td>
                                    )}
                                    {!isFetching && data.orders.length === 0 && (
                                        <td colSpan={'6'} className="text-[15px] py-[100px] font-medium text-[#87909C] text-center">
                                            No orders yet!
                                        </td>
                                    )}

                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Layout(AdminOrders)