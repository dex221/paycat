import React, { useContext, useEffect, useState } from 'react'
import StartUp from '../components/StartUp'
import HomeScreen from '../components/HomeScreen'
import { BACKEND_URL } from '../constants/constants'
import StatesContext from '../context/StatesContext'

const Home = () => {

    const context = useContext(StatesContext)
    const { usersCount, setusersCount } = context

    const [loading, setloading] = useState(true)

    useEffect(() => {
        handleUserCount()
    }, [])

    const handleUserCount = async () => {

        try {
            const response = await fetch(`${BACKEND_URL}/api/users/length`, {
                method: 'Get',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            let { TotalUsers, success } = await response.json();
            if (success) {
                setusersCount(TotalUsers)
            }
        } catch (error) {
            console.log(error)
        } finally {
            setloading(false)
        }

    }



    return (
        <div>
            <HomeScreen userLength={usersCount || 0} isDataLoading={loading}/>
        </div>
    )
}

export default Home