import React, { useContext, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import edit from '../assets/edit.png'
import search from '../assets/search.png'
import { useNavigate } from 'react-router-dom'
import { ethers } from 'ethers'
import { BACKEND_URL } from '../constants/constants'
import { CircularProgress } from '@mui/material'
import StatesContext from '../context/StatesContext'
import { useDisconnect } from 'wagmi'


const Settings = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, setuserData, userData, socketRef, resetState } = context

    const [name, setname] = useState(userData.name && userData.name)
    const [presentImage, setpresentImage] = useState(userData.image && userData.image)
    const [avatar, setavatar] = useState('')
    const [loading, setloading] = useState(false)

    const { disconnect } = useDisconnect();

    const handleImageChnage = (e) => {

        const reader = new FileReader()
        reader.onload = () => {
            if (reader.readyState === 2) {
                setpresentImage(reader.result)
                setavatar(reader.result)
            }
        }
        reader.readAsDataURL(e.target.files[0])
    }

    const navigate = useNavigate()

    const handleLogout = async () => {

        disconnect()
        sessionStorage.removeItem('Token');
        navigate('/')
        resetState()
        socketRef.current.emit("logout");

    }

    const CloudinaryUploader = async (file) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('upload_preset', 'ojipiz6u');
        const rqst = await fetch(`https://api.cloudinary.com/v1_1/${import.meta.env.VITE_API_CLOUD_NAME}/auto/upload`, {
            method: 'POST',
            body: formData,
        })

        const res = await rqst.json()
        return {
            imageUrl: res.secure_url
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault()
        setloading(true)

        try {

            let image = presentImage
            if (avatar) {
                const { imageUrl } = await CloudinaryUploader(avatar)
                image = imageUrl
            }

            const token = sessionStorage.getItem('Token');
            const response = await fetch(`${BACKEND_URL}/api/user/update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ name, image })
            });
            let { success, user } = await response.json();

            if (success) {
                setuserData(user)
            }

        } catch (e) {
            console.log(e)
        }

        finally {
            setloading(false)
        }

    }

    return (
        <div className='flex justify-center mt-[150px] pb-[30px] selection: md:mt-[100px] w-full'>
            <div className='flex flex-col items-center w-full mx-[30px] sm:w-[400px] p-[30px]'
                style={{
                    border: '1px solid rgba(217, 217, 217, 0.50)',
                    boxShadow: '0px 0px 4px 0px #D9D9D9',
                    background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                }}
            >
                <div className='relative h-[150px] 2xl:h-[174px] w-[150px] 2xl:w-[174px] rounded-full'>
                    <img src={presentImage} alt="" className='rounded-full h-full w-full object-cover border border-[#0C8CE9]' />
                    <div className='absolute bottom-[13px] right-[15px]'>
                        <label htmlFor="imageSelect" className='cursor-pointer'>
                            <img src={edit} alt="" />
                        </label>
                        <input
                            id='imageSelect'
                            type="file"
                            accept=".jpg, .jpeg, .png, .gif"
                            className='hidden'
                            onChange={(e) => handleImageChnage(e)}
                        />
                    </div>
                </div>
                <div>

                    <form
                        onSubmit={(e) => handleSubmit(e)}
                        className='mt-[30px] flex flex-col items-center gap-[15px] w-[250px]'>
                        <div className='relative z-10 w-full'>
                            <input
                                type="text"
                                className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[35px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                                placeholder='Name'
                                value={name}
                                required
                                onChange={(e) => setname(e.target.value)}
                                style={{
                                    border: '1px solid rgba(217, 217, 217, 0.50)'
                                }}
                            />
                            <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                                <img src={search} alt="" className='h-[13px]' />
                            </div>
                        </div>
                        <button
                            type='submit'
                            disabled={loading}
                            className='w-full h-[29px] 2xl:h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] 2xl:text-[14px] font-bold rounded-[10px] text-white'
                        >
                            {loading ? <CircularProgress size={19} sx={{ color: 'white' }} /> : 'Save'}
                        </button>

                        <button className='w-full mt-[10px] h-[29px] 2xl:h-[34px] bg-[#E0115F] hover:bg-[#B20A4D] duration-700 text-[12px] 2xl:text-[14px] font-bold rounded-[10px] text-white'
                            onClick={() => handleLogout()}
                        >
                            Disconnect wallet
                        </button>
                    </form>
                </div>

            </div>
        </div>
    )
}

export default Layout(Settings)