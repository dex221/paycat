import React, { useContext, useEffect, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import StatesContext from '../context/StatesContext'
import { useAllOrdersQuery, useUpdateOrderStatusMutation } from '../helpers/OrderApi'
import { CircularProgress } from '@mui/material'
import OrderDetails from '../components/Modals/OrderDetails'
import { useLocation } from 'react-router-dom'
import ReviewModel from '../components/Modals/ReviewModel'
import { BNB_CONTRACT_ABI, BNB_CONTRACT_ADDRESS, BUSD_ADRESS, ETH_CONTRACT_ABI, ETH_CONTRACT_ADDRESS, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../constants/constants'
import { useNetwork } from 'wagmi'
import { prepareWriteContract, waitForTransaction, writeContract } from 'wagmi/actions'

const investmentType = ['Booked', 'Received']
const tableHead = ['Serial No', 'Service Title', 'Status', 'Details', 'Actions']

const Orders = () => {

  const context = useContext(StatesContext)
  const { isDarkMode, userData, setsuccess, seterror } = context

  const { state } = useLocation()

  let defaultValue = 'Booked'

  if (state && state.type) {
    defaultValue = state.type
  }

  const { chain } = useNetwork()

  const [activeType, setactiveType] = useState(defaultValue)
  const [orderStatus, setorderStatus] = useState('')
  const [open, setopen] = useState(false)
  const [orderData, setorderData] = useState('')
  const [activeIndex, setactiveIndex] = useState('')
  const [serviceId, setserviceId] = useState('')
  const [reviewOpen, setreviewOpen] = useState(false)
  const [receivedBy, setreceivedBy] = useState('')
  const [loading, setloading] = useState(false)

  let userId = ''
  if (userData && userData._id) {
    userId = userData._id
  }

  const { data, isLoading, isFetching, refetch } = useAllOrdersQuery({ serviceType: activeType, userId })
  const [updateOrder, res] = useUpdateOrderStatusMutation()


  const handleClick = async (e, item, i) => {

    setserviceId(item.serviceId)
    setreceivedBy(item.receivedBy._id)
    setactiveIndex(i)

    let status
    if (item.status === 'processing') {
      status = 'delivered'
    } else if (item.status === 'delivered') {
      status = 'approved'
    }

    setorderStatus(status)

    if (status === 'approved') {
      try {

        setloading(true)

        let contractAddress
        let contactAbi

        const activeToken = item.paymentCoin

        if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
          contractAddress = ETH_CONTRACT_ADDRESS
          contactAbi = ETH_CONTRACT_ABI
          if (chain && chain.id === 97) {
            seterror('Switch you network to Ethereum')
            setloading(false)
            return
          }
        } else {
          contractAddress = BNB_CONTRACT_ADDRESS
          contactAbi = BNB_CONTRACT_ABI
          if (chain && chain.id !== 97) {
            seterror('Switch you network to BNB Smart Chain')
            setloading(false)
            return
          }
        }

        let tokenAddress

        switch (activeToken) {
          case 'WBTC':
            tokenAddress = WBTC_ADDRESS
            break;
          case 'ETH':
            tokenAddress = WBTC_ADDRESS
            break;
          case 'BSUD':
            tokenAddress = BUSD_ADRESS
            break;
          case 'USDT':
            tokenAddress = USDT_ADDRESS
            break;
          case 'BNB':
            tokenAddress = WBNB_ADDRESS
            break;
          case 'USDC':
            tokenAddress = USDC_ADDRESS
            break;
          default:
            break;
        }

        let uniquieId = item.orderId

        const { request } = await prepareWriteContract({
          address: contractAddress,
          abi: contactAbi,
          functionName: 'releaseFunds',
          args: [item.receivedBy.walletAddress, tokenAddress, uniquieId],
        })

        const { hash } = await writeContract(request)

        await waitForTransaction({
          hash,
          confirmations: 1
        })

        updateOrder({ orderId: item._id, status })


      } catch (error) {

      } finally {
        setloading(false)
      }


    } else {
      updateOrder({ orderId: item._id, status })
    }


  }

  useEffect(() => {

    if (res.status === 'fulfilled') {
      setsuccess(`Order ${orderStatus} successfully`)
      setactiveIndex('')
      if (orderStatus === 'approved') {
        setreviewOpen(true)
      }
    }

  }, [res])

  useEffect(() => {

    if (state) {
      refetch()
    }

  }, [state])


  return (
    <div className='px-[30px] pb-[30px] pt-[70px]  max-w-[1540px] mx-auto'>

      {open && (
        <OrderDetails setopen={setopen} orderData={orderData} />
      )}

      {reviewOpen && (
        <ReviewModel open={reviewOpen} setopen={setreviewOpen} serviceId={serviceId} receivedBy={receivedBy} />
      )}

      <div className='flex justify-center'>
        <div className='flex justify-center bg-gray-600 items-center h-[52px] px-[7px] rounded-[15px]'
          style={{
            background: isDarkMode && 'rgba(255, 255, 255, 0.04)'
          }}
        >
          <div className='flex'>
            {investmentType.map((item, i) => (
              <div key={i} >
                <div className={` w-[95px] `} onClick={() => setactiveType(item)}>
                  <button className={`rounded-[6px] w-full text-[14px] font-medium h-[34px] ${activeType === item ? 'bg-[#5E5EFA66] text-white' : ' text-[#93A4BD]'} `}
                    style={{
                      boxShadow: activeType === item && '0px 5px 13px 0px rgba(137, 126, 255, 0.27)',
                      border: activeType === item && '1px solid #5E5EFA'
                    }}
                  >
                    {item === 'Booked' ? ' My Orders' : 'My Sales'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className='w-full xl:w-[95%] mx-auto mt-[40px]'>
        <div className='flex flex-col items-center w-full p-[15px] rounded-[10px]'
          style={{
            border: '1px solid rgba(217, 217, 217, 0.50)',
            boxShadow: '0px 0px 4px 0px #D9D9D9',
            background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

          }}
        >
          <div className="relative rounded-[10px] overflow-x-auto w-full max-h-[400px]"

          >
            <table className="w-full">
              <thead className="text-[14px] font-medium text-[#87909C]" style={{ background: 'rgba(255, 255, 255, 0.04)' }}>
                <tr className='border-b-[0.5px] border-gray-700'>
                  {tableHead.map((item, i) => (
                    <th scope="col" className={`py-[16px] px-[30px] text-center`} key={i}>
                      {item}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className='w-full'>
                {!isLoading && data.orders.length > 0 && data.orders.map((item, i) => (
                  <tr
                    style={{
                      background: 'rgba(255, 255, 255, 0.04)'
                    }}
                    key={i}
                  >
                    <td className="text-white text-center py-[15px] text-[16px] font-medium">
                      {i + 1}
                    </td>
                    <td className="text-white text-center py-[15px] text-[16px] font-medium">
                      {item.title.length > 25 ? `${item.title.substring(0, 25)}...` : item.title}
                    </td>
                    <td className={`${item.status === 'processing' ? 'text-yellow-500' : item.status === 'delivered' ? 'text-blue-500' : item.status === 'Dismissed' ? 'text-red-500' : 'text-green-500'} text-center capitalize py-[15px] text-[16px] font-medium `}>
                      {item.status}
                    </td>
                    <td className="text-white text-center py-[15px] text-[16px] font-medium">
                      <button
                        className='px-[10px] py-[5px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[12px] font-bold rounded-[10px] text-white'
                        onClick={() => {
                          setorderData(item)
                          setopen(true)
                        }}
                      >
                        Show Details
                      </button>
                    </td>
                    <td className="text-white text-center py-[15px] text-[16px] font-medium">
                      <button
                        className={`h-[30px] w-[75px] bg-[#5E5EFA66] disabled:cursor-not-allowed duration-700 text-[12px] font-bold rounded-[10px] text-white`}
                        disabled={(item.status === 'processing' && activeType === 'Booked') || (item.status === 'delivered' && activeType === 'Received') || (item.status === 'approved') || res.isLoading || item.status === 'Dismissed'}
                        style={{
                          boxShadow: '0px 5px 13px 0px rgba(137, 126, 255, 0.27)',
                          border: '1px solid #5E5EFA'
                        }}
                        onClick={(e) => handleClick(e, item, i)}
                      >
                        {((res.isLoading || loading) && activeIndex === i) ? <CircularProgress sx={{ color: 'white' }} size={17} /> : (
                          <h2>
                            {!res.isLoading && ((item.status === 'processing' || item.status === 'delivered') && activeType === 'Booked') && 'Approve'}
                            {!res.isLoading && (item.status === 'processing' && activeType === 'Received') && 'Deliver'}

                            {!res.isLoading && (item.status === 'delivered' && activeType === 'Received') && 'Delivered'}

                            {(item.status === 'approved' && activeType === 'Booked') && 'Approved'}
                            {(item.status === 'approved' && activeType === 'Received') && 'Delivered'}
                            {item.status === 'Dismissed' && 'Dismissed'}
                          </h2>
                        )}

                      </button>

                    </td>

                  </tr>
                ))}
                <tr
                  style={{
                    background: 'rgba(255, 255, 255, 0.04)',
                  }}
                >
                  {isLoading && (
                    <td colSpan={'6'} className="py-[85px] text-center">
                      <CircularProgress sx={{ color: 'white' }} />
                    </td>
                  )}
                  {!isFetching && data.orders.length === 0 && (
                    <td colSpan={'6'} className="text-[15px] py-[100px] font-medium text-[#87909C] text-center">
                      You didn't {activeType.toLowerCase()} any orders yet!
                    </td>
                  )}

                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>
  )
}

export default Layout(Orders)