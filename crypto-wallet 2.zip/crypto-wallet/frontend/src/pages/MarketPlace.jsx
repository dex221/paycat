import React, { useContext, useEffect, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import searchicon from '../assets/searchicon.png'
import bitcoinleft from '../assets/marketplace/bitcoinleft.svg'
import bitcoinright from '../assets/marketplace/bitcoinright.png'
import flower from '../assets/marketplace/flower.svg'
import twoflowers from '../assets/marketplace/twoflowers.png'
import { Country } from 'country-state-city'
import { CircularProgress, Pagination, useMediaQuery } from '@mui/material'

import bnb from '../assets/tokens/bnb.png'
import bsud from '../assets/tokens/bsud.png'
import eth from '../assets/tokens/eth.png'
import usdc from '../assets/tokens/usdc.png'
import usdt from '../assets/tokens/usdt.png'
import wbtc from '../assets/tokens/wbtc.png'
import StatesContext from '../context/StatesContext'

import MarketplaceCard from '../components/MarketplaceCard'
import ServiceDetail from '../components/Modals/ServiceDetail'
import CustomSelect from '../components/CustomSelect'
import { useGetAllServicesQuery, useGetCoinsPriceUSDQuery } from '../helpers/ServiceApi'
import DeleteConfirmation from '../components/Modals/DeleteConfirmation'

const categoriesData = [
    'All categories',
    "Services",
    "Phone & tablet",
    "Smart Watches",
    "Art&Decoration",
    "Computers",
    "Jewelry & Watches",
    "Fashion & Accessories",
    "Home & Garden",
    "Motors",
    "For Free",
    "Video games",
    "Baby & Toys",
    "Multimedia",
    "Job offer",
    "Books/DVD’s",
    "Property",
    "Other",
];

const coinsData = [
    {
        name: 'All payment coins',
    },
    {
        name: 'WBTC',
        img: wbtc,

    },
    {
        name: 'ETH',
        img: eth,

    },
    {
        name: 'BSUD',
        img: bsud,

    },
    {
        name: 'USDC',
        img: usdc,

    },
    {
        name: 'USDT',
        img: usdt,

    },
    {
        name: 'BNB',
        img: bnb,

    },

]

const MarketPlace = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, search, setsearch, setnotConntedOpen, walletConnected, setconnectAction, setcreateServiceOpen, setchatHistoryOpen, setcontactOpen } = context

    const [open, setopen] = useState(false)
    const [country, setcountry] = useState('All countries')
    const [categories, setcategories] = useState('All categories')
    const [coins, setcoins] = useState('All payment coins')

    const [filters, setfilters] = useState({
        country: '',
        categories: '',
        coins: '',
        search: ''
    })

    const [isCountryOpen, setisCountryOpen] = useState(false)
    const [isCtaegoryOpen, setisCtaegoryOpen] = useState(false)
    const [iscoinsOpen, setiscoinsOpen] = useState(false)
    const [showFilters, setshowFilters] = useState(false)
    const [isCardClicked, setisCardClicked] = useState(false)

    const [serviceDetailOpen, setserviceDetailOpen] = useState(false)
    const [serviceData, setserviceData] = useState('')
    const [serviceId, setserviceId] = useState('')
    const [page, setpage] = useState(1)
    const [cardData, setcardData] = useState('')

    const smallerthen640 = useMediaQuery('(max-width:640px)')
    const smallerthen1415 = useMediaQuery('(max-width:1415px)')


    const { data, isFetching: isLoading, refetch, isLoading: loading } = useGetAllServicesQuery({ page, filters })
    const { data: CoinsPrice, isFetching: CoinPriceLoading } = useGetCoinsPriceUSDQuery()

    const handleClick = (item) => {
        setchatHistoryOpen(false)
        setcontactOpen(false)
        setserviceDetailOpen(true)
        setserviceData(item)
    }

    useEffect(() => {
        // Function to handle the scrolling behavior
        const handleScrollLock = () => {
            if (serviceDetailOpen || iscoinsOpen || isCtaegoryOpen || isCountryOpen) {
                if (serviceDetailOpen || smallerthen640) {
                    document.body.style.maxHeight = '100vh';
                    document.body.style.overflow = 'hidden';
                }
            } else {
                // Enable scrolling on the body element
                document.body.style.maxHeight = 'auto';
                document.body.style.overflow = 'unset';
            }

        };

        // Call the function when the state changes
        handleScrollLock();

        // Clean up the effect to re-enable scrolling when the component unmounts
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [serviceDetailOpen, isCtaegoryOpen, iscoinsOpen, isCountryOpen]);

    useEffect(() => {

        if (isCountryOpen) {
            setiscoinsOpen(false)
            setisCtaegoryOpen(false)
        }

    }, [isCountryOpen])

    useEffect(() => {

        if (iscoinsOpen) {
            setisCountryOpen(false)
            setisCtaegoryOpen(false)
        }

    }, [iscoinsOpen])

    useEffect(() => {

        if (isCtaegoryOpen) {
            setisCountryOpen(false)
            setiscoinsOpen(false)
        }

    }, [isCtaegoryOpen])

    useEffect(() => {
        if (data) {
            setcardData(data)
            refetch()
        }
    }, [data])


    useEffect(() => {
        setpage(1)

        if (categories !== 'All categories') {

            setfilters(prevFilters => ({
                ...prevFilters,
                categories: encodeURIComponent(categories)
            }));
        } else {
            setfilters(prevFilters => ({
                ...prevFilters,
                categories: ''
            }));
        }

        if (country !== 'All countries') {
            setfilters(prevFilters => ({
                ...prevFilters,
                country
            }));
        } else {
            setfilters(prevFilters => ({
                ...prevFilters,
                country: ''
            }));

        }


        if (coins !== 'All payment coins') {
            setfilters(prevFilters => ({
                ...prevFilters,
                coins
            }));
        } else {
            setfilters(prevFilters => ({
                ...prevFilters,
                coins: ''
            }));
        }

        setfilters(prevFilters => ({
            ...prevFilters,
            search
        }));

        if (search) {
            window.scrollTo(0, 0)
        }


    }, [country, categories, coins, search])

    useEffect(() => {

        if (isCardClicked) {
            setisCardClicked(false)
            setserviceDetailOpen(false)
            setTimeout(() => {
                setserviceDetailOpen(true)
            }, 400);
        }

    }, [isCardClicked])



    return (
        <div className={`mt-[100px] md:mt-0 mb-[50px] md:mb-0 max-w-[1540px] mx-auto relative  `}>

            {serviceDetailOpen && (
                <ServiceDetail setserviceDetailOpen={setserviceDetailOpen} serviceData={serviceData} setserviceData={setserviceData} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} setisCardClicked={setisCardClicked} />
            )}

            {open && (
                <DeleteConfirmation open={open} setopen={setopen} serviceId={serviceId} />
            )}

            <div className=' md:m-[25px] px-[20px] md:px-0'>

                {/* <div className={`block lg:hidden w-full fixed top-[65px]  ${serviceDetailOpen ? 'z-20' : 'z-50'} left-0 right-0 py-[15px] px-[20px]`}
                    style={{
                        backgroundColor: isDarkMode ? 'rgb(2, 15, 50)' : 'rgb(75 85 99)'
                    }}
                >
                    <div className='relative h-[40px] w-full '>
                        <input
                            type="text"
                            value={search}
                            onChange={(e) => setsearch(e.target.value)}
                            className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px]  dark:placeholder:text-[#D9D9D980] dark:text-white'
                            placeholder='Search...'
                            style={{
                                border: isDarkMode ? '1px solid rgba(217, 217, 217, 0.50)' : '1px solid black'
                            }}
                        />
                        <div className='absolute top-[2px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                            <img src={searchicon} alt="" className='h-[16px]' />
                        </div>
                    </div>
                </div> */}

                <div className='w-full h-[84px] relative z-10 overflow-hidden flex items-center mt-[30px] lg:mt-0'
                    style={{
                        borderRadius: '10px',
                        border: '1px solid #9747FF',
                        background: 'linear-gradient(256deg, rgba(18, 39, 88, 0.50) 0%, rgba(151, 71, 255, 0.50) 100%)',
                        boxShadow: '0px 0px 4px 0px #D9D9D9'
                    }}
                >
                    <div className='hidden sm:block absolute left-[30px] sm:left-[62px] z-20'>
                        <img src={flower} alt="" />
                    </div>
                    <div className='hidden sm:block absolute left-[45px] sm:left-[77px] bottom-0'>
                        <img src={bitcoinleft} alt="" />
                    </div>
                    <div className='hidden sm:block absolute right-0 bottom-0'>
                        <img src={bitcoinright} alt="" />
                    </div>
                    <div className='hidden sm:block absolute left-[50%] sm:left-[57%] bottom-0'>
                        <img src={twoflowers} alt="" className='h-[50px]' />
                    </div>

                    <div className='flex justify-between items-center relative z-20 w-full gap-[25px] '>
                        <h2 className={`ml-[25px] sm:ml-[85px] lg:ml-[200px] text-white text-[12px] md:text-[14px] ${smallerthen1415 ? 'xl:text-[16px]' : 'xl:text-[20px]'}   font-bold`}>
                            is time to Earn some crypto by selling your service and some of your stuff.

                        </h2>
                    

                        <div>
                            <button
                                onClick={() => {
                                    if (walletConnected) {
                                        setcreateServiceOpen(true)
                                    } else {
                                        setnotConntedOpen(true)
                                        setconnectAction('sell')
                                    }
                                }}
                                className=' mr-[25px] sm:mr-[85px] text-[12px] sm:text-[14px] font-bold text-white w-[95px] sm:w-[118px] h-[32px] sm:h-[34px] rounded-[10px] bg-[#0C8CE9]'>
                                SELL NOW
                            </button>
                        </div>

                    </div>

                </div>

                <div className='sm:min-h-[64px] relative md:flex items-center mt-[10px] py-[10px] sm:py-[20px] lg:py-0 px-[20px] lg:px-[65px]'
                    style={{
                        borderRadius: '10px',
                        border: '1px solid #9747FF',
                        background: 'linear-gradient(90deg, rgba(151, 71, 255, 0.50) 0%, #020F32 72.09%)',
                        boxShadow: '0px 0px 4px 0px #D9D9D9'
                    }}
                >
                    <div>
                        <h2 className='sm:hidden text-right text-white font-medium text-[12px]'
                            onClick={() => setshowFilters(!showFilters)}
                        >
                            {showFilters ? 'Hide filters' : 'Show filters'}
                        </h2>
                    </div>
                    {(showFilters || !smallerthen640) && (
                        <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 px-[5px] gap-[15px] md:gap-[25px] xl:gap-[40px]  w-full pt-[15px] pb-[10px]'>

                            <div
                                className='relative z-30 lg:z-10'>
                                <CustomSelect
                                    open={isCtaegoryOpen}
                                    setopen={setisCtaegoryOpen}
                                    value={categories}
                                    onChange={(newValue) => setcategories(newValue)}
                                    options={categoriesData}
                                />

                            </div>
                            <div
                                className='relative z-20 lg:z-10'
                            >
                                <CustomSelect
                                    open={iscoinsOpen}
                                    setopen={setiscoinsOpen}
                                    value={coins}
                                    onChange={(newValue) => setcoins(newValue)}
                                    options={coinsData}
                                />
                            </div>
                            <div
                                className='relative z-10'
                            >
                                <CustomSelect
                                    open={isCountryOpen}
                                    setopen={setisCountryOpen}
                                    value={country}
                                    onChange={(newValue) => setcountry(newValue)}
                                    options={Country && Country.getAllCountries()}
                                    isCountry={true}
                                />
                            </div>

                        </div>
                    )}

                </div>
                {isLoading ? (
                    <div className='flex justify-center items-center mt-[120px] sm:mt-[150px] xl:mt-[200px]'>
                        <CircularProgress sx={{ color: isDarkMode && 'white' }} />
                    </div>
                ) : (
                    <div>
                        < div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 ${smallerthen1415 ? 'xl:grid-cols-3' : 'xl:grid-cols-4'}   2xl:grid-cols-4 gap-[40px] xl:gap-[45px] 2xl:gap-[60px] mt-[30px]`}>
                            {cardData && cardData.services.length > 0 && cardData.services.map((item, i) => (
                                <div key={i}>
                                    <MarketplaceCard handleClick={() => handleClick(item)} serviceData={item} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} setdeleteOpen={setopen} setserviceId={setserviceId} />
                                </div>
                            ))}
                        </div>

                    </div>
                )}

                <div className='flex justify-center mt-[20px]'>
                    {!isLoading && data && data.resultPerPage < data.filteredServicesCount && (

                        <Pagination color='primary' size='medium'
                            count={Math.ceil(data.totalServicesCount / data.resultPerPage)}
                            page={page}
                            onChange={(event, value) => setpage(value)}
                            onClick={() => window.scrollTo(0, 0)}
                            sx={{
                                '& .MuiPaginationItem-icon, & .MuiPaginationItem-root': {
                                    color: 'white',
                                    border: '1px solid #0C8CE9',
                                    borderRadius: '50px',
                                    backgroundColor: '#122758'
                                },
                            }}

                        />
                    )}
                </div>

                {!isLoading && data.services.length === 0 && (
                    <div className='mt-[120px] pb-[60px] lg:pb-0 sm:mt-[150px] xl:mt-[200px]'>
                        <p className="text-center text-[12px] underline underline-offset-8 text-gray-400 my-7">
                            No services found
                        </p>
                    </div>
                )}

            </div>
        </div >
    )
}

export default Layout(MarketPlace)