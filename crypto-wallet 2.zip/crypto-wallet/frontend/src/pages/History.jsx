import React, { useContext } from 'react'
import Layout from '../components/Hoc/Layout'
import StatesContext from '../context/StatesContext'
import Table from '../components/Table'
import { useGetHistoryQuery } from '../helpers/notificationApi'

const History = () => {

    const context = useContext(StatesContext)
    const { isDarkMode, userData } = context

    const tableHead = ['Serial No', 'Transaction Date', 'Receipt Address ', 'Amount']

    const { data, isFetching } = useGetHistoryQuery((userData && userData._id) || '')

    return (
        <div className='w-[80%] pb-[30px] mx-auto mt-[150px] md:mt-[100px]'>
            <div className='flex flex-col items-center w-full p-[15px] rounded-[10px]'
                style={{
                    border: '1px solid rgba(217, 217, 217, 0.50)',
                    boxShadow: '0px 0px 4px 0px #D9D9D9',
                    background: !isDarkMode && 'rgba(2, 15, 50,0.7)'

                }}
            >
                <Table
                    tableHead={tableHead}
                    data={data}
                    isFetching={isFetching}
                />
            </div>
        </div>
    )
}

export default Layout(History)