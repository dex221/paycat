import React, { useContext, useEffect, useRef, useState } from 'react'
import Layout from '../components/Hoc/Layout'
import card from '../assets/credit-card.png'
import chevron from '../assets/downarrow.png'
import homeboxbg from '../assets/home/homeboxbg.png'
import homeboxbgsecond from '../assets/home/homeboxbgsecond.png'
import info from '../assets/info-circle.png'
import rectangle from '../assets/rectangle.png'
import { InformationCircleIcon, PaperAirplaneIcon, XMarkIcon } from '@heroicons/react/24/solid'
import messagepic from '../assets/message.png'
import backIcon from '../assets/back-icon.png'
import link from '../assets/link.png'
import axios from 'axios'

import { motion } from 'framer-motion';
import TokenContainer from '../components/TokenContainer'
import ChatBox from '../components/ChatBox'
import { useLocation, useParams } from 'react-router-dom'
import { useSendMessageMutation } from '../helpers/conversationApi'
import StatesContext from '../context/StatesContext'
import StyledTextFeild from '../components/StyledTextFeild'
import { useMediaQuery } from '@mui/material'

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const Conversation = () => {

    const context = useContext(StatesContext)
    const { onlineUsers, setlastMessage, chatOpen, setcontactOpen, setchatOpen, contactOpen, chatHistoryOpen } = context

    const [openpaymentMode, setopenpaymentMode] = useState(false)
    const [paymentModes, setpaymentModes] = useState('SINGLE PAYMENT')
    const [showSugggestion, setshowSugggestion] = useState(true)
    const [openChatBox, setopenChatBox] = useState(false)
    const [message, setmessage] = useState('')
    const [isUserActive, setisUserActive] = useState('')
    const [progress, setprogress] = useState('')
    const [fileName, setfileName] = useState('')

    const smallerthen650 = useMediaQuery('(max-width:600px)')

    const [sendMessage, res] = useSendMessageMutation()

    let { state } = useLocation()
    const { id } = useParams()

    const handleSubmit = (e) => {

        e.preventDefault()

        sendMessage({ id, message, userId: state.id })
        setlastMessage({
            conversationId: id,
            message,
            createdAt: new Date(),
            userData: {
                _id: state._id,
                name: state.name,
                image: state.image,
                walletAddress: state.walletAddress
            },
            unreadCount: 0
        })
        setmessage('')
    }

    const CloudinaryUploader = async (file, filename) => {

        setprogress(0)

        const formData = new FormData();
        formData.append('file', file.target.files[0]);
        formData.append('upload_preset', 'ojipiz6u');

        await axios({
            method: "POST",
            url: `https://api.cloudinary.com/v1_1/${import.meta.env.VITE_API_CLOUD_NAME}/auto/upload`,
            data: formData,
            onUploadProgress: (progressEvent) => {
                const { loaded, total } = progressEvent;
                let percent = Math.floor((loaded * 100) / total)
                setprogress(percent)
            }

        }).then(async (res) => {

            if (filename) {

                setlastMessage({
                    conversationId: id,
                    message: 'Sent an document',
                    createdAt: new Date(),
                    userData: {
                        _id: state._id,
                        name: state.name,
                        image: state.image,
                        walletAddress: state.walletAddress
                    },
                    unreadCount: 0
                })
                sendMessage({ id, document: res.data.secure_url, userId: state.id, filename })

            } else {

                setlastMessage({
                    conversationId: id,
                    message: 'Sent an picture',
                    createdAt: new Date(),
                    userData: {
                        _id: state._id,
                        name: state.name,
                        image: state.image,
                        walletAddress: state.walletAddress
                    },
                    isSeen: true,
                    unreadCount: 0
                })

                sendMessage({ id, image: res.data.secure_url, userId: state.id })
            }

        })


    };

    const handleChange = (e) => {

        setopenChatBox(true)
        const selectedFile = e.target.files[0];

        if (selectedFile) {

            const allowedExtensions = ['doc', 'docx', 'pptx', 'txt', 'zip', 'tar', 'pdf'];
            const fileExtension = selectedFile.name.split('.').pop().toLowerCase();

            if (allowedExtensions.includes(fileExtension)) {

                const maxSize = 10 * 1024 * 1024; // 10MB in bytes
                if (selectedFile.size <= maxSize) {
                    let filename = selectedFile.name

                    setfileName(filename)
                    CloudinaryUploader(e, filename)

                } else {
                    toast.error('File size should not exceed 10MB.', {
                        position: smallerthen650 ? 'top-center' : "top-right",
                        autoClose: 3000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "light",
                        toastClassName: "rounded-lg",
                        className: 'text-[16px] mt-[75px] mx-auto md:mt-0 w-[320px] h-full rounded-md relative z-50',
                        style: { borderRadius: '15px' },
                    });
                }

            } else {
                CloudinaryUploader(e)
            }

            // Reset the file input value
            e.target.value = '';
        }
    }

    useEffect(() => {
        // Function to handle the scrolling behavior
        const handleScrollLock = () => {
            if (openChatBox && !smallerthen650) {
                // Disable scrolling on the body element
                document.body.style.overflow = 'hidden';
            } else {
                // Enable scrolling on the body element
                document.body.style.overflow = 'unset';
            }
        };

        // Call the function when the state changes
        handleScrollLock();

        // Clean up the effect to re-enable scrolling when the component unmounts
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [openChatBox]);


    useEffect(() => {

        if (onlineUsers) {
            let isActive = onlineUsers.some((data) => data.userId === state.walletAddress);
            setisUserActive(isActive)
        }

    }, [onlineUsers])

    useEffect(() => {


        if (state.scrollBottom) {
            window.scrollTo(0, document.body.scrollHeight);
            setopenChatBox(true)
        }

        if (state.fromChat) {
            setchatOpen(true)
        }

        const handleInputFocus = (event) => {
            // Scroll the input into view when it's focused
            event.target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            setopenChatBox(true)
        };

        const inputField = document.getElementById('inputfeild');

        if (inputField && smallerthen650) {
            inputField.addEventListener('focus', handleInputFocus);
        }

        return () => {
            if (inputField && smallerthen650) {
                inputField.removeEventListener('focus', handleInputFocus);
            }
        };

    }, [state])

    return (
        <div className={`${state.fromChat && 'h-[80vh] lg:h-screen relative overflow-hidden'}`}>

            <div className='relative z-50'>
                <ToastContainer />
            </div>

            <div className={`mt-[60px] sm:mt-[100px]  ${chatHistoryOpen || contactOpen ? 'md:mt-[110px]' : 'md:mt-[110px]'} 2xl:mt-[120px] px-[30px] relative z-10 pb-[60px] sm:pb-[80px] 2xl:pb-[140px] ${state.fromChat && 'hidden'}`}>

                <div className='lg:hidden'>
                    <img src={backIcon} alt="" onClick={() => setcontactOpen(true)} />
                </div>

                <div
                    className='flex flex-col mb-[40px] md:hidden items-center gap-[12px] cursor-pointer rounded-[10px]'
                >
                    <div className='relative'>
                        <img src={state.image} alt="" className='rounded-full border border-[#FFF3F3] w-[100px] h-[100px]' />
                        {isUserActive && (
                            <div className='absolute top-[6px] right-[6px]'>
                                <div className='bg-[#28C95F] h-[15px] w-[15px] rounded-full' />
                            </div>
                        )}
                    </div>
                    <div>
                        <h2 className='dark:text-white text-center font-semibold text-[18px]'>
                            {state.name.length > 30 ? `${state.name.substring(0, 30)}...` : state.name}
                        </h2>
                        <h2 className='dark:text-white text-center font-medium mt-[5px] text-[10px]'>
                            {state.walletAddress}
                        </h2>

                    </div>

                </div>

                <div
                    className={`relative max-w-[545px] mx-auto h-[44px] bg-gray-800 dark:bg-[#020F32] cursor-pointer flex justify-between items-center px-[20px]  ${!openpaymentMode && 'rounded-[99px]'}`}
                    style={{
                        border: '1px solid rgba(217, 217, 217, 0.50)',
                        borderTopLeftRadius: openpaymentMode && '20px',
                        borderTopRightRadius: openpaymentMode && '20px'
                    }}
                    onClick={() => setopenpaymentMode(!openpaymentMode)}
                >
                    <div className='flex gap-[10px] items-center'>
                        <img src={card} alt="" />
                        <p
                            className='text-[15px] font-normal'
                            style={{
                                color: 'rgba(217, 217, 217, 0.50)'
                            }}
                        >
                            {paymentModes}
                        </p>
                    </div>
                    <img src={chevron} alt="" />

                    {openpaymentMode && (
                        <div className="absolute space-y-[15px] top-[44px] left-0 right-0 z-20 bg-gray-800 dark:bg-[#020F32] px-[20px] py-[20px]"
                            style={{
                                border: '1px solid rgba(217, 217, 217, 0.50)',
                                borderBottomLeftRadius: openpaymentMode && '20px',
                                borderBottomRightRadius: openpaymentMode && '20px',
                                borderTopColor: 'transparent'
                            }}
                        >
                            <p
                                className='text-[15px] font-normal px-[15px] py-[10px] rounded-[15px]'
                                style={{
                                    color: 'rgba(217, 217, 217, 0.50)',
                                    border: '1px solid rgba(217, 217, 217, 0.50)',

                                }}
                                onClick={() => setpaymentModes('SINGLE PAYMENT')}
                            >
                                SINGLE PAYMENT
                            </p>
                            <p
                                className='text-[15px] font-normal px-[15px] py-[10px] rounded-[15px]'
                                style={{
                                    color: 'rgba(217, 217, 217, 0.50)',
                                    border: '1px solid rgba(217, 217, 217, 0.50)',

                                }}
                                onClick={() => setpaymentModes('MULTI PAYMENT')}
                            >
                                MULTI PAYMENT
                            </p>

                        </div>
                    )}
                </div>
                <div className='h-[130px] mt-[20px] relative z-10'>
                    {showSugggestion ? (
                        <motion.div
                            whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                            transition={{ duration: 0.7, ease: 'easeInOut', delay: 0.2 }}
                            initial='hidden'
                            className='bg-[#020F32] h-full rounded-[10px] mx-auto max-w-[545px] relative z-10 overflow-hidden border border-[#9747FF] flex items-center'
                            viewport={{ once: true }}
                            style={{
                                opacity: 0
                            }}
                        >
                            <div className='absolute left-[-30px] top-0 bottom-0 z-20'
                            >
                                <img src={homeboxbg} alt="" />
                            </div>
                            <div className='absolute left-[-32px] top-0 bottom-0'
                            >
                                <img src={homeboxbgsecond} alt="" />
                            </div>
                            <div className='absolute right-0  top-0 '
                            >
                                <div className='relative cursor-pointer z-30'
                                    onClick={() => setshowSugggestion(false)}
                                >
                                    <img src={rectangle} alt="" className='h-[25px] md:h-[40px]' />
                                    <div className='absolute inset-0 flex items-center justify-center'>
                                        <XMarkIcon className='h-[15px] text-white' />
                                    </div>
                                </div>
                            </div>

                            <div className='relative z-20 px-[20px] flex w-full items-center gap-[45px] sm:gap-[60px] '>
                                <img src={info} alt="" />
                                <div>
                                    <h2 className='text-white font-semibold text-[11px] sm:text-[17px]'>
                                        About {paymentModes}
                                    </h2>
                                    <p className='text-[9px] sm:text-[12px] lg:text-[14px] mt-[4px] font-normal max-w-[325px] text-[#FFF3F3]'>
                                        UserA pay's for a good or service, the money is hold in the smart contract and will only be release and paid to UserB only when UserA will confirm the reception of the good or service.
                                    </p>
                                </div>
                            </div>
                        </motion.div>
                    ) : (
                        <div className='mx-auto max-w-[545px]'>
                            <InformationCircleIcon
                                className='text-white h-[17px] cursor-pointer'
                                onClick={() => setshowSugggestion(true)}
                            />
                        </div>
                    )}
                </div>
                <TokenContainer paymentModes={paymentModes} />
                {openChatBox && (
                    <ChatBox setopenChatBox={setopenChatBox} openChatBox={openChatBox} fileName={fileName} progress={progress} setfileName={setfileName} setprogress={setprogress} />
                )}
            </div>


            {chatOpen && state.fromChat && (
                <ChatBox setopenChatBox={setchatOpen} openChatBox={chatOpen} fileName={fileName} progress={progress} setfileName={setfileName} setprogress={setprogress} fromChat={state.fromChat} />
            )}

            <div className={`${state.fromChat && 'fixed bottom-0 left-0 right-0  z-40 lg:absolute'}`}>
                <div className={`bg-gray-700 dark:bg-[#020F32] w-full px-[20px] ${state.fromChat ? 'pt-[0px] lg:pt-[30px] pb-[20px] lg:pb-[50px]' : 'pt-[60px] pb-[10px] '}  sm:pb-[40px]`}>

                    <div className='max-w-[1000px] mx-auto'>
                        <form onSubmit={(e) => handleSubmit(e)} className='relative'>

                            <StyledTextFeild
                                value={message}
                                onChange={setmessage}
                                setopenChatBox={setopenChatBox}
                                img1={messagepic}
                                handleSubmit={handleSubmit}
                            />

                            <div className='absolute top-0 left-[15px] bottom-0 gap-[15px] z-20 rounded-[99px] flex items-center'>
                                <img src={messagepic} alt="" className='h-[20px] cursor-pointer'
                                    onClick={() => setopenChatBox(!openChatBox)}
                                />
                                <div>
                                    <label htmlFor="imageSelect" className='cursor-pointer'>
                                        <img src={link} alt="" className='h-[20px] cursor-pointer' />
                                    </label>
                                    <input
                                        id='imageSelect'
                                        onChange={(e) => handleChange(e)}
                                        type="file"
                                        accept=".jpg, .jpeg, .png, .gif, .doc, .docx,.pptx, .txt, .zip, .tar"
                                        className='w-0 hidden h-0'
                                    />
                                </div>
                            </div>
                            <button type='submit' className='absolute top-0 bottom-0 right-[20px] flex items-center gap-[15px] z-20 cursor-pointer'>
                                <PaperAirplaneIcon className='h-[20px] text-gray-500 active:scale-75 duration-700' />
                            </button>
                        </form>
                    </div>
                </div>
            </div>

        </div >
    )
}

export default Layout(Conversation)