import React, { useContext, useEffect, useState } from 'react'
import Layout from '../components/Hoc/Layout'

import bnb from '../assets/tokens/bnb.png'
import bsud from '../assets/tokens/bsud.png'
import eth from '../assets/tokens/eth.png'
import usdc from '../assets/tokens/usdc.png'
import usdt from '../assets/tokens/usdt.png'
import wbtc from '../assets/tokens/wbtc.png'
import StatesContext from '../context/StatesContext'
import { BUSD_ADRESS, TOKEN_ABI, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../constants/constants'
import { CircularProgress } from '@mui/material'
import { useAccount, useNetwork } from 'wagmi'
import { ethers } from 'ethers'
import { readContract } from 'wagmi/actions'


const Wallets = () => {

    const { chain } = useNetwork()

    const context = useContext(StatesContext)
    const { isDarkMode, userData } = context

    const [wetcBalance, setwetcBalance] = useState(0)
    const [bsudbalance, setbsudbalance] = useState(0)
    const [usdcBalance, setusdcBalance] = useState(0)
    const [usdtBalance, setusdtBalance] = useState(0)
    const [bnbBalance, setbnbBalance] = useState(0)
    const [loading, setloading] = useState(true)

    const { address } = useAccount()

    useEffect(() => {

        getTokenData()

    }, [address, chain])


    const getTokenData = async () => {

        try {

            setloading(true)

            if (chain.id === 97) {

                const BSUD = await readContract({
                    address: BUSD_ADRESS,
                    abi: TOKEN_ABI,
                    functionName: 'balanceOf',
                    args: [address],
                })
                // const WBNB = await readContract({
                //     address: WBNB_ADDRESS,
                //     abi: TOKEN_ABI,
                //     functionName: 'balanceOf',
                //     args: [address],
                // })

                setbsudbalance(ethers.utils.formatUnits(BSUD.toString(), 'ether'))
                // setbnbBalance(ethers.utils.formatUnits(WBNB.toString(), 'ether'))
                setloading(false)

            } else {

                const WBTC = await readContract({
                    address: WBTC_ADDRESS,
                    abi: TOKEN_ABI,
                    functionName: 'balanceOf',
                    args: [address],
                })
                // const USDC = await readContract({
                //     address: USDC_ADDRESS,
                //     abi: TOKEN_ABI,
                //     functionName: 'balanceOf',
                //     args: [address],
                // })
                // const USDT = await readContract({
                //     address: USDT_ADDRESS,
                //     abi: TOKEN_ABI,
                //     functionName: 'balanceOf',
                //     args: [address],
                // })

                setwetcBalance(ethers.utils.formatUnits(WBTC.toString(), 'ether'))
                // setusdcBalance(ethers.utils.formatUnits(USDC.toString(), 'ether'))
                // setusdtBalance(ethers.utils.formatUnits(USDT.toString(), 'ether'))
                setloading(false)

            }

        } catch (error) {

        } finally {
            setloading(false)
        }
    }

    return (
        <div className='flex justify-center px-[20px] mb-[30px] mt-[150px] md:mt-[100px]'>
            <div className='w-full sm:w-[80%] lg:w-[600px] rounded-[15px] '
                style={{
                    border: '1px solid #9747FF',
                    background: isDarkMode ? 'rgba(2, 15, 50, 0.50)' : 'rgba(2, 15, 50, 0.90)',
                    boxShadow: '0px 4px 4px 0px rgba(12, 140, 233, 0.22)',
                    backdropFilter: 'blur(4.5px)'
                }}
            >
                <div className='px-[16px] py-[19px] min-h-[430px]'>
                    <h2 className='text-white text-center text-[25px] font-bold'>
                        Wallet Address
                    </h2>
                    <p className='text-gray-300 text-[12px] mt-[6px] break-words font-semibold text-center'>
                        {userData.walletAddress}
                    </p>
                    {loading ? (
                        <div className='flex justify-center items-center h-full mt-[120px]'>
                            <CircularProgress sx={{ color: 'white' }} />
                        </div>
                    ) : (

                        <div className='flex flex-col items-center space-y-[15px] mt-[30px] mb-[15px]'>
                            <div
                                className={`${chain && chain.id === 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={wbtc} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        WBTC
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    {wetcBalance}
                                </h2>
                            </div>
                            <div
                                className={`${chain && chain.id === 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={eth} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        ETH
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    80
                                </h2>
                            </div>
                            <div
                                className={`${chain && chain.id !== 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={bsud} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        BSUD
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    {bsudbalance}
                                </h2>
                            </div>
                            <div
                                className={`${chain && chain.id === 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={usdc} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        USDC
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    {usdcBalance}
                                </h2>
                            </div>
                            <div
                                className={`${chain && chain.id === 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={usdt} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        USDT
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    {usdtBalance}
                                </h2>
                            </div>
                            <div
                                className={`${chain && chain.id !== 97 ? 'hidden' : 'flex'} items-center w-full lg:w-[350px] hover:scale-95 duration-700 gap-[7px] justify-between rounded-[10px] px-[16px] py-[5px] bg-[#0C8CE9]`}>
                                <div className='flex items-center gap-[7px]'>
                                    <img src={bnb} alt="" />
                                    <h2 className='text-white text-[14px] font-bold'>
                                        BNB
                                    </h2>
                                </div>
                                <h2 className='text-white font-bold text-[14px]'>
                                    {bnbBalance}
                                </h2>
                            </div>
                        </div>
                    )}

                </div>
            </div>
        </div>
    )
}

export default Layout(Wallets)