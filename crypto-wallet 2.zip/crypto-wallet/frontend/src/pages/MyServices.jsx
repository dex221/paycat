import React, { useContext, useState } from 'react'
import StatesContext from '../context/StatesContext'
import MarketplaceCard from '../components/MarketplaceCard'
import Layout from '../components/Hoc/Layout'
import { useGetAllServicesOfUserQuery, useGetCoinsPriceUSDQuery } from '../helpers/ServiceApi'
import { CircularProgress, Pagination } from '@mui/material'
import CreateService from '../components/Modals/CreateService/CreateService'
import DeleteConfirmation from '../components/Modals/DeleteConfirmation'

const MyServices = () => {

    const context = useContext(StatesContext)
    const { contactOpen, chatHistoryOpen, userData, isDarkMode } = context

    const [page, setpage] = useState(1)
    const [open, setopen] = useState(false)
    const [serviceDetailOpen, setserviceDetailOpen] = useState(false)
    const [serviceData, setserviceData] = useState('')
    const [serviceId, setserviceId] = useState('')

    let userId = (userData && userData._id && userData._id) || ''

    const { data, isFetching , isLoading } = useGetAllServicesOfUserQuery({ userId, page })
    const { data: CoinsPrice, isFetching: CoinPriceLoading } = useGetCoinsPriceUSDQuery()

    return (
        <div className='px-[30px] pb-[30px] pt-[70px]  max-w-[1540px] mx-auto'>
            <h2 className='dark:text-white  font-bold text-[18px] sm:text-[26px] text-center'>
                My Services
            </h2>
            {serviceDetailOpen && (
                <CreateService setcreateServiceOpen={setserviceDetailOpen} serviceData={serviceData} isEditService={true} open={serviceDetailOpen} />
            )}

            {open && (
                <DeleteConfirmation open={open} setopen={setopen} serviceId={serviceId} />
            )}

            {isLoading ? (
                <div className='flex justify-center items-center mt-[180px] xl:mt-[200px]'>
                    <CircularProgress sx={{ color: isDarkMode && 'white' }} />
                </div>
            ) : (
                <div className={`grid grid-cols-1 sm:grid-cols-2  ${contactOpen || chatHistoryOpen ? 'xl:grid-cols-3 lg:grid-cols-2' : 'xl:grid-cols-4 lg:grid-cols-3'} 2xl:grid-cols-4 gap-[40px] xl:gap-[45px] 2xl:gap-[60px] mt-[37px]`}>
                    {data.services.map((item, i) => (
                        <div key={i}>
                            <div onClick={() => {
                                setserviceData(item)
                                setserviceDetailOpen(true)
                            }} className='relative z-10'>
                                <MarketplaceCard serviceData={item} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} myServices={true} setdeleteOpen={setopen} setserviceId={setserviceId}/>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <div className='flex justify-center mt-[20px]'>
                {!isFetching && data && data.resultPerPage < data.filteredServicesCount && (

                    <Pagination color='primary' size='medium'
                        count={Math.ceil(data.totalServicesCount / data.resultPerPage)}
                        page={page}
                        onChange={(event, value) => setpage(value)}
                        onClick={() => window.scrollTo(0, 0)}
                        sx={{
                            '& .MuiPaginationItem-icon, & .MuiPaginationItem-root': {
                                color: 'white',
                                border: '1px solid #0C8CE9',
                                borderRadius: '50px',
                                backgroundColor: '#122758'
                            },
                        }}

                    />
                )}
            </div>

            {!isFetching && data.services.length === 0 && (
                <div className='mt-[180px] pb-[60px] lg:pb-0  xl:mt-[200px]'>
                    <p className="text-center text-[12px] underline underline-offset-8 dark:text-gray-400 ">
                        No services found
                    </p>
                </div>
            )}

        </div>
    )
}

export default Layout(MyServices)