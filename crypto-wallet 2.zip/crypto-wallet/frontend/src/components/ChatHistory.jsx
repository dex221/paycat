import { useContext, useEffect, useRef, useState } from 'react'
import { ChatBubbleLeftIcon, PencilIcon, PencilSquareIcon, XMarkIcon } from '@heroicons/react/24/solid'
import StatesContext from '../context/StatesContext'
import searchicon from '../assets/searchicon.png'
import TimeAgo from 'react-timeago'
import { CircularProgress, useMediaQuery } from '@mui/material'
import { useAllConversationsHistoryQuery } from '../helpers/contactApi'
import { useLocation, useNavigate } from 'react-router-dom'


const ChatHistory = () => {
    const context = useContext(StatesContext);
    const { onlineUsers, setchatHistoryOpen, userData, lastMessage, allConversations, setallConversations, notifications, setcontactOpen, setisComingFromChat } = context;

    const [filterConversations, setfilterConversations] = useState('')
    const [chatFound, setchatFound] = useState(false)
    const [search, setsearch] = useState('')

    const { data, isLoading, refetch } = useAllConversationsHistoryQuery((userData && userData._id && userData._id) || '');
    const smallerthen640 = useMediaQuery('(max-width:640px)')
    const smallerthen768 = useMediaQuery('(max-width:768px)')

    let { pathname } = useLocation()
    const location = pathname.split('/')[1] === 'conversation'

    const navigate = useNavigate()


    useEffect(() => {
        if (data && data.friends) {
            if (!allConversations) {
                setallConversations(data.friends);
                setchatFound(true)
            }
        }
    }, [data])

    useEffect(() => {
        if (allConversations) {
            // Create a hash map to store conversations by conversationId
            const conversationMap = new Map();

            // Iterate through allConversations to populate the map
            allConversations.forEach(conversation => {
                if (!conversationMap.has(conversation.conversation)) {
                    conversationMap.set(conversation.conversation, conversation);
                }
            });

            // Apply search filtering if search is active
            let filteredConversations = [...conversationMap.values()];
            if (search) {
                filteredConversations = filteredConversations.filter(conversation =>
                    conversation.userData.name.toLowerCase().includes(search.toLowerCase())
                );
            }

            // Sort the conversations and update the filterConversations state
            const sortedConversations = filteredConversations.sort(
                (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
            );
            setfilterConversations(sortedConversations);
        } else {
            setfilterConversations([]);
        }
    }, [allConversations, search]);

    useEffect(() => {
        if (allConversations && lastMessage) {

            const conversationIdExists = allConversations.some((item) => item.conversation === lastMessage.conversationId)

            if (conversationIdExists) {
                setallConversations(prev => prev.map(conversation => {
                    if (lastMessage.conversationId === conversation.conversation) {
                        return {
                            ...conversation,
                            message: lastMessage.message,
                            createdAt: lastMessage.createdAt
                        };
                    }
                    return conversation;
                }));
            } else {
                setallConversations(prev => [lastMessage, ...prev])
            }

        }
    }, [lastMessage])

    useEffect(() => {
        if (notifications && allConversations) {

            const reversedNotifications = [...notifications].reverse();

            const conversationUpdates = {};

            reversedNotifications.forEach((notification) => {
                if (notification.type === 'Unread') {
                    let isConversationExists = allConversations.some((item) => item.conversation === notification.conversationId)
                    if (!isConversationExists) {

                        setallConversations((prev) => [{
                            conversation: notification.conversationId,
                            message: notification.message,
                            createdAt: notification.createdAt,
                            userData: {
                                _id: notification.senderId._id,
                                name: notification.senderId.name,
                                image: notification.senderId.image,
                                walletAddress: notification.senderId.walletAddress
                            },
                            unreadCount: 0
                        }, ...prev]);

                    } else {

                        conversationUpdates[notification.conversationId] = {
                            unreadCount: (conversationUpdates[notification.conversationId]?.unreadCount || 0) + 1,
                            message: notification.message,
                            createdAt: notification.createdAt
                        };
                    }
                }
            });

            setallConversations(prev => prev.map(conversation => {
                const update = conversationUpdates[conversation.conversation];
                if (update) {
                    return {
                        ...conversation,
                        ...update
                    };
                }
                return {
                    ...conversation,
                    unreadCount: 0
                };
            }));
        }
    }, [notifications, chatFound]);

    useEffect(() => {
        refetch()
    }, [])

    return (
        <div
            className={`${location && 'lg:fixed top-0 left-0'} min-h-screen lg:border-r border-[#D9D9D9]`}
        >
            <div
                className={`fixed top-0 right-0 bottom-0 min-h-screen dark:bg-[#020F32] bg-gray-700 dark:lg:bg-transparent w-full flex-shrink-0 lg:w-[250px] md:relative z-40  ${location && 'lg:ml-[140px] xl:ml-[145px] 2xl:ml-[170px]'}`}
            >            <div className='w-full border-b border-[#D9D9D9] flex justify-between items-center py-[24px] 2xl:py-[26px] px-[15px]'>
                    <div className='flex items-center gap-[10px] '>
                        <ChatBubbleLeftIcon
                            className='text-white h-[25px] 2xl:h-[32px]'
                        />
                        <h5 className='text-[#F1F1F1] text-[18px] 2xl:text-[20px] font-medium'>
                            Chats
                        </h5>
                    </div>
                    <div className='flex items-center gap-[20px]'>
                        <PencilSquareIcon
                            className='text-white h-[25px] 2xl:h-[32px] cursor-pointer'
                            onClick={() => {
                                setchatHistoryOpen(false)
                                setcontactOpen(true)
                                setisComingFromChat(true)
                            }}
                        />
                        <XMarkIcon
                            onClick={() => {
                                setchatHistoryOpen(false)
                                navigate('/')
                            }}
                            className='w-[30px] text-white lg:hidden'
                        />
                    </div>
                </div>

                <div className='relative h-[37px] 2xl:h-[40px] mt-[15px] mx-[20px]'>
                    <input
                        type="text"
                        value={search}
                        onChange={(e) => setsearch(e.target.value)}
                        className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                        placeholder='Search...'
                        style={{
                            border: '1px solid rgba(217, 217, 217, 0.50)'
                        }}
                    />
                    <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                        <img src={searchicon} alt="" className='h-[16px]' />
                    </div>
                </div>

                <div className='mt-[35px] md:mt-[25px] '>
                    {isLoading ? (
                        <div className='flex justify-center mt-[200px]'>
                            <CircularProgress sx={{ color: 'white' }} size={34} />
                        </div>
                    ) : (
                        <div className='h-[400px] sm:h-[450px] 2xl:h-[600px] overflow-y-auto '>
                            {filterConversations && filterConversations.length > 0 ? (
                                filterConversations.map((item, i) => {

                                    let isActive = false

                                    if (onlineUsers) {
                                        isActive = onlineUsers.some((data) => data.userId === item.userData.walletAddress);
                                    }

                                    return (
                                        <div className='overflow-hidden' key={i}>
                                            <div className='flex items-center justify-between px-[35px] md:px-[10px] py-[15px] sm:border-b border-gray-700 hover:bg-slate-800 duration-500 cursor-pointer'
                                                onClick={() => {
                                                    navigate(`/conversation/${item.conversation} `, {
                                                        state: {
                                                            name: item.userData.name,
                                                            image: item.userData.image,
                                                            walletAddress: item.userData.walletAddress,
                                                            id: item.userData._id,
                                                            fromChat: true
                                                        }
                                                    })
                                                    if (smallerthen768) {
                                                        setchatHistoryOpen(false)
                                                    }
                                                }}
                                            >
                                                <div
                                                    className='flex items-center gap-[12px] cursor-pointer rounded-[10px]'

                                                >
                                                    <div className='relative w-[36px] h-[36px]'>
                                                        <img src={item.userData.image} alt="" className='rounded-full h-full w-full object-cover border border-[#FFF3F3] ' />
                                                        {isActive && (
                                                            <div className='absolute top-0 right-0'>
                                                                <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div>
                                                        <h2 className='text-white font-semibold text-[11px]'>
                                                            {item.userData.name.length > 25 ? `${item.userData.name.substring(0, 25)}...` : item.userData.name}
                                                        </h2>
                                                        <div>
                                                            <h2 className={`font-semibold text-[10px] break-words mt-[5px] line-clamp-2`}
                                                                style={{
                                                                    color: item.unreadCount > 0 ? 'white' : 'rgba(217, 217, 217, 0.50)'
                                                                }}
                                                            >
                                                                {(!smallerthen640 && item.message) && (item.message.length > 23 ? `${item.message.substring(0, 23)}...` : item.message)}
                                                                {(smallerthen640 && item.message) && (item.message.length > 30 ? `${item.message.substring(0, 30)}...` : item.message)}

                                                            </h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='flex justify-center items-center flex-col gap-[8px]'>
                                                    {item.unreadCount > 0 && (
                                                        <div className='w-[20px] h-[14px] bg-[#038AE8] rounded-[699px] flex justify-center items-center'>
                                                            <h2 className='text-white text-[8px] font-bold '>
                                                                {item.unreadCount}
                                                            </h2>
                                                        </div>
                                                    )}
                                                    <TimeAgo
                                                        date={new Date(item.createdAt)}
                                                        className="text-[#038AE8] text-[8px] font-light text-center"
                                                    />
                                                </div>
                                            </div>
                                            <div className='w-full ml-[83px] sm:hidden h-[1px] bg-gray-700' />
                                        </div>
                                    );
                                })
                            ) : (
                                <div>
                                    {filterConversations && filterConversations.length === 0 && (
                                        <p className='text-white text-center text-[12px] mt-[200px]'>No chats found!</p>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChatHistory;
