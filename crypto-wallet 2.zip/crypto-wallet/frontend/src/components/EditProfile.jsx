import React, { useContext, useState } from 'react'
import edit from '../assets/edit.png'
import search from '../assets/search.png'
import { motion } from 'framer-motion';
import { BACKEND_URL } from '../constants/constants';
import { CircularProgress } from '@mui/material';
import StatesContext from '../context/StatesContext';
import { XMarkIcon } from '@heroicons/react/24/solid'


const EditProfile = ({ seteditProfileOpen }) => {


    const context = useContext(StatesContext)
    const { setuserData, userData } = context

    const [name, setname] = useState(userData.name && userData.name)
    const [presentImage, setpresentImage] = useState(userData.image && userData.image)
    const [avatar, setavatar] = useState('')
    const [loading, setloading] = useState(false)


    const handleImageChnage = (e) => {

        const reader = new FileReader()
        reader.onload = () => {
            if (reader.readyState === 2) {
                setpresentImage(reader.result)
                setavatar(reader.result)
            }
        }
        reader.readAsDataURL(e.target.files[0])
    }

    const CloudinaryUploader = async (file) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('upload_preset', 'ojipiz6u');
        const rqst = await fetch(`https://api.cloudinary.com/v1_1/${import.meta.env.VITE_API_CLOUD_NAME}/auto/upload`, {
            method: 'POST',
            body: formData,
        })

        const res = await rqst.json()
        return {
            imageUrl: res.secure_url
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault()
        setloading(true)

        try {

            let image = presentImage
            if (avatar) {
                const { imageUrl } = await CloudinaryUploader(avatar)
                image = imageUrl
            }

            const token = sessionStorage.getItem('Token');

            const response = await fetch(`${BACKEND_URL}/api/user/update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ name, image })
            });
            let { success, user } = await response.json();

            if (success) {
                setuserData(user)
            }

        } catch (e) {
            console.log(e)
        }

        finally {
            setloading(false)
            seteditProfileOpen(false)
        }

    }

    return (
        <motion.div
            whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
            transition={{ duration: 0.7, ease: 'easeInOut' }}
            initial='hidden'
            viewport={{ once: true }}
            className='absolute top-0 bottom-0 z-10 sm:top-[-10px] right-0 left-0 sm:left-[-10px] flex justify-center sm:justify-start items-center sm:items-start '
            style={{
                opacity: 0
            }}
        >
            <div
                className='w-[280px] relative sm:w-[305px] z-20 p-[26px] bg-[#020F32]'
                style={{
                    boxShadow: '0px 0px 6px 1px rgba(12, 140, 233, 0.74)',
                }}
            >
                <div className='absolute right-[12px] top-[12px]'>
                    <XMarkIcon className='cursor-pointer h-[20px] text-white'
                        onClick={() => seteditProfileOpen(false)}
                    />
                </div>

                <h2 className='text-white text-[20px] font-bold'>
                    Edit my profile
                </h2>
                <div className='relative  mt-[20px] mb-[15px] w-[103px] h-[103px] mx-auto'>
                    <img src={presentImage} alt="" className=' h-full w-full object-cover rounded-full border border-[#0C8CE9]'
                    />
                    <div className='absolute bottom-[5px] right-0'>
                        <label htmlFor="imageSelect" className='cursor-pointer'>
                            <img src={edit} alt="" />
                        </label>
                        <input
                            onChange={(e) => handleImageChnage(e)}
                            id='imageSelect' type="file" accept=".jpg, .jpeg, .png, .gif" className='hidden' />
                    </div>
                </div>
                <form onSubmit={(e) => handleSubmit(e)}>
                    <div className='relative'>
                        <input
                            type="text"
                            className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[35px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                            placeholder='Name'
                            value={name}
                            onChange={(e) => setname(e.target.value)}
                            style={{
                                border: '1px solid rgba(217, 217, 217, 0.50)'
                            }}
                        />
                        <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                            <img src={search} alt="" className='h-[13px]' />
                        </div>
                    </div>
                    <button
                        className='rounded-[10px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700  w-full h-[25px] text-[14px] font-bold text-white mt-[10px]'
                        type='submit'
                    >
                        {loading ? <CircularProgress size={19} sx={{ color: 'white' }} /> : 'Save'}
                    </button>
                </form>
            </div>
        </motion.div>
    )
}

export default EditProfile