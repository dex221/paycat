import React, { useContext, useEffect, useState } from 'react'
import bnb from '../assets/tokens/bnb.png'
import bsud from '../assets/tokens/bsud.png'
import eth from '../assets/tokens/eth.png'
import usdc from '../assets/tokens/usdc.png'
import usdt from '../assets/tokens/usdt.png'
import wbtc from '../assets/tokens/wbtc.png'

import tag from '../assets/tag.png'
import StatesContext from '../context/StatesContext'
import { useLocation } from 'react-router-dom'
import { useAddPaymentNotificationsMutation, useAddScheduleNotificationMutation } from '../helpers/notificationApi'
import { CircularProgress, TextField } from '@mui/material'

import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import dayjs, { Dayjs } from 'dayjs';
import { LocalizationProvider, DateTimePicker } from '@mui/x-date-pickers'
import { StyledCalendar } from './style'
import { BUSD_ADRESS, TOKEN_ABI, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../constants/constants'
import { useAccount, useNetwork } from 'wagmi'
import { ethers } from 'ethers'
import { readContract } from 'wagmi/actions'



const data = [
    {
        name: 'WBTC',
        img: wbtc
    },
    {
        name: 'ETH',
        img: eth
    },
    {
        name: 'BSUD',
        img: bsud
    },
    {
        name: 'USDC',
        img: usdc
    },
    {
        name: 'USDT',
        img: usdt
    },
    {
        name: 'BNB',
        img: bnb
    },
]

const TokenContainer = ({ paymentModes }) => {

    const { chain } = useNetwork()

    const [activeToken, setactiveToken] = useState('WBTC')
    const [amount, setamount] = useState('')
    const [DeadlinesNo, setDeadlinesNo] = useState('')
    const [successMxg, setsuccessMxg] = useState('')

    const [selectedDate, setselectedDate] = useState(
        dayjs(new Date(new Date().getTime() + 900000)),

    )

    const { state } = useLocation()

    const context = useContext(StatesContext)
    const { isDarkMode, setnotifications, setisApprovedFailed, seterror } = context
    const [loading, setloading] = useState(false)

    const [addPayment, res] = useAddPaymentNotificationsMutation()
    const [schedulePayment, response] = useAddScheduleNotificationMutation()

    const { address } = useAccount()

    const handleSubmit = async (e) => {

        e.preventDefault()
        setloading(true)
        setsuccessMxg('')

        let value = amount

        if (paymentModes === 'MULTI PAYMENT') {
            value = amount / DeadlinesNo
        }

        if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
            if (chain && chain.id === 97) {
                seterror('Switch you network to Ethereum')
                setloading(false)
                return
            }
        } else {
            if (chain && chain.id !== 97) {
                seterror('Switch you network to BNB Smart Chain')
                setloading(false)
                return
            }
        }

        try {

            let tokenAddress = '';

            switch (activeToken) {
                case 'WBTC':
                    tokenAddress = WBTC_ADDRESS
                    break;
                case 'ETH':
                    tokenAddress = WBTC_ADDRESS
                    break;
                case 'BSUD':
                    tokenAddress = BUSD_ADRESS
                    break;
                case 'USDT':
                    tokenAddress = USDT_ADDRESS
                    break;
                case 'BNB':
                    tokenAddress = WBNB_ADDRESS
                    break;
                case 'USDC':
                    tokenAddress = USDC_ADDRESS
                    break;
                default:
                    break;
            }

            const tokenValue = await readContract({
                address: tokenAddress,
                abi: TOKEN_ABI,
                functionName: 'balanceOf',
                args: [address],
            })


            const requiredAmount = ethers.utils.parseUnits(value.toString(), 'ether');

            if (Number(tokenValue) < Number(requiredAmount.toString())) {
                setisApprovedFailed(true)
                setloading(false)
                return;
            }

            if (paymentModes === 'MULTI PAYMENT') {
                schedulePayment({ senderId: state.id, amount: value, DeadlinesNo, sheduleDate: selectedDate, tokenName: activeToken })
            } else {
                addPayment({ amount, id: state.id, tokenName: activeToken })
            }


        } catch (error) {
            setisApprovedFailed(true)
            setloading(false)
        }

    }

    useEffect(() => {

        if (res.status === 'fulfilled') {

            setamount('')
            setloading(false)
            setsuccessMxg('Please approve this transaction in your notification tab!')


            const data = {
                amount,
                senderId: {
                    name: state.name,
                    walletAddress: state.walletAddress,
                    image: state.image,
                    _id: state.id,
                },
                type: 'approvals',
                isSeen: false,
                createdAt: new Date(res.data.createdAt),
                tokenName: activeToken
            }

            setnotifications(prev => [data, ...prev])
            setTimeout(() => {
                setsuccessMxg('')
            }, 4000);
        }
    }, [res])


    useEffect(() => {
        if (response.status === 'fulfilled') {
            setsuccessMxg('Payment has been scheduled successfully!')
            setamount('')
            setDeadlinesNo('')
            setloading(false)

            const data = {
                message: `You have scheduled ${amount / DeadlinesNo} ${activeToken} to Mr`,
                senderId: {
                    name: state.name,
                    walletAddress: state.walletAddress,
                    image: state.image,
                    _id: state.id,
                },
                type: 'scheduled',
                isSeen: false,
                createdAt: new Date(response.data.createdAt),
                scheduledAt: selectedDate,
                tokenName: activeToken
            }

            setnotifications(prev => [data, ...prev])

            setTimeout(() => {
                setsuccessMxg('')
            }, 4000);
        }
    }, [response])


    return (
        <div className='max-w-[1000px] rounded-[15px]  mx-auto mt-[15px]'
            style={{
                border: '1px solid #9747FF',
                background: isDarkMode ? 'rgba(2, 15, 50, 0.50)' : 'rgba(2, 15, 50, 0.90)',
                boxShadow: '0px 4px 4px 0px rgba(12, 140, 233, 0.22)',
                backdropFilter: 'blur(4.5px)'
            }}
        >
            <div className='grid grid-cols-1 lg:grid-cols-2 '>
                <div className='px-[16px] py-[19px]'>
                    <h2 className='text-white text-center text-[16px] font-medium'>
                        {paymentModes}
                    </h2>
                    <h6 className='text-white text-center lg:text-start text-[16px] font-normal mt-[10px]'>
                        Select your token
                    </h6>
                    <div className='flex flex-col items-center lg:items-start space-y-[15px] mt-[15px]'>
                        {data.map((item, i) => (
                            <button key={i}
                                onClick={() => setactiveToken(item.name)}
                                className={`flex items-center w-[208px] gap-[7px] rounded-[10px] px-[16px] py-[5px] ${activeToken === item.name ? 'bg-[#B613C7]' : 'bg-[#0C8CE9]'}`}>
                                <img src={item.img} alt="" />
                                <h2 className='text-white text-[14px] font-bold'>
                                    {item.name}
                                </h2>
                            </button>
                        ))}
                    </div>
                </div>
                <div
                    style={{
                        background: 'rgba(182, 19, 199, 0.10)'
                    }}
                    className='flex px-[20px] py-[40px] lg:p-[20px] items-center justify-center'
                >
                    <form onSubmit={(e) => handleSubmit(e)} className={`w-full xl:w-[80%] ${paymentModes !== 'MULTI PAYMENT' && 'md:mt-[40px]'}`}>
                        <div className='relative'>
                            <input
                                type="number"
                                required
                                value={amount}
                                onChange={(e) => setamount(e.target.value)}
                                className='h-full w-full outline-none rounded-[99px] mb-[20px] px-[20px] relative z-20 bg-transparent text-[15px] font-medium py-[10px] placeholder:text-[#D9D9D980] text-white'
                                placeholder='Enter token amount...'
                                style={{
                                    border: '1px solid rgba(217, 217, 217, 0.50)'
                                }}
                            />

                        </div>

                        {paymentModes === 'MULTI PAYMENT' && (
                            <div>
                                <StyledCalendar>
                                    <div className='relative'>
                                        <LocalizationProvider dateAdapter={AdapterDayjs} >
                                            <DateTimePicker
                                                value={selectedDate}
                                                minutesStep={5}
                                                minDate={new Date()}
                                                onChange={setselectedDate}
                                                DialogProps
                                                inputProps={{ readOnly: true }}
                                                renderInput={(params) => <TextField required  {...params} fullWidth />}
                                            />

                                        </LocalizationProvider>
                                        <div className='absolute top-[-10px] left-[14px] rounded-[20px]'>
                                            <h2 className='text-[11px] text-white'>
                                                Deadline Date
                                            </h2>
                                        </div>
                                    </div>
                                </StyledCalendar>

                                <div className='relative my-[20px]'>
                                    <input
                                        type="number"
                                        className='h-full w-full outline-none rounded-[99px] px-[20px] pl-[56px] relative z-20 bg-transparent text-[15px] font-medium py-[10px] placeholder:text-[#D9D9D980] text-white'
                                        placeholder='No of Deadlines'
                                        required
                                        value={DeadlinesNo}
                                        onChange={(e) => setDeadlinesNo(e.target.value)}
                                        style={{
                                            border: '1px solid rgba(217, 217, 217, 0.50)'
                                        }}
                                    />
                                    <div className='absolute top-[5px] left-[25px] bottom-0 right-0  rounded-[99px] flex items-center'>
                                        <img src={tag} alt="" className='h-[20px]' />
                                    </div>
                                </div>
                            </div>
                        )}
                        {successMxg && (
                            <h2 className='text-green-500 text-[12px] mb-[10px] font-medium'>
                                {successMxg}
                            </h2>
                        )}
                        <button type='submit'
                            className='w-full h-[45px] disabled:cursor-not-allowed sm:h-[54px] lg:mb-0 text-[12px] sm:text-[14px] font-bold rounded-[10px] text-white bg-[#B613C7]'
                            disabled={loading}
                        >
                            {loading ? <CircularProgress sx={{ color: 'white' }} size={23} /> : ' CONFIRM PAYMENT'}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default TokenContainer