import React, { useContext, useEffect, useState } from 'react'
import smile from '../assets/marketplace/smile.png'
import { CircularProgress, Rating, useMediaQuery } from '@mui/material'
import { useCreateReviewsMutation, useGetReviewCheckQuery, useGetReviewsQuery } from '../helpers/ServiceApi'

import TimeAgo from 'react-timeago'
import StatesContext from '../context/StatesContext'

const ReviewsContainer = ({ serviceId, userId }) => {

    const context = useContext(StatesContext)
    const { userData, seterror, walletConnected, success } = context

    const [page, setpage] = useState(1)
    const [reviews, setreviews] = useState('')
    const [isRatingUpdated, setisRatingUpdated] = useState(false)

    const [rating, setRating] = useState(0);
    const [comment, setcomment] = useState('')

    const smallerthen640 = useMediaQuery('(max-width:640px)')

    let bookedBy = (userData && userData._id) || ''


    const { data, isFetching } = useGetReviewsQuery({ serviceId, page })
    const { data: reviewCheck, isLoading, refetch } = useGetReviewCheckQuery({ bookedBy, serviceId })
    const [createReview, res] = useCreateReviewsMutation()

    const handleRatingChange = (event, newValue) => {
        setRating(newValue);
    };

    const handleSubmit = (e) => {
        e.preventDefault()

        if (rating === 0) {
            seterror('Rating is required')
            return
        }

        createReview({ ratedTo: userId, serviceId, rating, comment })

    }
    useEffect(() => {

        if (data) {
            if (!reviews || isRatingUpdated) {
                setpage(1)
                setreviews(data)
                setisRatingUpdated(false)
            } else {
                setreviews((prev) => {
                    return {
                        ...prev,
                        reviews: [...prev.reviews, ...data.reviews],
                    };
                });
            }
        }

    }, [data])

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setisRatingUpdated(true)
        }

        if (success === 'Order approved successfully') {
            refetch()
        }

    }, [res, success])



    return (
        <div>
            {!reviews || isLoading ? (
                <div className='flex justify-center my-[40px]'>
                    <CircularProgress sx={{ color: 'white' }} size={35} />
                </div>
            ) : (

                <div>
                    {/* <div className={`${reviewCheck && !reviewCheck.canReview && 'hidden'}`}>
                        <div className='flex justify-between items-center'>
                            <h2 className='text-[15px] font-bold text-white '>
                                Rate this article
                            </h2>
                            <Rating name="read-only"
                                precision={0.5}
                                value={rating}
                                onChange={handleRatingChange}
                                style={{
                                    color: '#9747FF',
                                    fontSize: smallerthen640 ? '30px' : '25px'

                                }}
                                sx={{
                                    '& .MuiRating-iconEmpty': {
                                        color: '#9747FF',  // Change color of non-active star
                                        borderColor: '#9747FF !important', // Change border color of non-active star
                                    },
                                }}
                            />
                        </div>
                        <form onSubmit={(e) => handleSubmit(e)}>
                            <div className='mt-[25px] relative'>
                                <textarea
                                    className='w-full px-[18px] py-[10px] h-[120px] rounded-[10px] bg-transparent outline-none text-white placeholder:text-[#D9D9D980] text-[15px]  font-normal'
                                    placeholder='Type the Your comment . . .'
                                    required
                                    value={comment}
                                    onChange={(e) => setcomment(e.target.value)}
                                    maxLength={800}
                                    style={{
                                        border: '1px solid rgba(217, 217, 217, 0.50)',
                                        resize: 'none'
                                    }}
                                />
                                <div className='absolute bottom-[18px] right-[10px]'>
                                    <img src={smile} alt="" />
                                </div>
                            </div>
                            <div className='flex justify-end'>
                                <button
                                    className='h-[29px] sm:h-[32px] w-[130px] cursor-not-allowed sm:w-[150px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[11px] sm:text-[13px]  font-bold rounded-[10px] text-white'
                                    type='submit'
                                    disabled={!walletConnected || res.isLoading}
                                >
                                    {res.isLoading ? <CircularProgress sx={{ color: 'white' }} size={18} /> : ' Post your comment'}
                                </button>
                            </div>
                        </form>
                    </div> */}

                    {/* ratings */}
                    <div className='mt-[15px]'>
                        <h2 className={`text-[15px] font-bold text-white ${reviews && reviews.reviews.length === 0 && 'hidden'}`}>
                            Others rates
                        </h2>
                        {reviews && reviews.reviews.length > 0 && (
                            <div>
                                <div className='mt-[10px] border border-[#122758] p-[10px] rounded-[10px] md:max-h-[500px] xl:max-h-[600px] md:overflow-y-auto'>
                                    {reviews.reviews.map((item, i) => (
                                        <div key={i}>
                                            <div className='flex items-center justify-between'>
                                                <div className='flex items-center gap-[5px]'>
                                                    <img src={item.ratedBy.image} alt="" className={`object-cover rounded-full  border-[2px] border-[#9747FF]  w-[25px] h-[25px]`} />
                                                    <div>
                                                        <h2 className={` font-normal text-white text-[11px]`}>
                                                            {item.ratedBy.name}
                                                        </h2>
                                                        <h6 className='text-white text-[8px]'>
                                                            {item.ratedBy.walletAddress.substring(0, 15)}...
                                                        </h6>
                                                    </div>
                                                </div>
                                                <div className=' flex flex-col gap-[9px] justify-center'>
                                                    <Rating name="read-only" value={item.rating} precision={0.5} readOnly
                                                        style={{
                                                            color: '#9747FF',
                                                            fontSize: '13px'

                                                        }}
                                                        sx={{
                                                            '& .MuiRating-iconEmpty': {
                                                                color: '#9747FF',  // Change color of non-active star
                                                                borderColor: '#9747FF !important', // Change border color of non-active star
                                                            },
                                                        }}
                                                    />
                                                    <TimeAgo
                                                        date={new Date(item.createdAt)}
                                                        className='text-[10px] mt-[-8px] font-light text-right '
                                                        style={{
                                                            color: 'rgba(217, 217, 217, 0.50)'
                                                        }} />
                                                </div>
                                            </div>
                                            <h2 className=' text-[12px] text-white font-normal line-clamp-3 break-words w-[99%] mt-[5px] leading-[15px] max-w-[340px] xl:max-w-[440px]'>
                                                {item.comment}
                                            </h2>
                                            <div className='h-[1px] w-[100px] mx-auto bg-[#038AE8] my-[11px]' />
                                        </div>
                                    ))}
                                </div>

                                {!isFetching && reviews && page < reviews.totalPages && (
                                    <div className='my-[20px] flex justify-center'>
                                        <h2 className='text-center text-[14px] text-white bg-gray-700 w-fit px-[15px] py-[4px] rounded-[5px] cursor-pointer'
                                            onClick={() => setpage(prev => prev + 1)}
                                        >
                                            Show More
                                        </h2>
                                    </div>
                                )}

                                {isFetching && (
                                    <div className='my-[20px] flex justify-center'>
                                        <CircularProgress sx={{ color: 'white' }} size={29} />
                                    </div>
                                )}

                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}

export default ReviewsContainer