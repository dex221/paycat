import { TextField } from '@mui/material'
import React from 'react'

const StyledTextFeild = ({ value, onChange, setopenChatBox, handleSubmit }) => {

    const handleKeyPress = (event) => {
        if (event.key === 'Enter') {
            handleSubmit(event)
        }
    }

    return (
        <TextField
            placeholder={'Type a message'}
            required={true}
            value={value}
            fullWidth
            multiline={true}
            id='inputfeild'
            minRows={1}
            maxRows={3}
            onKeyDown={(e) => handleKeyPress(e)}
            onClick={() => setopenChatBox(true)}
            type={'text'}
            onChange={(e) => onChange(e.target.value)}
            InputProps={{
                disableUnderline: true,
                style: {
                    fontSize: 15,
                },
            }}
            sx={{

                maxHeight: '500px',
                overflow: 'auto',
                '& .MuiInputBase-root': {
                    borderRadius: '99px',
                    paddingRight: '48px',
                    paddingLeft: '80px',
                    paddingTop: '10px',
                    paddingBottom: '10px',
                    color: 'white',
                    background: 'transparent',
                    border: '1px solid rgba(217, 217, 217, 0.50)'

                },


            }}
            variant="standard"
        />
    )
}

export default StyledTextFeild