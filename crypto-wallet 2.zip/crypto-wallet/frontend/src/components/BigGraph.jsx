import React, { useEffect, useState } from 'react'
import AreaGraph from './AreaGraph'

const BigGraph = ({ isGraphOpen, setisGraphOpen, filterHistory, setactiveTime, activeTime, isFetching }) => {

    const [isShow, setisShow] = useState(false)

    useEffect(() => {
        setTimeout(() => {
            setisShow(true)
        }, 100);
    }, [])


    return (
        <div>
            {isGraphOpen && (
                <div>
                    <div
                        className="fixed top-0 left-0 w-full h-full z-40"
                        style={{
                            backgroundColor: 'rgba(12, 140, 233, 0.10)',
                        }}
                        onClick={() => setisGraphOpen(false)}
                    ></div>
                </div>
            )}
            {isGraphOpen && (
                <div className='absolute bottom-0 left-0 right-0 h-[450px] z-50 rounded-[5px]'
                    style={{
                        border: '1px solid #000',
                        background: '#122758',
                        boxShadow: '0px -4px 4px 0px rgba(241, 241, 241, 0.13)'
                    }}
                >
                    <div className='flex items-center justify-between py-[14px] max-w-[400px] mx-auto'>
                        <h2 className='text-[16px] font-bold text-[#5E8BFA] '>
                            Transactions volume
                        </h2>
                        <div className='rounded-[99px] p-[5px] cursor-pointer'
                            style={{
                                background: 'rgba(2, 15, 50, 0.62)'
                            }}
                            onClick={() => setisGraphOpen(false)}
                        >
                            <h2 className='text-white text-[14px]'>
                                {`< >`}
                            </h2>
                        </div>
                    </div>
                    <div className='px-[56px]  max-w-[1550px] mx-auto'
                    >
                        {isFetching ? (
                            <div
                                className='h-[330px] flex justify-center items-center animate-pulse px-[40px]'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.80)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            />
                        ) : (
                            <div
                                className='h-[330px] flex justify-center items-center pt-[40px] px-[40px]'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.60)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            >
                                {isShow && (
                                    <div className='w-full h-full'>
                                        <AreaGraph filterHistory={filterHistory} isBigGraph={true} />
                                    </div>
                                )}

                            </div>
                        )}


                        <div className='h-[30px] px-[5px] w-fit mx-auto flex mt-[10px] gap-[10px] items-center rounded-[99px]'
                            style={{
                                background: 'rgba(2, 15, 49, 0.60)',
                                boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                            }}
                        >
                            <button className={`text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '1 week' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                onClick={() => setactiveTime('1 week')}
                            >
                                1 week
                            </button>
                            {/* <button className={`text-white hidden md:block  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '1 month' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                onClick={() => setactiveTime('1 month')}
                            >
                                1 month
                            </button> */}
                            <button className={`text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '6 months' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                onClick={() => setactiveTime('6 months')}
                            >
                                6 months
                            </button>
                            <button className={`text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '1 year' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                onClick={() => setactiveTime('1 year')}
                            >
                                1 year
                            </button>

                        </div>

                    </div>
                </div>
            )
            }
        </div >
    )
}

export default BigGraph