import { PlusSmallIcon } from '@heroicons/react/24/solid';
import React from 'react';

const NumberComponent = ({ number }) => {
    const numberStr = String(number).padStart(5, '0');

    return (
        <div
            className='border border-[#B613C7] rounded-[99px] bg-[#122758] flex items-center pl-[10px] pr-[18px] py-[4px] gap-[8px]'
            style={{
                boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
            }}
        >
            <PlusSmallIcon className='text-[#9747FF] w-[25px] 2xl:w-[32px]' />
            {numberStr.split('').map((digit, index) => (
                <React.Fragment key={index}>
                    {index !== 0 && (
                        <div className='h-[60%] w-[2px] bg-[#9747FF] my-[10px]' />
                    )}
                    <h2 className={`texy-[28px] 2xl:text-[32px] font-normal  text-white ${index === 0 && 'ml-[-5px]'}`}>
                        {digit}
                    </h2>
                </React.Fragment>
            ))}
        </div>
    );
};

export default NumberComponent;
