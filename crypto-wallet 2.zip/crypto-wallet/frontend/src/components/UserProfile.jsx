import React, { useContext, useState } from 'react'
import { motion } from 'framer-motion';
import { Rating, useMediaQuery } from '@mui/material';
import StatesContext from '../context/StatesContext';

import plus from '../assets/plus.png'
import useredit from '../assets/useredit.png'
import useradd from '../assets/useradd.png'
import { useDisconnect } from 'wagmi';
import { useNavigate } from 'react-router-dom';
import NewContact from './Contact/NewContact';


const UserProfile = ({ setuserProfileOpen }) => {

    const context = useContext(StatesContext)
    const { userData, socketRef, resetState, setcreateServiceOpen } = context

    const [openEditContact, setopenEditContact] = useState(false)

    const smallerthen600 = useMediaQuery('(max-width:600px)')

    const { disconnect } = useDisconnect();

    const navigate = useNavigate()

    const handleLogout = async () => {

        disconnect()
        setuserProfileOpen(false)
        setopenEditContact(false)
        sessionStorage.removeItem('Token');
        navigate('/')
        socketRef.current.emit("logout");
        resetState()

    }

    return (
        <div>
            <motion.div
                key="notification-box"
                whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                className='absolute top-[80px] md:top-[70px] right-[9px] w-[350px] z-[9999]'
                style={{
                    background: '#020F32',
                    border: '1px solid #0C8CE9',
                    opacity: 0,
                    boxShadow: '-4px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                    left: smallerthen600 && '10px',
                    margin: smallerthen600 && '0 auto'
                }}
            >

                <div className='px-[15px] py-[15px]'>

                    <div className='flex justify-between items-center'>

                        <div className='flex items-center gap-[12px] cursor-pointer'
                        >
                            <div className='relative h-[36px] w-[36px]'>
                                <img src={userData.image} alt="" className='rounded-full border h-full w-full object-cover border-[#FFF3F3]' />
                                <div className='absolute top-0 right-0'>
                                    <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                </div>
                            </div>
                            <div>
                                <h2 className='text-white font-semibold text-[13px]'>
                                    {userData.name.length > 30 ? `${userData.name.substring(0, 30)}...` : userData.name}
                                </h2>
                                <p className='text-[#D9D9D980] text-[10px] font-light'>
                                    {userData.walletAddress.substring(0, 15)}...
                                </p>
                            </div>
                        </div>
                        <div className='mt-[-5px]'>
                            <Rating name="read-only" value={userData.ratings} readOnly precision={0.5}
                                style={{
                                    color: '#9747FF',
                                    fontSize: '20px'

                                }}
                                sx={{
                                    '& .MuiRating-iconEmpty': {
                                        color: '#9747FF',  // Change color of non-active star
                                        borderColor: '#9747FF', // Change border color of non-active star
                                    },
                                }}
                            />
                            <h2 className='text-[10px] mt-[-8px] font-light text-right '
                                style={{
                                    color: 'rgba(217, 217, 217, 0.50)'
                                }}
                            >
                                {userData.totalReviews} rates
                            </h2>
                        </div>
                    </div>
                    <div className='w-full h-[0.5px] bg-[#0C8CE9] mt-[10px]' />

                    <div className='mt-[20px] px-[15px]'>

                        {openEditContact && (
                            <NewContact setopenEditContact={setopenEditContact} UserProfile={true} />
                        )}

                        <div className='grid grid-cols-3 gap-[15px]'>
                            <div className='h-[90px] bg-[#020F31] px-[10px] rounded-[5px] border border-[#038AE8]'>
                                <div className='mt-[10px] cursor-pointer w-full h-[58px] rounded-[10px] flex justify-center items-center'
                                    style={{
                                        background: 'rgba(18, 39, 88, 0.74)'
                                    }}
                                    onClick={() => {
                                        setuserProfileOpen(false)
                                        setcreateServiceOpen(true)
                                    }}
                                >
                                    <img src={plus} alt="" />
                                </div>
                                <h2 className='text-center mt-[3px]  text-[10px] font-light text-gray-400'>
                                    Add Sell Offer
                                </h2>
                            </div>
                            <div className='h-[90px] bg-[#020F31] px-[10px] rounded-[5px] border border-[#038AE8]'>
                                <div className='mt-[10px] cursor-pointer w-full h-[58px] rounded-[10px] flex justify-center items-center'
                                    style={{
                                        background: 'rgba(18, 39, 88, 0.74)'
                                    }}
                                    onClick={() => setopenEditContact(true)}
                                >
                                    <img src={useradd} alt="" />
                                </div>
                                <h2 className='text-center mt-[3px]  text-[10px] font-light text-gray-400'>
                                    Add contact
                                </h2>
                            </div>
                            <div className='h-[90px] bg-[#020F31] rounded-[5px] border border-[#038AE8]'>
                                <div className='px-[10px]'>
                                    <div className='mt-[10px] cursor-pointer w-full h-[58px] rounded-[10px] flex justify-center items-center'
                                        style={{
                                            background: 'rgba(18, 39, 88, 0.74)'
                                        }}
                                        onClick={() => navigate('/settings')}
                                    >
                                        <img src={useredit} alt="" />
                                    </div>
                                </div>
                                <h2 className='text-center mt-[3px]  text-[10px] font-light text-gray-400'>
                                    Edit my Profile
                                </h2>
                            </div>
                        </div>
                    </div>

                    <div>
                        <button
                            className='w-full mt-[20px] h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                            onClick={() => navigate('/orders')}
                        >
                            My Orders
                        </button>
                        <button
                            className='w-full mt-[10px] h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                            onClick={() => navigate('/services')}
                        >
                            My Sales Offers
                        </button>
                        <button
                            className='w-full mt-[20px] h-[34px] bg-[#E0115F] hover:bg-[#B20A4D] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                            onClick={() => handleLogout()}
                        >
                            Disconnect wallet
                        </button>
                    </div>

                </div>

            </motion.div >
        </div>
    )
}

export default UserProfile