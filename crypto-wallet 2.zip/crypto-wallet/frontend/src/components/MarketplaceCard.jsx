import React, { useContext, useEffect, useState } from 'react'
import { Rating } from '@mui/material'

import bnb from '../assets/tokens/bnb.png'
import bsud from '../assets/tokens/bsud.png'
import usdc from '../assets/tokens/usdc.png'
import wbtc from '../assets/tokens/wbtc.png'
import eth from '../assets/ethchain.png'
import usdt from '../assets/tokens/usdt.png'

import { useNavigate } from 'react-router-dom'
import Checkbox from '@mui/material/Checkbox';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import Favorite from '@mui/icons-material/Favorite';
import { EyeIcon, TrashIcon } from '@heroicons/react/24/solid'
import StatesContext from '../context/StatesContext'
import { useCreateLikeMutation } from '../helpers/ServiceApi'


const MarketplaceCard = ({ handleClick, isOther, serviceData: cardData, CoinsPrice, CoinPriceLoading, myServices, setdeleteOpen, setserviceId }) => {

    const context = useContext(StatesContext)
    const { userData, walletConnected } = context

    const [serviceData, setserviceData] = useState(cardData)
    const [activeToken, setactiveToken] = useState(serviceData.paymentCoin[0])
    const [activeTokenImage, setactiveTokenImage] = useState('')
    const [activePrice, setactivePrice] = useState()

    const navigate = useNavigate()

    const [createLike] = useCreateLikeMutation()

    const clickfunction = () => {
        if (handleClick) {
            handleClick()
        }
    }

    const handleLikeChange = () => {
        if (walletConnected) {
            createLike(serviceData._id)

            const isLiked = serviceData.likes.includes(userData._id);

            if (isLiked) {
                // If the user already liked, remove their ID from the likes array
                setserviceData((prevServiceData) => ({
                    ...prevServiceData,
                    likes: prevServiceData.likes.filter((id) => id !== userData._id),
                }));
            } else {
                // If the user hasn't liked, add their ID to the likes array
                setserviceData((prevServiceData) => ({
                    ...prevServiceData,
                    likes: [...prevServiceData.likes, userData._id],
                }));
            }
        }
    }

    useEffect(() => {

        let img
        let ActiveTokenPrice

        switch (activeToken) {
            case 'WBTC':
                img = wbtc
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.wbtcUsd).toFixed(3)
                }
                break;
            case 'ETH':
                img = eth
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.ethUsd).toFixed(3)
                }
                break;
            case 'BSUD':
                img = bsud
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.busdUsd).toFixed(3)
                }
                break;
            case 'USDT':
                img = usdt
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.usdtUsd).toFixed(3)
                }
                break;
            case 'BNB':
                img = bnb
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.wbnbUsd).toFixed(3)
                }
                break;
            case 'USDC':
                img = usdc
                if (CoinsPrice) {
                    ActiveTokenPrice = (serviceData.price / CoinsPrice.usdcUsd).toFixed(3)
                }
                break;

            default:
                break;
        }

        setactiveTokenImage(img)
        setactivePrice(ActiveTokenPrice)

    }, [activeToken, CoinsPrice])

    return (
        <div className='rounded-[10px] cursor-pointer border border-[#9747FF] overflow-hidden '
            onClick={() => clickfunction()}
        >
            <div className='px-[7px] py-[10px] lg:py-[5px] bg-[#020F32]'>
                <div className='flex justify-between items-center'>
                    <div className='flex items-center gap-[5px]'
                        onClick={(e) => {
                            e.stopPropagation()

                            navigate(`/user/${serviceData.user._id}`)

                        }}
                    >
                        <img src={serviceData.user.image} alt="" className={`object-cover rounded-full border border-[#9747FF] ${isOther ? 'w-[25px] h-[25px] ' : ' w-[35px] h-[35px]'}`}

                        />
                        <div>
                            <h2 className={` font-normal text-white ${isOther ? 'text-[11px]' : 'text-[13px]'}`}>
                                {serviceData.user.name}
                            </h2>
                            <h6 className='text-white text-[8px]'>
                                {serviceData.user.walletAddress.substring(0, 15)}...
                            </h6>
                        </div>
                    </div>
                    <div className=' flex flex-col gap-[9px] justify-center'>
                        <Rating name="read-only" value={serviceData.ratings} readOnly precision={0.5}
                            style={{
                                color: '#9747FF',
                                fontSize: isOther ? '13px' : '17px'

                            }}
                            sx={{
                                '& .MuiRating-iconEmpty': {
                                    color: '#9747FF',  // Change color of non-active star
                                    borderColor: '#9747FF !important', // Change border color of non-active star
                                },
                            }}
                        />

                        <h2 className='text-[10px] mt-[-8px] font-light text-right '
                            style={{
                                color: 'rgba(217, 217, 217, 0.50)'
                            }}
                        >
                            {serviceData.totalReviews} rates
                        </h2>
                    </div>
                </div>
            </div>
            <div className='h-[220px] sm:h-[285px]  xl:h-[280px] 2xl:h-[270px] w-full relative'>
                <img src={serviceData.images[0]} alt="" className='h-full w-full object-cover' />
                <div className='absolute top-[0px] right-[0px] '>
                    <div className='flex flex-col items-center'>
                        <div onClick={(e) => e.stopPropagation()} >
                            <Checkbox
                                icon={<FavoriteBorder sx={{ color: 'white', fontSize: '25px' }} />}
                                checkedIcon={<Favorite sx={{ color: 'red', fontSize: '25px' }} />}
                                onChange={() => handleLikeChange()}
                                checked={serviceData.likes.includes(userData._id)}
                                disabled={!walletConnected}
                            />
                        </div>
                        <h2 className='text-[13px] mt-[-15px] font-semibold text-white'>
                            {serviceData.likes.length}
                        </h2>
                    </div>
                    <div className='flex flex-col items-center mt-[10px]'>
                        <EyeIcon className='text-white h-[20px]' />
                        <h2 className='text-[13px] font-semibold text-white'>
                            {serviceData.views}
                        </h2>
                    </div>
                </div>
                {(myServices || (userData && userData.isAdmin)) && (

                    <div className='absolute bottom-[5px] right-[5px] cursor-pointer'
                        onClick={(e) => {
                            e.stopPropagation()
                            setdeleteOpen(true)
                            setserviceId(serviceData._id)
                        }}
                    >
                        <div className='p-[6px] rounded-full bg-gray-500'>
                            <TrashIcon className='text-white h-[20px]' />
                        </div>
                    </div>
                )}

            </div>
            <div className='px-[10px] pb-[15px] pt-[5px] bg-[#020F32]'>
                <h2 className='text-white text-[13px] font-semibold line-clamp-1 break-words'>
                    {serviceData.title}
                </h2>
                <div className='mt-[6px] grid grid-cols-2 items-center gap-[20px]'>
                    <div className='flex items-center gap-[5px]'>
                        {CoinPriceLoading ? (
                            <div className='h-[25px] w-[75px] animate-pulse rounded-[3px]'
                                style={{
                                    backgroundColor: 'rgba(151, 71, 255,0.7)'
                                }}
                            />
                        ) : (
                            <h6 className='text-[20px] h-[25px] text-[#9747FF] font-semibold w-[75px]'>
                                {activePrice}
                            </h6>
                        )}

                        <img src={activeTokenImage} alt="" onClick={(e) => e.stopPropagation()} className='h-[25px] w-[25px] rounded-full border border-[#9747FF]' />
                    </div>
                    <div className='flex gap-[5px] flex-wrap'>
                        {serviceData.paymentCoin.map((item, i) => {

                            let img

                            switch (item) {
                                case 'WBTC':
                                    img = wbtc
                                    break;
                                case 'ETH':
                                    img = eth
                                    break;
                                case 'BSUD':
                                    img = bsud
                                    break;
                                case 'USDT':
                                    img = usdt
                                    break;
                                case 'BNB':
                                    img = bnb
                                    break;
                                case 'USDC':
                                    img = usdc
                                    break;

                                default:
                                    break;
                            }

                            return (
                                <img
                                    src={img}
                                    key={i}
                                    alt=""
                                    className='h-[20px] cursor-pointer w-[20px] rounded-full border border-[#9747FF]'
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        setactiveToken(item)
                                    }}
                                />
                            )
                        })}
                    </div>
                </div>
                <h6 className='text-[10px] text-[#9747FF] font-semibold'>
                    {serviceData.price} $
                </h6>

                <div className='mt-[6px] grid grid-cols-2 items-center gap-[20px]'>
                    <div className='flex items-center gap-[6px]'>
                        <h2 className='text-[10px]'
                            style={{
                                color: 'rgba(255, 255, 255, 0.60)',
                            }}
                        >
                            {serviceData.country}
                        </h2>
                    </div>
                    <div className='flex flex-wrap gap-[3px]'>
                        {serviceData.category.map((item, i) => (
                            <div key={i}>
                                {i < 2 && (
                                    <div className='border border-[#038AE8] px-[5px] py-[2px] rounded-[99px]' key={i}>
                                        <h2 className='text-white text-[7px]'>
                                            {item}
                                        </h2>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MarketplaceCard