import { CircularProgress, useMediaQuery } from "@mui/material"

const Table = ({ tableHead, data, isFetching }) => {

    const smallerthen640 = useMediaQuery('(max-width:640px)')

    function formatDate(date) {
        // Get the year, month, and day components of the date
        const year = date.getFullYear().toString().slice(-2); // Get the last two digits of the year
        const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Add 1 to month because it's zero-based
        const day = date.getDate().toString().padStart(2, '0');

        // Combine them in the desired format
        return `${month}/${day}/${year}`;
    }


    return (

        <div className="relative rounded-[10px] overflow-x-auto w-full max-h-[400px]"

        >
            <table className="w-full">
                <thead className="text-[14px] font-medium text-[#87909C]" style={{ background: 'rgba(255, 255, 255, 0.04)' }}>
                    <tr className='border-b-[0.5px] border-gray-700'>
                        {tableHead.map((item, i) => (
                            <th scope="col" className={`py-[16px] px-[30px] text-center`} key={i}>
                                {item}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody className='w-full'>
                    {!isFetching && data.history.length > 0 && data.history.map((item, i) => (
                        <tr
                            style={{
                                background: 'rgba(255, 255, 255, 0.04)'
                            }}
                            key={i}
                        >
                            <td className="text-white text-center py-[15px] text-[12px] sm:text-[16px] font-medium">
                                {i + 1}
                            </td>
                            <td className="text-white text-center text-[12px] sm:text-[16px] font-medium">
                                {formatDate(new Date(item.createdAt))}
                            </td>
                            <td className="text-white text-center text-[12px] sm:text-[16px] font-medium">
                                {smallerthen640 ? item.receiptAddress.substring(0, 12) : item.receiptAddress.substring(0, 15)}...
                            </td>
                            <td className="text-white text-center text-[12px] sm:text-[16px] font-medium">
                                {item.amount} {item.tokenName && item.tokenName}
                            </td>

                        </tr>
                    ))}
                    <tr
                        style={{
                            background: 'rgba(255, 255, 255, 0.04)',
                        }}
                    >
                        {isFetching && (
                            <td colSpan={'6'} className="py-[85px] text-center">
                                <CircularProgress sx={{ color: 'white' }} />
                            </td>
                        )}
                        {!isFetching && data.history.length === 0 && (
                            <td colSpan={'6'} className="text-[15px] py-[100px] font-medium text-[#87909C] text-center">
                                You didn't have any previous transactions yet!
                            </td>
                        )}

                    </tr>

                </tbody>
            </table>
        </div>
    )
}

export default Table