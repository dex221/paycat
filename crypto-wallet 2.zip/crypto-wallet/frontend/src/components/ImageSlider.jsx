import React from 'react'
// import Swiper core and required modules
import { Autoplay, Pagination } from 'swiper/modules';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/autoplay';
import { Box, styled } from '@mui/material';


const ImageSlider = ({ data }) => {

    const StyledPortfolioSection = styled(Box)(({ theme }) => ({
        '.swiper-pagination-bullet': {
            backgroundColor: '#038AE8 !important',
            height: '12px',
            width: '12px',
            opacity: '1.0'
        },
        '.swiper-pagination-bullet-active': {
            backgroundColor: '#9747FF !important',
            height: '12px',
            width: '31px',
            strokeEidth: '1px',
            filter: 'drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))',
            borderRadius: '5px'
        },
        '.swiper-pagination': {
            background: 'rgba(7, 23, 62, 0.66)',
            padding: '5px',
            borderRadius: '999px',
            width: 'fit-content',
            margin: '0 auto', 
            position: 'absolute', 
            bottom: '10px', 
            left: 0,
            right: 0,
            display: 'flex',
            justifyContent: 'center',
        },

    }))

    return (
        <div
            className='h-[230px] 2xl:h-[254px]'
            style={{
                borderRadius: '5px',
                background: 'rgba(18, 39, 88, 0.56)',
                boxShadow: '0px 4px 4px 0px rgba(217, 217, 217, 0.19)'
            }}
        >
            <StyledPortfolioSection>
                <Swiper
                    modules={[Pagination, Autoplay]}
                    slidesPerView={1}
                    pagination={{ clickable: true }}
                    autoplay
                >
                    {data.map((item, i) => (

                        <SwiperSlide
                            key={i}
                            className={`h-[230px] 2xl:h-[254px] w-full`}
                        >
                            <img src={item.imgUrl} alt="" className='h-full w-full object-cover rounded-[5px]' />
                        </SwiperSlide>
                    ))}

                </Swiper>
            </StyledPortfolioSection>
        </div >
    )
}

export default ImageSlider