import React, { useContext, useEffect, useState } from 'react';

import bg from '../../assets/home/bg.png'
import blacklogo from '../../assets/home/blacklogo.png'

import bell from '../../assets/bell.png'
import blueid from '../../assets/paymentblue.png'
import searchicon from '../../assets/searchicon.png'
import gift from '../../assets/gift.png'

import Contact from '../Contact/Contact';
import Notification from '../Notification';
import { useLocation, useNavigate } from 'react-router-dom';
import { Bars3BottomLeftIcon, Cog6ToothIcon } from '@heroicons/react/24/solid';
import MobNav from '../MobNav';
import DarkToggle from '../DarkToggle';
import { BACKEND_URL } from '../../constants/constants'

import { CircularProgress, useMediaQuery } from '@mui/material';
import { useWeb3Modal } from '@web3modal/react';
import { useAccount } from 'wagmi'
import { disconnect } from 'wagmi/actions'
import NotConnectedModal from '../Modals/NotConnectedModal';
import UserProfile from '../UserProfile';
import ChatHistory from '../ChatHistory';
import CreateService from '../Modals/CreateService/CreateService';
import NetworkDropdown from '../NetworkDropdown';
import MobSettings from '../Modals/MobSettings';
import StatesContext from '../../context/StatesContext';
import WalletsModel from '../Modals/WalletsModel';

const Layout = (Component) => function Hoc() {
    const context = useContext(StatesContext)
    const { walletConnected, contactOpen, setunreadMessages, setisComingFromChat, data, chatOpen, search, setsearch, setcontactOpen, notConntedOpen, setnotConntedOpen, setwalletConnected, isDarkMode, setconnectAction, createServiceOpen, setcreateServiceOpen, setuserData, userData, NotificationOpen, setNotificationOpen, onlineUsers, notifications, setnotificationQuery, chatHistoryOpen, setchatHistoryOpen, unreadMessages } = context

    const [isOpen, setisOpen] = useState(false)
    const [loading, setloading] = useState(false)
    const [isUserActive, setisUserActive] = useState('')
    const [isNewNotification, setisNewNotification] = useState(false)
    const [notificationCount, setnotificationCount] = useState('')
    const [userProfileOpen, setuserProfileOpen] = useState(false)
    const [dropdownOpen, setdropdownOpen] = useState(false)
    const [mobSettings, setmobSettings] = useState(false)
    const [walletOpen, setwalletOpen] = useState(false)

    const navigate = useNavigate()
    let { pathname, state } = useLocation()
    const location = pathname.split('/')[1] === 'conversation'
    const isMarketPlace = pathname === '/'


    const smallerthen640 = useMediaQuery('(max-width:640px)')
    const smallerthen768 = useMediaQuery('(max-width:768px)')

    const { open } = useWeb3Modal()
    const { address, isConnected, } = useAccount()

    const handleMetamaskLogin = async () => {

        setloading(true)

        try {

            if (!window.ethereum) {
                setwalletOpen(true)

            } else {

                if (isConnected) {
                    await disconnect()
                }

                await open()
                localStorage.setItem('ButtonClicked', true)
            }

        } catch (error) {
            console.error(error);
        }
        finally {
            setloading(false)
        }
    }

    useEffect(() => {

        if (isConnected && localStorage.getItem('ButtonClicked')) {
            setloading(true)
            try {
                const connectFunction = async () => {

                    const data = { address };

                    const authResponse = await fetch(`${BACKEND_URL}/api/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(data)
                    });

                    const { token, user } = await authResponse.json();

                    if (user) {
                        setnotConntedOpen(false)
                        setwalletConnected(true)
                        if (pathname === '/') {
                            navigate('/dashboard')
                        }
                        sessionStorage.setItem('Token', token);
                        setuserData(user)
                    }
                }
                connectFunction()
            } catch (error) {
                console.log(error)
            }
            finally {
                setloading(false)
                localStorage.removeItem('ButtonClicked')
            }
        }

    }, [isConnected])


    useEffect(() => {

        if (onlineUsers && state) {
            let isActive = onlineUsers.some((data) => data.userId === state.walletAddress);
            setisUserActive(isActive)
        }

    }, [onlineUsers, pathname])

    useEffect(() => {
        if (notifications) {
            let newNotificationCount = 0;
            let isNew = false;
            let unread = 0
            notifications.forEach(data => {
                if (!data.isSeen) {
                    newNotificationCount++;
                    isNew = true;
                }
                switch (data.type) {
                    case 'Unread':
                        unread++;
                        break;
                    default:
                        break;
                }
            });

            setunreadMessages(unread)

            setisNewNotification(isNew);
            setnotificationCount(newNotificationCount)
        }
    }, [notifications]);


    useEffect(() => {
        if (isDarkMode) {
            if (smallerthen640 || pathname === '/') {
                document.body.style.backgroundColor = 'rgb(2, 15, 50)';
                document.documentElement.style.backgroundColor = 'rgb(2, 15, 50)';
            }
        }
        else if (!isDarkMode) {
            if (smallerthen640 && (isOpen || contactOpen)) {
                document.body.style.backgroundColor = 'rgb(55 65 81)';
                document.documentElement.style.backgroundColor = 'rgb(55 65 81)';
            } else {
                document.body.style.backgroundColor = '#f2f7fb';
            }
        }


    }, [isDarkMode, isOpen, contactOpen]);

    useEffect(() => {
        // Function to handle the scrolling behavior
        const handleScrollLock = () => {
            if (createServiceOpen || notConntedOpen) {
                // Disable scrolling on the body element
                document.body.style.overflow = 'hidden';
            } else {
                // Enable scrolling on the body element
                document.body.style.overflow = 'unset';
            }
        };

        // Call the function when the state changes
        handleScrollLock();

        // Clean up the effect to re-enable scrolling when the component unmounts
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, [createServiceOpen, notConntedOpen]);

    useEffect(() => {
        if (!location) {
            window.scrollTo(0, 0)
        }

    }, [])

    return (
        <div className={`relative min-h-screen}`}
        >
            <NotConnectedModal
                open={notConntedOpen}
                setOpen={setnotConntedOpen}
                handleMetamaskLogin={handleMetamaskLogin}
                loading={loading}
            />

            <MobNav isOpen={isOpen} setisOpen={setisOpen} setnotConntedOpen={setnotConntedOpen} unreadCount={unreadMessages} />

            {isDarkMode && pathname !== '/' && (
                <div className='hidden sm:block sm:absolute top-0 bottom-[-30px] right-[-20px] left-[-20px]'>
                    <img src={bg} alt="" className='w-full h-full object-cover' />
                </div>
            )}

            <div className='flex h-full relative z-20 '>

                <div className={`hidden lg:block px-[30px] bg-gray-700 dark:bg-transparent 2xl:px-[43px] py-[24px] min-h-screen relative z-20 border-r border-[#D9D9D9] ${(isMarketPlace || location) && 'lg:fixed top-0 left-0 bottom-0 h-[100vh] overflow-y-auto'}`}

                >
                    <img src={blacklogo} alt="" className='w-[55px] 2xl:w-full mx-auto' />
                    <h6 className='text-[13px] text-center font-bold text-white mt-[12px]'>
                        PAYCAT
                    </h6>
                    <div className='h-[1px] w-[55px] 2xl:w-[60px] bg-[#D9D9D9] mx-auto mt-[30px]' />

                    <div className='mt-[40px] space-y-[35px]'>
                        {data.map((item, i) => (
                            <div
                                key={i}
                                onClick={() => {
                                    if (walletConnected) {
                                        if (item.title !== 'Chat') {
                                            if (item.title === 'Crypto Payment') {
                                                setcontactOpen(!contactOpen)
                                                setisComingFromChat(false)
                                                setchatHistoryOpen(false)
                                                if (pathname === '/') {
                                                    navigate('/dashboard')
                                                }
                                            } else {
                                                setcontactOpen(false)
                                                setchatHistoryOpen(false)
                                            }
                                        } else {
                                            if (item.title === 'Chat') {
                                                setchatHistoryOpen(!chatHistoryOpen)
                                                setcontactOpen(false)
                                                if (pathname === '/') {
                                                    navigate('/dashboard')
                                                }
                                            }
                                        }
                                        if (item.route) {
                                            navigate(item.route)
                                        }
                                    } else {
                                        if (item.title === 'Market-place') {
                                            navigate(item.route)
                                        } else if (item.title === 'Home') {
                                            navigate(item.route)
                                        } else {
                                            setnotConntedOpen(true)
                                            if (item.title === 'Chat') {
                                                setconnectAction(`${item.title}`)
                                            } else if (item.title === 'Crypto Payment') {
                                                setconnectAction(`do ${item.title}`)
                                            } else {
                                                setconnectAction(`access your ${item.title}`)
                                            }
                                        }
                                    }
                                }}
                                className='flex flex-col items-center gap-[10px] w-[70px] cursor-pointer hover:scale-90 duration-700'>
                                {item.img ? (
                                    <img src={item.title === 'Crypto Payment' && contactOpen ? blueid : item.img} alt="" className='w-[23px] lg:w-[29px] xl:w-[33px] 2xl:w-[38px]' />
                                ) : (
                                    <div className='relative'>
                                        {item.icon}
                                        {item.title === 'Chat' && (
                                            <div>
                                                {unreadMessages > 0 && (
                                                    <div className='absolute top-[-7px] right-[-9px]'>
                                                        <div className='px-[8px] py-[3px] rounded-[69px] bg-[#E0115F]'>
                                                            <h2 className='text-white text-[10px] font-bold'>
                                                                {unreadMessages > 99 ? '99+' : unreadMessages}
                                                            </h2>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                )}
                                <h4 className={`text-[10px] lg:text-[12px] text-center 2xl:text-[13px] font-normal ${item.title === 'Crypto Payment' && contactOpen ? 'text-[#0C8CE9]' : 'text-[#F1F1F1] '} ${item.title === 'Chat' && chatHistoryOpen ? 'text-[#0C8CE9]' : 'text-[#F1F1F1] '}`}>{item.title}</h4>
                            </div>
                        ))}
                    </div>

                </div>
                {contactOpen && (
                    <Contact />
                )}
                {chatHistoryOpen && (
                    <ChatHistory setchatHistoryOpen={setchatHistoryOpen} />
                )}

                {createServiceOpen && (
                    <CreateService setcreateServiceOpen={setcreateServiceOpen} open={createServiceOpen} />
                )}

                <WalletsModel open={walletOpen} setopen={setwalletOpen} handleMetamaskLogin={handleMetamaskLogin} setloading={setloading} />


                {mobSettings && (
                    <MobSettings setmobSettings={setmobSettings} />
                )}
                <div className='w-full'>
                    <div className={`relative z-20 h-fit md:border-b bg-gray-700  border-gray-600 dark:border-[#D9D9D9]  px-[15px] py-[15px] 2xl:py-[20px] ${(isMarketPlace || location) ? `lg:fixed top-0 ${(contactOpen || chatHistoryOpen) ? 'lg:left-[391px] xl:left-[397px] 2xl:left-[423px]' : 'left-[131px] 2xl:left-[160px]'} lg:z-20  right-0 lg:dark:bg-[#020F32]` : 'dark:bg-transparent'} `}

                    >
                        <div className={`w-full flex items-center justify-between ${location || pathname === '/dashboard' || pathname === '/' ? 'lg:justify-between' : 'lg:justify-end'}`}>
                            {walletConnected && (pathname === '/dashboard' || pathname === '/') && (

                                <div className='hidden lg:flex flex-shrink-0 items-center gap-[5px] cursor-pointer hover:scale-90 duration-700'>
                                    <img src={gift} alt="" />
                                    <h2 className='text-[#EBEF10] text-[16px] font-bold '>
                                        +1
                                    </h2>
                                </div>
                            )}
                            {pathname === '/' && (
                                <div className='hidden lg:block grow pr-[30px] pl-[60px]'>
                                    <div className='relative h-[40px] w-full '>
                                        <input
                                            type="text"
                                            value={search}
                                            onChange={(e) => setsearch(e.target.value)}
                                            className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                                            placeholder='Search...'
                                            style={{
                                                border: '1px solid rgba(217, 217, 217, 0.50)'
                                            }}
                                        />
                                        <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                                            <img src={searchicon} alt="" className='h-[16px]' />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className='hidden lg:flex'

                            >
                                {/* other user data */}
                                {walletConnected && location && (
                                    <div className='flex items-center gap-[12px]'>
                                        <div className='relative h-[36px] w-[36px]'>
                                            <img src={state.image} alt="" className='rounded-full border border-[#FFF3F3] h-full w-full object-cover' />
                                            {isUserActive && (
                                                <div className='absolute top-0 right-0'>
                                                    <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                                </div>
                                            )}
                                        </div>
                                        <div className=''>
                                            <h2 className='text-white font-semibold text-[13px]'>
                                                {state.name}
                                            </h2>
                                            <p className='text-[#D9D9D980] text-[10px] font-light'>
                                                {state.walletAddress.substring(0, 12)}...
                                            </p>
                                        </div>
                                    </div>
                                )}
                            </div>

                            <div className={`fixed top-0 left-0 right-0 z-50  lg:relative `}
                                style={{
                                    background: isDarkMode && 'rgb(2, 15, 50)'
                                }}
                            >
                                <div className={`relative z-50 flex justify-between md:w-[96vw] lg:w-full px-[20px] md:px-0 py-[15px] md:py-0 border-b border-gray-600 dark:border-[#D9D9D9] md:border-none ${!isDarkMode && 'bg-gray-700'}`}
                                    style={{
                                        background: isDarkMode && 'rgb(2, 15, 50)'
                                    }}
                                >

                                    {!walletConnected ? (
                                        <div>
                                            <img src={blacklogo} alt="" className='w-[35px] lg:hidden' />
                                        </div>
                                    ) : (
                                        <div className='lg:hidden flex items-center gap-[10px]'>
                                            <div className="relative w-[38px] h-[38px] rounded-full cursor-pointer lg:hidden flex items-center gap-[10px]"  >
                                                <Bars3BottomLeftIcon
                                                    className={`absolute top-0 left-0 w-full h-full text-white transition-all duration-1000 ease-in-out selection:bg-transparent focus:bg-transparent`}
                                                    onClick={() => setisOpen(!isOpen)}
                                                />
                                            </div>
                                            <div className=''>
                                                <div className='flex items-center gap-[5px] cursor-pointer hover:scale-90 duration-700'>
                                                    <img src={gift} alt="" className='h-[25px]' />
                                                    <h2 className='text-[#EBEF10] text-[12px] font-bold '>
                                                        +1
                                                    </h2>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    <div className='grow flex justify-end flex-shrink-0 '>

                                        {walletConnected ? (
                                            <div className='lg:pr-[20px] flex gap-[21px] items-center'>

                                                <div
                                                    className='relative cursor-pointer'
                                                    onClick={() => {
                                                        setnotificationQuery('')
                                                        setNotificationOpen(!NotificationOpen)
                                                    }}
                                                >
                                                    <img src={bell} alt="" className='h-[25px]' />
                                                    {isNewNotification && (
                                                        <div className='absolute top-[-2px] right-[-2px]'>
                                                            <div className='h-[15px] w-[15px] rounded-full bg-[#E0115F] flex items-center justify-center' >
                                                                <h6 className='text-white font-semibold text-[10px]'>
                                                                    {notificationCount}
                                                                </h6>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>

                                                <div className='lg:hidden bg-slate-800 px-[10px] py-[8px] rounded-[5px] flex items-center gap-[15px]'
                                                >
                                                    {/* <Cog6ToothIcon className='text-white h-[20px] cursor-pointer relative z-20' onClick={() => setmobSettings(true)} /> */}
                                                    <NetworkDropdown dropdownOpen={dropdownOpen} setdropdownOpen={setdropdownOpen} />
                                                </div>

                                                {/* <div className='hidden lg:block'>
                                                    <DarkToggle />
                                                </div> */}
                                                <div className='hidden lg:block'>
                                                    <NetworkDropdown dropdownOpen={dropdownOpen} setdropdownOpen={setdropdownOpen} />
                                                </div>
                                                <div className='flex items-center gap-[12px] cursor-pointer'
                                                    onClick={() => setuserProfileOpen(!userProfileOpen)}
                                                >
                                                    <div className='relative h-[36px] w-[36px]'>
                                                        <img src={userData.image && userData.image} alt="" className='rounded-full border h-full w-full object-cover border-[#FFF3F3]' />
                                                        <div className='absolute top-0 right-0'>
                                                            <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                                        </div>
                                                    </div>
                                                    <div className='hidden md:block'>
                                                        <h2 className='text-white font-semibold text-[13px]'>
                                                            {userData.name?.length > 30 ? `${userData.name?.substring(0, 30)}...` : userData.name}
                                                        </h2>
                                                        <p className='text-[#D9D9D980] text-[10px] font-light'>
                                                            {userData.walletAddress.substring(0, 15)}...
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>

                                        ) : (
                                            <div className='flex items-center gap-[20px]'>
                                                {/* <DarkToggle /> */}
                                                <button
                                                    className='w-[110px] sm:w-[138px] h-[30px] sm:h-[34px] bg-[#0C8CE9] text-white text-[12px] sm:text-[14px] font-bold rounded-[10px]'
                                                    onClick={() => handleMetamaskLogin()}
                                                >
                                                    {loading ? <CircularProgress size={21} sx={{ color: 'white' }} /> : 'Connect Wallet'}
                                                </button>
                                                <div className='lg:hidden'>
                                                    <div className="relative w-[38px] h-[38px] rounded-full cursor-pointer block lg:hidden"  >
                                                        <Bars3BottomLeftIcon
                                                            className={`absolute top-0 left-0 w-full h-full text-white transition-all duration-1000 ease-in-out selection:bg-transparent focus:bg-transparent`}
                                                            onClick={() => setisOpen(!isOpen)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    <Notification setNotificationOpen={setNotificationOpen} />
                                    {userProfileOpen && (
                                        <UserProfile setuserProfileOpen={setuserProfileOpen} />
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        {isOpen || contactOpen && (

                            <div className='min-h-screen w-[100vw] sm:hidden absolute inset-0 z-20'
                                style={{
                                    backgroundColor: isDarkMode ? 'rgb(2, 15, 50)' : 'rgb(55 65 81)'
                                }}
                            />
                        )}
                    </div>
                    <div
                        className={`relative ${(isMarketPlace || location && (!contactOpen && !chatHistoryOpen)) && `lg:ml-[140px] xl:ml-[145px] 2xl:ml-[155px] ${(!chatOpen || isMarketPlace || !contactOpen) && !location && 'lg:mt-[110px]'}`} ${((isMarketPlace || location) && (contactOpen || chatHistoryOpen)) && `lg:ml-[395px] xl:ml-[398px] 2xl:ml-[422px] ${isMarketPlace && 'lg:mt-[110px]'}`}`}
                        style={{
                            display: (isOpen || contactOpen) && smallerthen640 && 'none',
                            zIndex: smallerthen768 && 10,
                        }}
                    >

                        <Component />
                    </div>
                </div>
            </div >
        </div >
    )
}
export default Layout;
