import React, { useState } from 'react'
import bnb from '../assets/bnbchain.png'
import ethchain from '../assets/ethchain.png'
import { ChevronDownIcon } from '@heroicons/react/24/solid'
import { useNetwork, useSwitchNetwork } from 'wagmi'

const NetworkDropdown = ({ dropdownOpen, setdropdownOpen }) => {

    const { chain } = useNetwork()
    const { chains, switchNetwork } =
        useSwitchNetwork()

    return (
        <div className='relative'>
            <div className='lg:w-[190px] border border-[#5E8BFA] px-[2px] lg:px-[10px] py-[2px] lg:py-[8px] rounded-[30px] flex items-center gap-[5px] lg:gap-0 justify-between cursor-pointer'
                onClick={() => setdropdownOpen(!dropdownOpen)}
            >

                <div className='flex items-center gap-[7px]'>
                    <img src={chain && chain.id === 97 ? bnb : ethchain} alt="" className='h-[17px] w-[17px] lg:h-[20px]' />
                    <h2 className='text-[14px] text-[#5E8BFA] font-normal hidden lg:block '>
                        {chain && chain.id !== 97 ? 'Ethereum' : 'BNB Smart Chain'}
                    </h2>
                </div>
                <ChevronDownIcon className='text-[#5E8BFA] h-[15px] lg:h-[20px] pr-[5px]' />
            </div>
            {dropdownOpen && (
                <div className='absolute top-[45px] left-[-85px] right-[-60px] lg:left-0 lg:right-0 bg-[#020F31] border border-[#5E8BFA] rounded-[10px] '
                    style={{
                        boxShadow: '0px 4px 4px 0px rgba(255, 255, 255, 0.09)'
                    }}
                >
                    <div className='py-[5px] border-b border-[#5E8BFA]'>
                        <h2 className='text-white  text-center text-[14px] font-normal'>
                            Select a Network
                        </h2>
                    </div>
                    <div className='px-[20px] py-[13px] space-y-[13px]'>
                        {chains && chains.length > 0 && chains.map((item, i) => (

                            <button className='flex items-center gap-[7px] cursor-pointer'
                                onClick={() => {
                                    setdropdownOpen(false)
                                    switchNetwork?.(item.id)
                                }}
                                disabled={!switchNetwork || item.id === chain?.id}
                                key={i}
                            >
                                <img src={i !== 0 ? bnb : ethchain} alt="" className='h-[20px]' />
                                <h2 className='text-[14px] text-white font-normal '>
                                    {i !== 0 ? 'BNB Smart Chain' : 'Ethereum'}
                                </h2>
                            </button>
                        ))}
                    </div>
                </div>
            )}

        </div>
    )
}

export default NetworkDropdown