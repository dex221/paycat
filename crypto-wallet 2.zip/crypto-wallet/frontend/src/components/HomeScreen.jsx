import React, { useContext, useEffect, useState } from 'react'
import { motion } from 'framer-motion';
import Layout from './Hoc/Layout'
import StatesContext from '../context/StatesContext'
import { Player } from '@lottiefiles/react-lottie-player';
import ImageSlider from './ImageSlider';

import NumberComponent from './NumberComponent';
import { CircularProgress, useMediaQuery } from '@mui/material';
import { useWeb3Modal } from '@web3modal/react';
import { useAccount } from 'wagmi';
import { BACKEND_URL } from '../constants/constants';
import AreaGraph from './AreaGraph';
import { useNavigate } from 'react-router-dom';
import BigGraph from './BigGraph';
import { useGettotalHistoryGraphQuery } from '../helpers/notificationApi';
import { useAllSliderImagesQuery } from '../helpers/homeSliderApi';
import { disconnect } from 'wagmi/actions';


const HomeScreen = ({ isDataLoading }) => {

    const context = useContext(StatesContext)
    const { usersCount, isDarkMode, setwalletConnected, setuserData, userData, walletConnected } = context

    const [loading, setloading] = useState(false)
    const [activeTime, setactiveTime] = useState('1 week')
    const [isGraphOpen, setisGraphOpen] = useState(false)

    const { open } = useWeb3Modal()
    const { address, isConnected } = useAccount()

    const smallerthen1415 = useMediaQuery('(max-width:1415px)')

    const navigate = useNavigate()
    const { data: history, isFetching } = useGettotalHistoryGraphQuery(activeTime)
    const { data: slider1, isLoading: slider1Loading } = useAllSliderImagesQuery('Slider 1')
    const { data: slider2, isLoading: slider2Loading } = useAllSliderImagesQuery('Slider 2')


    const handleMetamaskLogin = async () => {

        setloading(true)

        if (isConnected) {
            await disconnect()
        }

        try {
            await open()
            localStorage.setItem('ButtonClicked', true)

        } catch (error) {
            console.error(error);
        }
        finally {
            setloading(false)
        }
    }

    function abbreviateAddress(address, startChars = 6, endChars = 4) {
        if (!address || typeof address !== 'string') {
            return '';
        }

        const length = address.length;
        if (length < startChars + endChars) {
            return address; // Return the full address if it's too short
        }

        const startPart = address.substr(0, startChars);
        const endPart = address.substr(length - endChars, endChars);

        return `${startPart}...${endPart}`;
    }

    useEffect(() => {

        if (isConnected && localStorage.getItem('ButtonClicked')) {
            setloading(true)
            try {
                const connectFunction = async () => {

                    const data = { address };

                    const authResponse = await fetch(`${BACKEND_URL}/api/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(data)
                    });

                    const { token, user } = await authResponse.json();

                    if (user) {
                        setwalletConnected(true)
                        navigate('/dashboard')
                        sessionStorage.setItem('Token', token);
                        setuserData(user)
                    }
                }
                connectFunction()
            } catch (error) {
                console.log(error)
            }
            finally {
                setloading(false)
                localStorage.removeItem('ButtonClicked')
            }
        }

    }, [isConnected])

    return (
        <div>
            {isGraphOpen && (
                <BigGraph isGraphOpen={isGraphOpen} setisGraphOpen={setisGraphOpen} filterHistory={history && history.history} setactiveTime={setactiveTime} activeTime={activeTime} isFetching={isFetching} />
            )}

            <div className='pt-[65px] pb-[35px] relative md:py-[35px] sm:px-[56px]  max-w-[1550px] mx-auto'>

        
                <div className='px-[25px]  sm:px-0'>
                    <h2 className=' text-center text-[#5E8BFA] text-[24px] sm:text-[30px] 2xl:text-[36px] font-bold'>
                        WelCome to Paycat !
                    </h2>
                    <p className='text-center dark:text-white text-[12px] sm:text-[15px] 2xl:text-[18px]  font-bold'>
                        Your crypto payment, Chat and a Marketplace use-case solution
                    </p>
                </div>

                <div

                    className='flex justify-center h-[350px] sm:h-[500px] 2xl:h-[600px] w-full'
                >
                    <Player
                        src="/pic.json"
                        loop
                        autoplay
                        className='h-full w-[390px] sm:w-full object-contain'
                    />
                </div>

                <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 ${smallerthen1415 ? 'xl:grid-cols-3' : 'xl:grid-cols-4'} gap-[30px] px-[25px] sm:px-0`}>
                    {slider1Loading ? (
                        <div
                            className='h-[230px] 2xl:h-[254px]'
                            style={{
                                borderRadius: '5px',
                                background: isDarkMode ? 'rgba(18, 39, 88, 0.56)' : 'rgb(31 41 55)',
                                boxShadow: '0px 4px 4px 0px rgba(217, 217, 217, 0.19)'
                            }}
                        >
                            <div className='w-full h-full animate-pulse'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.7)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            />
                        </div>
                    ) : (
                        <div>
                            {slider1 && slider1.slider.length > 0 && (
                                <ImageSlider data={slider1.slider} />
                            )}
                        </div>
                    )}
                    <div
                        className='h-[230px] 2xl:h-[254px] px-[20px] py-[30px]'
                        style={{
                            borderRadius: '5px',
                            background: isDarkMode ? 'rgba(18, 39, 88, 0.56)' : 'rgb(31 41 55)',
                            boxShadow: '0px 4px 4px 0px rgba(217, 217, 217, 0.19)'
                        }}
                    >
                        {isDataLoading ? (
                            <div className='w-full h-full animate-pulse'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.70)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            />
                        ) : (
                            <div>
                                <h2 className='text-center text-[20px] 2xl:text-[28px] font-bold text-[#5E8BFA] '>
                                    Ready to join our...
                                </h2>
                                <div className=' py-[20px]'>
                                    <div className='flex justify-center'>
                                        <NumberComponent number={usersCount} />
                                    </div>
                                    <h2 className='text-white font-bold text-[10px] 2xl:text-[12px] mt-[3px] text-center '>
                                        Actives users
                                    </h2>
                                </div>
                                <div className='flex justify-center'>
                                    <button
                                        className='w-[138px] h-[34px] bg-[#0C8CE9] text-white text-[12px] sm:text-[14px] font-bold rounded-[10px]'
                                        onClick={() => {
                                            if (!walletConnected) {
                                                handleMetamaskLogin()
                                            }
                                        }}
                                    >
                                        {loading ? <CircularProgress size={21} sx={{ color: 'white' }} /> : (userData && userData.walletAddress ? abbreviateAddress(userData.walletAddress) : 'Connect Wallet')}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                    <div
                        className='h-[230px] 2xl:h-[254px] p-[10px]'
                        style={{
                            borderRadius: '5px',
                            background: isDarkMode ? 'rgba(18, 39, 88, 0.56)' : 'rgb(31 41 55)',
                            boxShadow: '0px 4px 4px 0px rgba(217, 217, 217, 0.19)'
                        }}
                    >
                        <div className='flex items-center justify-between'>
                            <h2 className='text-[16px] font-bold text-[#5E8BFA] '>
                                Transactions volume
                            </h2>
                            <div className='hidden md:block rounded-[99px] p-[5px] cursor-pointer'
                                style={{
                                    background: 'rgba(2, 15, 50, 0.62)'
                                }}
                                onClick={() => setisGraphOpen(true)}
                            >
                                <h2 className='text-white text-[14px]'>
                                    {`< >`}
                                </h2>
                            </div>
                        </div>
                        {isFetching ? (
                            <div className='w-full h-[140px] animate-pulse'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.70)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            />
                        ) : (

                            <div className='w-full h-[140px] py-[10px]'
                                style={{
                                    borderRadius: '4px',
                                    background: 'rgba(2, 15, 49, 0.60)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            >
                                {!isGraphOpen && (
                                    <AreaGraph filterHistory={history && history.history} />
                                )}

                            </div>
                        )}


                        <div
                        >
                            <div className='h-[30px] px-[5px] w-fit mx-auto flex mt-[10px] gap-[10px] items-center rounded-[99px]'
                                style={{
                                    background: 'rgba(2, 15, 49, 0.60)',
                                    boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            >
                                <button className={`text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '1 week' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                    onClick={() => setactiveTime('1 week')}
                                >
                                    1 week
                                </button>

                                <button className={`text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '6 months' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                    onClick={() => setactiveTime('6 months')}
                                >
                                    6 months
                                </button>
                                <button className={`hidden sm:block text-white  text-[11px] font-normal w-[53px] xl:w-[58px] h-[16px] rounded-[99px]  ${activeTime === '1 year' ? 'bg-[#9747FF]' : 'bg-[#122758]'}`}
                                    onClick={() => {
                                        setactiveTime('1 year')
                                        setisGraphOpen(true)
                                    }}
                                >
                                    1 year
                                </button>

                            </div>
                        </div>
                    </div>
                    <div className={`lg:hidden  ${smallerthen1415 ? 'xl:hidden' : 'xl:block'}`}>
                        {slider2Loading ? (
                            <div
                                className='h-[230px] 2xl:h-[254px]'
                                style={{
                                    borderRadius: '5px',
                                    background: isDarkMode ? 'rgba(18, 39, 88, 0.56)' : 'rgb(31 41 55)',
                                    boxShadow: '0px 4px 4px 0px rgba(217, 217, 217, 0.19)'
                                }}
                            >
                                <div className='w-full h-full animate-pulse'
                                    style={{
                                        borderRadius: '4px',
                                        background: 'rgba(2, 15, 49, 0.7)',
                                        boxShadow: '0px 2px 4px 0px rgba(0, 0, 0, 0.25)'
                                    }}
                                />
                            </div>
                        ) : (
                            <div>
                                {slider2 && slider2.slider.length > 0 && (
                                    <ImageSlider data={slider2.slider} />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div >
    )
}

export default Layout(HomeScreen)