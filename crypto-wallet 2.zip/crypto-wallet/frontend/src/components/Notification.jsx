import React, { useContext, useEffect, useRef, useState } from 'react'
import bell from '../assets/bluebell.png'
import cross from '../assets/cross.png'
import TimeAgo from 'react-timeago'
import chevronDown from '../assets/chevron-down.png'
import chevronUp from '../assets/chevron-up.png'
import { motion } from 'framer-motion';
import StatesContext from '../context/StatesContext'
import { useNotificationsDeleteMutation, useNotificationsSeenMutation, useUpdatePaymentNotificationsMutation, useUserNotificationsQuery } from '../helpers/notificationApi'
import { CircularProgress, useMediaQuery } from '@mui/material'
import { pusherClient } from '../utils/pusher'
import { useNavigate } from 'react-router-dom'
import { BNB_CONTRACT_ABI, BNB_CONTRACT_ADDRESS, BUSD_ADRESS, CONTRACT_ABI, CONTRACT_ADDRESS, ETH_ADDRESS, TOKEN_ABI, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../constants/constants'
import { useAccount, useContractWrite, useNetwork } from 'wagmi'
import { ethers } from 'ethers'
import { prepareWriteContract, readContract, waitForTransaction, writeContract } from 'wagmi/actions'



const Notification = () => {

    const { address } = useAccount()

    const { chain } = useNetwork()

    const context = useContext(StatesContext)
    const { notifications, setnotifications, seterror, userData, setisApproved, onlineUsers, NotificationOpen, setisApprovedFailed, setNotificationOpen, notificationOpenStates, setNotificationOpenStates, notificationQuery, walletConnected, isComponentOpen, setisComponentOpen } = context

    const [filterNotifications, setfilterNotifications] = useState('')

    const { data, isFetching, refetch } = useUserNotificationsQuery((userData && userData._id && userData._id) || '')
    const [seenNotification, res] = useNotificationsSeenMutation()
    const [updatePayment, response] = useUpdatePaymentNotificationsMutation()
    const [deleteNotification, resp] = useNotificationsDeleteMutation()
    const [isLoading, setisLoading] = useState(false)
    const [clickedIndex, setclickedIndex] = useState('')

    const [approvedAmount, setapprovedAmount] = useState('')

    const smallerthen600 = useMediaQuery('(max-width:600px)')

    const navigate = useNavigate()

    // Function to toggle the open state of a specific notification box
    const toggleNotification = (index) => {

        setNotificationOpenStates((prevStates) => {
            const newStates = [...prevStates];
            newStates[index] = !prevStates[index];
            return newStates;
        });
    };


    // Refs for each notification box to get the actual content height
    const notificationRefs = useRef([]);

    const messageHandler = (message) => {

        setnotifications((current) => {
            if (find(current, { id: message.id })) {
                return current;
            }

            return [message, ...current]
        });

    };

    const handleClick = async (e, item) => {
        e.stopPropagation();
        setisLoading(true);

        try {

            const activeToken = item.tokenName

            if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
                if (chain && chain.id === 97) {
                    seterror('Switch you network to Ethereum')
                    setisLoading(false)
                    return
                }
            } else {
                if (chain && chain.id !== 97) {
                    seterror('Switch you network to BNB Smart Chain')
                    setisLoading(false)
                    return
                }
            }

            let tokenAddress = '';

            switch (item.tokenName) {
                case 'WBTC':
                    tokenAddress = WBTC_ADDRESS
                    break;
                case 'ETH':
                    tokenAddress = WBTC_ADDRESS
                    break;
                case 'BSUD':
                    tokenAddress = BUSD_ADRESS
                    break;
                case 'USDT':
                    tokenAddress = USDT_ADDRESS
                    break;
                case 'BNB':
                    tokenAddress = WBNB_ADDRESS
                    break;
                case 'USDC':
                    tokenAddress = USDC_ADDRESS
                    break;
                default:
                    break;
            }

            const tokenValue = await readContract({
                address: tokenAddress,
                abi: TOKEN_ABI,
                functionName: 'balanceOf',
                args: [address],
            })

            const requiredAmount = ethers.utils.parseUnits(item.amount.toString(), 'ether');

            setapprovedAmount(requiredAmount)

            if (Number(tokenValue) < Number(requiredAmount.toString())) {
                setisApprovedFailed(true)
                setisLoading(false)
                return;
            }

            const { request } = await prepareWriteContract({
                address: tokenAddress,
                abi: TOKEN_ABI,
                functionName: 'approve',
                args: [CONTRACT_ADDRESS, requiredAmount],
            })

            const { hash } = await writeContract(request)

            await waitForTransaction({
                confirmations: 1,
                hash
            })

            const { request: contractRqst } = await prepareWriteContract({
                address: CONTRACT_ADDRESS,
                abi: CONTRACT_ABI,
                functionName: 'transferTokens',
                args: [tokenAddress, item.senderId.walletAddress, requiredAmount]
            })

            const { hash: contractHash } = await writeContract(contractRqst)

            await waitForTransaction({
                confirmations: 1,
                hash: contractHash
            })

            updatePayment({ senderId: tokenAddress, createdAt: item.createdAt, amount: item.amount, tokenName: item.tokenName }).then(() => {
                setnotifications(prev => {
                    const updatedNotifications = prev.map(notification => {
                        if ((notification.senderId._id === item.senderId._id) && (new Date(notification.createdAt).getTime() === new Date(item.createdAt).getTime())) {
                            return {
                                ...notification,
                                type: 'approved'
                            };
                        } else {
                            return notification;
                        }
                    });
                    return updatedNotifications;
                });
            }).then(() => {
                setisApproved(true)
                setNotificationOpen(false)
                setisLoading(false)
                if (smallerthen600) {
                    setTimeout(() => {
                        window.location.reload()
                    }, 2000);
                }
            })

        } catch (error) {
            console.error('Error:', error);
        } finally {
            setisLoading(false);
        }
    };

    const formatDate = (date) => {
        const months = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ];

        const month = months[date.getMonth()];
        const day = date.getDate();
        const year = date.getFullYear();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        const formattedHours = hours % 12 || 12; // Convert to 12-hour format

        return `${month} ${day}, ${year} at ${formattedHours}:${minutes} ${ampm}`;
    }


    useEffect(() => {

        if (userData && userData._id) {

            pusherClient.subscribe(userData._id)
            pusherClient.bind('notifications:new', messageHandler)

        }

        return () => {
            if (userData && userData._id) {
                pusherClient.unsubscribe(userData._id)
                pusherClient.unbind('notifications:new', messageHandler)
            }
        }
    }, [userData]);

    useEffect(() => {
        if (notifications) {
            notificationRefs.current = notificationRefs.current.slice(0, notifications.length);
        }
    }, [notifications]);

    useEffect(() => {
        if (data && data.notifications.notifications.length > 0) {
            if (walletConnected && !notifications) {
                setnotifications(data.notifications.notifications)
                setNotificationOpenStates(data.notifications.notifications.map(() => true))
            }
        }
    }, [data, walletConnected])

    useEffect(() => {

        const handleScrollLock = () => {
            if (NotificationOpen && smallerthen600) {
                // Disable scrolling on the body element
                document.body.style.overflow = 'hidden';
            } else {
                // Enable scrolling on the body element
                document.body.style.overflow = 'unset';
            }
        };

        handleScrollLock();


        if (notifications && NotificationOpen) {
            setisComponentOpen(true)
        }

        if (!notificationQuery && notifications && notifications.some((notification) => notification.isSeen === false)) {

            if (!NotificationOpen && isComponentOpen) {
                setnotifications(prev => {
                    const updatedNotifications = prev.map(notification => ({
                        ...notification,
                        isSeen: true
                    }));
                    return updatedNotifications;
                });
                if (filterNotifications) {
                    setfilterNotifications(prev => {
                        const updatedNotifications = prev.map(notification => ({
                            ...notification,
                            isSeen: true
                        }));
                        return updatedNotifications;
                    });
                }

                seenNotification(userData && userData._id)
            }
        }

        return () => {
            document.body.style.overflow = 'unset';
        };

    }, [NotificationOpen, isComponentOpen])

    useEffect(() => {


        setfilterNotifications(notifications)


    }, [notifications, walletConnected])

    useEffect(() => {

        if (filterNotifications) {
            setNotificationOpenStates(filterNotifications.map(() => true))
        }

    }, [filterNotifications])

    useEffect(() => {

        if (notificationQuery && notifications) {
            setfilterNotifications(prev => notifications.filter(item => item.type === notificationQuery))
        } else {
            setfilterNotifications(notifications)
        }

    }, [notificationQuery, notifications])

    useEffect(() => {
        refetch()
    }, [walletConnected])

    const handleMessageClick = (item, i) => {

        if (item.conversationId) {

            setNotificationOpen(false)
            deleteNotification(item.createdAt)

            setnotifications(prev => prev.filter(value =>
                new Date(value.createdAt).getTime() !== new Date(item.createdAt).getTime()
            ));

            navigate(`/conversation/${item.conversationId} `, {
                state: {
                    name: item.senderId.name,
                    image: item.senderId.image,
                    walletAddress: item.senderId.walletAddress,
                    id: item.senderId._id,
                    fromChat: true
                }
            })

        } else {
            toggleNotification(i)
        }

        if (item.type === 'received') {
            navigate('/wallets')
            setNotificationOpen(false)
        }

        if (item.type === 'Received' || item.type === 'DeliveredService' || item.type === 'Approved') {

            let x = 'Received'
            if (item.type === 'DeliveredService') {
                x = 'Booked'
            }

            navigate('/orders', { state: { type: x } })
            setNotificationOpen(false)
        }
    }


    return (
        <>
            {NotificationOpen && (
                <div>
                    <motion.div
                        key="notification-box"
                        whileInView={{ x: [200, 0], opacity: [0, 1] }}
                        transition={{ duration: 1.0, ease: 'easeInOut' }}
                        className='absolute top-[90px] right-[10px] w-[330px]  max-h-[467px] py-[24px] px-[5px]'
                        style={{
                            background: 'rgba(2, 15, 50, 0.80)',
                            border: '1px solid #0C8CE9',
                            opacity: 0,
                            left: smallerthen600 && '10px',
                            margin: smallerthen600 && '0 auto'
                        }}
                    >

                        <div className="flex justify-between items-center gap-[20px] px-[10px]">
                            <div className="flex items-center gap-[10px]">
                                <img src={bell} alt="" />
                                <h2 className="text-[#F1F1F1] text-[9px] font-normal">NOTIFICATIONS</h2>
                            </div>
                            <img
                                src={cross}
                                alt=""
                                className="cursor-pointer"
                                onClick={() => setNotificationOpen(false)}
                            />
                        </div>

                        <div className="mt-[15px] space-y-[10px] pb-[1px] px-[10px] min-h-[350px] max-h-[350px] overflow-y-auto">
                            {isFetching && (
                                <div className='flex justify-center items-center h-[300px] '>
                                    <CircularProgress sx={{ color: 'white' }} />
                                </div>
                            )}
                            {filterNotifications && notificationOpenStates && filterNotifications.map((item, i) => {

                                let showChevron = false;

                                if ((item.message && item.message.length > 81) || item.type === 'approvals') {
                                    showChevron = true;
                                }

                                let isActive = false

                                if (onlineUsers && item.senderId && item.senderId.walletAddress) {
                                    isActive = onlineUsers.some((data) => data.userId === item.senderId.walletAddress);
                                }

                                return (
                                    <motion.div
                                        key={i}
                                        className="p-[10px] cursor-pointer min-h-[90px] overflow-hidden"
                                        onClick={() => handleMessageClick(item, i)}
                                        style={{
                                            border: '1px solid #0C8CE9',
                                            background: '#020F32',
                                        }}
                                        animate={{ height: !notificationOpenStates[i] ? 'auto' : '90px' }} // 62 is the initial height
                                        transition={{ duration: 0.1 }}
                                    >
                                        <div className="flex gap-[10px] items-center">
                                            <TimeAgo
                                                date={new Date(item.createdAt)}
                                                className="text-[#0C8CE9] text-[9px] font-normal"
                                            />
                                            {showChevron && (
                                                <div>
                                                    {notificationOpenStates[i] ? ( // Use the state to render the appropriate chevron icon
                                                        <img src={chevronDown} alt="" />
                                                    ) : (
                                                        <img src={chevronUp} alt="" />
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex justify-between items-center gap-[20px] mt-[5px]">
                                            <div className='max-w-[210px]'>
                                                {item.type === 'scheduled' || item.type === 'scheduledreceiver' ? (
                                                    <h2 className={`text-[12px]  ${item.isSeen === false ? 'font-extrabold text-white' : 'font-medium text-[#F1F1F1]'} `}>
                                                        Payment scheduled
                                                    </h2>
                                                ) : (

                                                    <h2 className={`text-[12px]  ${item.isSeen === false ? 'font-extrabold text-white' : 'font-medium text-[#F1F1F1]'} `}>
                                                        {!item.amount ? `${item.senderId && item.senderId.name}` : item.type === 'approved' ? 'Payment approved' : 'Payment confirmation'}
                                                    </h2>
                                                )}
                                                <p

                                                    className={`${!notificationOpenStates[i] ? '' : 'line-clamp-2'
                                                        } text-[11px] leading-[12px] mt-[5px] font-normal break-words ${item.isSeen === false ? 'text-white font-bold' : 'text-[#D9D9D9]'}`}
                                                    ref={(el) => (notificationRefs.current[i] = el)}
                                                >
                                                    {(item.type === 'scheduledreceiver' || item.type === 'Received') && item.senderId && `${item.senderId.name} `}
                                                    {!item.amount ? item.message : `You have sent ${item.amount} ${item.tokenName} to ${item.senderId && item.senderId.name}`}
                                                    {(item.type === 'received' || item.type === 'scheduled') && item.senderId && ` ${item.senderId.name}`}
                                                    {item.scheduledAt && ` on ${formatDate(new Date(item.scheduledAt))}`}
                                                </p>
                                            </div>
                                            <div className="flex-shrink-0 relative"
                                            >
                                                <img
                                                    src={item.senderId && item.senderId.image}
                                                    alt=""
                                                    className="h-[36px] w-[36px] rounded-full"
                                                    style={{
                                                        border: '1px solid rgba(12, 140, 233, 0.60)',
                                                    }}
                                                />
                                                {isActive && (
                                                    <div className="absolute top-0 right-0">
                                                        <div className="w-[10px] h-[10px] bg-[#28C95F] rounded-full" />
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        {!notificationOpenStates[i] && item.type === 'approvals' && (
                                            <div className={`mt-[5px] relative z-40 pl-[1px] sm:pl-0`}>
                                                <button
                                                    className="text-[11px] disabled:cursor-not-allowed font-normal text-[#0C8CE9] h-[30px] w-[60px] border-[0.5px] border-[#0C8CE9]"
                                                    onClick={(e) => {
                                                        setclickedIndex(i)
                                                        handleClick(e, item)
                                                    }}
                                                    disabled={isLoading}
                                                >
                                                    {(response.isLoading || isLoading) && clickedIndex === i ? <CircularProgress size={17} sx={{ color: '#0C8CE9' }} /> : 'APPROVE'}
                                                </button>
                                            </div>
                                        )}
                                    </motion.div>
                                );
                            })}

                            {!isFetching && filterNotifications.length === 0 && (
                                <motion.div
                                    whileInView={{ opacity: [0, 1] }}
                                    transition={{ duration: 0.7, ease: 'easeInOut', delay: 0.2 }}
                                    initial='hidden'
                                    className='flex justify-center items-center h-[300px]'
                                    viewport={{ once: true }}
                                    style={{
                                        opacity: 0
                                    }}
                                >
                                    <h2 className='text-white text-[12px] text-center font-semibold'>
                                        {!notificationQuery && 'No notifications found!'}
                                        {notificationQuery === 'approvals' && 'No approval requests found!'}
                                        {notificationQuery === 'Unread' && 'No unread messages found!'}
                                        {notificationQuery === 'announcements' && 'No announcements found!'}

                                    </h2>
                                </motion.div>
                            )}

                        </div>

                    </motion.div >
                </div>
            )}
        </>
    )
}

export default Notification