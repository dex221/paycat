import React, { useContext, useState } from 'react';
import sun from '../assets/sun.png';
import moon from '../assets/moon.png';
import StatesContext from '../context/StatesContext';
import { useLocation } from 'react-router-dom';

const DarkToggle = () => {


    const context = useContext(StatesContext)
    const { isDarkMode, setisDarkMode, walletConnected } = context

    const { pathname } = useLocation()

    const [slidingEffect, setSlidingEffect] = useState('');

    const handleClick = () => {
        if (isDarkMode) {
            setSlidingEffect('translate-x-[-47px] sm:translate-x-[-60px] duration-500');
        } else {
            setSlidingEffect('translate-x-[47px] sm:translate-x-[60px] duration-500');
        }

        setTimeout(() => {
            setisDarkMode(!isDarkMode)
            setSlidingEffect('')
        }, 400);

    };

    return (
        <div
            className={`w-[80px] sm:w-[105px] h-[30px] sm:h-[42px] cursor-pointer rounded-[99px] transition-all duration-200 ${isDarkMode ? 'bg-[#9747FF]' : 'bg-white'
                }`}
            onClick={handleClick}
        >
            {isDarkMode ? (
                <div className={`flex items-center justify-end mr-[2px] mt-[1px] ${pathname !== '/' && walletConnected && 'lg:mt-[2px]'} `}>
                    <div
                        className={`h-[28px] sm:h-[40px] w-[28px] sm:w-[40px] flex items-center justify-center rounded-full bg-[#020F32] ${slidingEffect}`}
                    >
                        <img src={moon} alt="" className='h-[15px] sm:h-[25px]' />
                    </div>
                </div>
            ) : (
                <div className={`flex items-center justify-start ml-[2px] mt-[1px] ${pathname !== '/' && walletConnected && 'lg:mt-[2px]'} ${slidingEffect}`}>
                    <div className="h-[28px] sm:h-[40px] w-[28px] sm:w-[40px] flex items-center justify-center rounded-full bg-[#C0B128]">
                        <img src={sun} alt="" className='h-[15px] sm:h-[25px]' />
                    </div>
                </div>
            )
            }
        </div >
    );
};

export default DarkToggle;
