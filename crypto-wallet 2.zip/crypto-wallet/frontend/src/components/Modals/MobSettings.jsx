import React from 'react'
import cross from '../../assets/cross.png'
import { motion } from 'framer-motion';
import { Cog6ToothIcon, XMarkIcon } from '@heroicons/react/24/solid';
import DarkToggle from '../DarkToggle';


const MobSettings = ({ setmobSettings }) => {
    return (
        <div>
            <motion.div
                key="notification-box"
                whileInView={{ x: [200, 0], opacity: [0, 1] }}
                transition={{ duration: 1.0, ease: 'easeInOut' }}
                className='fixed top-[90px] right-[10px] w-[250px] px-[5px] z-50'
                style={{
                    background: 'rgba(2, 15, 50, 0.80)',
                    border: '1px solid #0C8CE9',
                    opacity: 0,
                    left: '10px',
                    margin: '0 auto'
                }}
            >

                <div className="flex justify-between items-center gap-[20px] mx-[10px] border-b border-[#0C8CE9] py-[10px]">
                    <div className="flex items-center gap-[10px]">
                        <Cog6ToothIcon className='text-white h-[20px]' />
                        <h2 className="text-[#F1F1F1] text-[11px] font-normal">Settings</h2>
                    </div>
                    <XMarkIcon
                        onClick={() => setmobSettings(false)}
                        className='text-white h-[16px]'
                    />
                </div>
                <div className='flex justify-between items-center px-[10px] py-[15px]'>
                    <h2 className='text-white font-medium text-[16px]'>
                        Dark Mode
                    </h2>
                    <DarkToggle />
                </div>
            </motion.div>
        </div>
    )
}

export default MobSettings