import React, { useContext, useEffect, useRef, useState } from 'react'
import { Box, CircularProgress, Rating, styled, useMediaQuery } from '@mui/material'
import { ChatBubbleLeftIcon, XMarkIcon } from '@heroicons/react/24/solid'
import bnb from '../../assets/tokens/bnb.png'
import bsud from '../../assets/tokens/bsud.png'
import usdc from '../../assets/tokens/usdc.png'
import wbtc from '../../assets/tokens/wbtc.png'
import eth from '../../assets/ethchain.png'
import usdt from '../../assets/tokens/usdt.png'
import ServiceImageSlider from '../sliders/ServiceImageSlider'
import { motion } from 'framer-motion';

import { Swiper, SwiperSlide } from 'swiper/react'
import 'swiper/css';
import 'swiper/css/navigation';
import { Navigation } from 'swiper/modules';
import ShippingModal from './ShippingModal'
import { useNavigate } from 'react-router-dom'
import StatesContext from '../../context/StatesContext'
import { useGetconversationIdMutation } from '../../helpers/contactApi'
import { useCreateViewMutation, useGetSimilarCategoryQuery, useGetSimilarServicesQuery } from '../../helpers/ServiceApi'
import MarketplaceCard from '../MarketplaceCard'
import ReviewsContainer from '../ReviewsContainer'
import BigImageSlider from '../sliders/BigImageSlider'


const StyledmageSection = styled(Box)(({ theme }) => ({
  '.swiper-button-prev, .swiper-button-next': {
    display: 'none'
  },

}));

const ServiceDetail = ({ setserviceDetailOpen, serviceData, CoinsPrice, CoinPriceLoading, setserviceData, setisCardClicked }) => {

  const context = useContext(StatesContext)
  const { userData, walletConnected, setnotConntedOpen, setconnectAction } = context

  const swiperRef = useRef(null)

  const [currentSlide, setCurrentSlide] = useState(0)
  const [openShippingModal, setopenShippingModal] = useState(false)
  const [data, setdata] = useState([])
  const [activeToken, setactiveToken] = useState()
  const [activeTokenImage, setactiveTokenImage] = useState('')
  const [activePrice, setactivePrice] = useState()
  const [page, setpage] = useState(1)
  const [otherUserServicesData, setotherUserServicesData] = useState('')
  const [bigSliderOPen, setbigSliderOPen] = useState(false)

  const [categoryPage, setcategoryPage] = useState(1)
  const [categoryData, setcategoryData] = useState('')
  const [isClicked, setisClicked] = useState(false)

  const navigate = useNavigate()

  let userId = (serviceData && serviceData.user._id) || ''
  let serviceId = (serviceData && serviceData._id) || ''
  let category = (serviceData && serviceData.category) || ''

  if (category) {
    category = encodeURIComponent(category)
  }

  const [createAndGetConvoId, res] = useGetconversationIdMutation()
  const { data: otherUserServices, isFetching } = useGetSimilarServicesQuery({ userId, page, serviceId })
  const { data: similarData, isFetching: SimilarLoading } = useGetSimilarCategoryQuery({ userId, page: categoryPage, category })
  const [createView] = useCreateViewMutation()


  const handleClick = () => {
    if (walletConnected) {
      if (userData && userData._id !== serviceData.user._id) {
        createAndGetConvoId(serviceData.user._id)
      }
    } else {
      setconnectAction(`Chat`)
      setnotConntedOpen(true)
    }
  }

  useEffect(() => {

    if (data && data.length > 0) {
      swiperRef.current.swiper.slideTo(currentSlide);
    }

  }, [currentSlide]);

  useEffect(() => {
    if (serviceData) {
      let images = []
      for (let i = 0; i < serviceData.images.length; i++) {
        images.push({
          img: serviceData.images[i]
        })

      }
      setdata(images)
      setactiveToken(serviceData.paymentCoin[0])

      createView(serviceData._id)
    }

  }, [serviceData])


  useEffect(() => {

    let img
    let ActiveTokenPrice

    switch (activeToken) {
      case 'WBTC':
        img = wbtc
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.wbtcUsd).toFixed(3)
        }
        break;
      case 'ETH':
        img = eth
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.ethUsd).toFixed(3)
        }
        break;
      case 'BSUD':
        img = bsud
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.busdUsd).toFixed(3)
        }
        break;
      case 'USDT':
        img = usdt
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.usdtUsd).toFixed(3)
        }
        break;
      case 'BNB':
        img = bnb
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.wbnbUsd).toFixed(3)
        }
        break;
      case 'USDC':
        img = usdc
        if (CoinsPrice) {
          ActiveTokenPrice = (serviceData.price / CoinsPrice.usdcUsd).toFixed(3)
        }
        break;

      default:
        break;
    }

    setactiveTokenImage(img)
    setactivePrice(ActiveTokenPrice)

  }, [activeToken, CoinsPrice])

  useEffect(() => {

    if (res.status === 'fulfilled') {
      navigate(`/conversation/${res.data.conversationId} `, {
        state: {
          name: serviceData.user.name,
          image: serviceData.user.image,
          walletAddress: serviceData.user.walletAddress,
          id: serviceData.user._id,
          fromChat: true,
          fromMarketPlace: true
        }
      })
      setserviceDetailOpen(false)
      setisClicked(false)
    }

    if (otherUserServices) {
      if (!otherUserServicesData) {
        setotherUserServicesData(otherUserServices)
      } else {
        setotherUserServicesData((prev) => {
          return {
            ...prev,
            services: [...prev.services, ...otherUserServices.services],
          };
        });
      }
    }
  }, [res, otherUserServices])

  useEffect(() => {

    if (similarData) {
      if (!categoryData) {
        setcategoryData(similarData)
      } else {
        setcategoryData((prev) => {
          return {
            ...prev,
            services: [...prev.services, ...similarData.services],
          };
        });
      }
    }

  }, [similarData])


  return (
    <div>

      <BigImageSlider
        open={bigSliderOPen}
        setopen={setbigSliderOPen}
        image={data.length > 0 && data[currentSlide].img}
      />

      <motion.div
        whileInView={{ opacity: [0, 1] }}
        transition={{ duration: 0.2, ease: 'easeInOut', delay: 0.2 }}
        initial='hidden'
        viewport={{ once: true }}
        className="fixed top-0 left-0 w-full h-full z-40"
        style={{
          opacity: 0,
          backgroundColor: 'rgba(12, 140, 233, 0.10)',
        }}
      />
      <motion.div
        whileInView={{ opacity: [0, 1] }}
        transition={{ duration: 0.2, ease: 'easeInOut', delay: 0.2 }}
        initial='hidden'
        viewport={{ once: true }}
        className='fixed z-50 left-[0px] lg:left-[135px] 2xl:left-[170px] lg:right-[6%] right-[0px] top-[75px] sm:top-[90px] lg:top-[30px] bottom-[0px] lg:bottom-[20px] overflow-auto'
        style={{
          opacity: 0,
          border: '1px solid #000',
          background: '#020F32',
          boxShadow: '-4px 0px 4px 0px rgba(0, 0, 0, 0.25)'
        }}
      >
        <div className='relative'>
          {openShippingModal && (
            <ShippingModal setopenShippingModal={setopenShippingModal} coinList={serviceData.paymentCoin} serviceData={serviceData} CoinsPrice={CoinsPrice} />
          )}

          <div className='px-[25px] py-[20px] border-b border-white'>
            <div className='flex justify-between items-center'>
              <div className='flex justify-between items-center min-w-[220px] sm:min-w-[280px]'>
                <div className='flex items-center gap-[5px] cursor-pointer'
                  onClick={() => {
                    navigate(`/user/${serviceData.user._id}`)
                  }}
                >
                  <img src={serviceData.user.image} alt="" className='object-cover rounded-full w-[35px] h-[35px] border border-[#9747FF]' />
                  <div>
                    <h2 className='text-[13px] font-normal text-white'>
                      {serviceData.user.name.length > 30 ? `${serviceData.user.name.substring(0, 30)}...` : serviceData.user.name}
                    </h2>
                    <h6 className='text-white text-[8px]'>
                      {serviceData.user.walletAddress.substring(0, 15)}...
                    </h6>
                  </div>
                </div>
                <div className=' flex  flex-col sm:flex-row gap-[5px] pt-[12px] sm:pt-0 sm:items-center'>
                  <Rating name="read-only" value={serviceData.ratings} precision={0.5} readOnly
                    style={{
                      color: '#9747FF',
                      fontSize: '17px'

                    }}
                    sx={{
                      '& .MuiRating-iconEmpty': {
                        color: '#9747FF',  // Change color of non-active star
                        borderColor: '#9747FF !important', // Change border color of non-active star
                      },
                    }}
                  />

                  <h2 className='text-[10px] font-light text-right '
                    style={{
                      color: 'rgba(217, 217, 217, 0.50)'
                    }}
                  >
                    ({serviceData.totalReviews}) rates
                  </h2>
                </div>
              </div>
              <div className='flex justify-center gap-[20px] sm:gap-[50px]'>
                {(res.isLoading && isClicked) ? <CircularProgress sx={{ color: 'white' }} size={20} /> : (
                  <ChatBubbleLeftIcon className='text-white h-[25px] cursor-pointer'
                    onClick={() => {
                      setisClicked(true)
                      handleClick()
                    }
                    }
                  />
                )}
                <XMarkIcon className='text-white h-[21px] cursor-pointer' onClick={() => setserviceDetailOpen(false)} />
              </div>
            </div>
          </div>

          <div className='p-[20px]'>

            <div className='flex gap-[30px] lg:gap-[70px] flex-col md:flex-row'>
              <div className='flex-1 flex-shrink-0'>
                <div className='md:hidden'>
                  <StyledmageSection>
                    <Swiper
                      onActiveIndexChange={(value) => setCurrentSlide(value.activeIndex)}
                      slidesPerView={1}
                      spaceBetween={15}
                      modules={[Navigation]}
                      navigation
                      ref={swiperRef}
                    >
                      {data.map((item, i) => (
                        <SwiperSlide key={i}
                          className='h-[250px] sm:h-[300px] md:h-[400px] xl:h-[500px] w-full rounded-[10px]'
                          onClick={() => setbigSliderOPen(true)}
                        >
                          <img src={item.img} alt="" className='h-full w-full object-cover rounded-[10px]' />
                        </SwiperSlide>
                      ))}
                    </Swiper>
                  </StyledmageSection>
                </div>
                <img src={data.length > 0 && data[currentSlide].img} alt="" onClick={() => setbigSliderOPen(true)} className='h-[200px] hidden cursor-pointer object-cover md:flex sm:h-[300px] md:h-[400px] xl:h-[500px] w-full rounded-[10px]' />
                <div className='mt-[25px]'>
                  <ServiceImageSlider data={data} currentSlide={currentSlide} setCurrentSlide={setCurrentSlide} />
                </div>
              </div>

              <div className='flex-[0.6]'>
                <h2 className='text-white text-[16px] xl:text-[20px] font-bold leading-[25px] break-words w-[99%]'>
                  {serviceData.title}
                </h2>
                <div className='mt-[6px] grid grid-cols-2 items-center gap-[30px]'>
                  <div className='flex items-center gap-[5px]'>
                    {CoinPriceLoading ? (
                      <div className='h-[33px] xl:h-[38px] w-[120px] xl:w-[148px] animate-pulse rounded-[3px]'
                        style={{
                          backgroundColor: 'rgba(151, 71, 255,0.7)'
                        }}
                      />
                    ) : (
                      <h6 className='text-[25px] xl:text-[32px] text-[#9747FF] font-semibold'>
                        {activePrice}
                      </h6>
                    )}

                    <img src={activeTokenImage} alt="" className='xl:h-[35px] h-[30px] w-[30px] xl:w-[35px] rounded-full border border-[#9747FF]' />
                  </div>

                  <div className='flex gap-[5px] flex-wrap'>
                    {serviceData && serviceData.paymentCoin.map((item, i) => {

                      let img

                      switch (item) {
                        case 'WBTC':
                          img = wbtc
                          break;
                        case 'ETH':
                          img = eth
                          break;
                        case 'BSUD':
                          img = bsud
                          break;
                        case 'USDT':
                          img = usdt
                          break;
                        case 'BNB':
                          img = bnb
                          break;
                        case 'USDC':
                          img = usdc
                          break;

                        default:
                          break;
                      }

                      return (
                        <img
                          src={img}
                          key={i}
                          alt=""
                          className='xl:h-[25px] h-[20px] cursor-pointer w-[20px] xl:w-[25px] rounded-full border border-[#9747FF]'
                          onClick={(e) => {
                            setactiveToken(item)
                          }}
                        />
                      )
                    })}
                  </div>
                </div>
                <h6 className='text-[13px] text-[#9747FF] font-semibold'>
                  {serviceData.price} $
                </h6>

                <div className='mt-[6px] flex justify-between items-center gap-[20px]'>
                  <div className='flex items-center gap-[6px]'>
                    <h2 className='text-[10px]'
                      style={{
                        color: 'rgba(255, 255, 255, 0.60)',
                      }}
                    >
                      {serviceData.country}
                    </h2>
                  </div>
                  <div className='flex flex-wrap gap-[3px]'>
                    {serviceData && serviceData.category.map((item, i) => (
                      <div key={i}>
                        <div className='border border-[#038AE8] px-[5px] py-[2px] rounded-[99px]' key={i}>
                          <h2 className='text-white text-[7px]'>
                            {item}
                          </h2>
                        </div>

                      </div>
                    ))}
                  </div>
                </div>
                <div className='w-full'>
                  <div className='h-[270px] xl:h-[350px] overflow-y-auto'>
                    <h2 className='text-white text-[11px] xl:text-[14px]  mt-[10px] w leading-[20px] break-words'>
                      {serviceData.desc}
                    </h2>
                  </div>
                </div>
                <button
                  className='w-full disabled:cursor-not-allowed mt-[30px] h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                  onClick={() => {
                    if (walletConnected) {
                      setopenShippingModal(true)
                    } else {
                      setconnectAction(`book order`)
                      setnotConntedOpen(true)
                    }
                  }}
                  disabled={userData && userData._id === serviceData.user._id}
                >
                  ORDER NOW
                </button>
                <button
                  className='w-full disabled:cursor-not-allowed mt-[15px] h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                  onClick={() => handleClick()}
                  disabled={res.isLoading || (userData && userData._id === serviceData.user._id)}                >
                  {res.isLoading && !isClicked ? <CircularProgress size={20} sx={{ color: 'white' }} /> : 'CHAT NOW'}
                </button>
              </div>

            </div>

            <div className='lg:hidden mt-[30px]'>
              <ReviewsContainer serviceId={serviceId} userId={serviceData.user._id} />
            </div>

            <div className='flex gap-[30px] lg:gap-[70px] flex-col md:flex-row mt-[50px]'>
              <div className='flex-1 flex-shrink-0'>
                <h2 className={`text-white font-bold text-[20px] ${otherUserServicesData && otherUserServicesData.services.length === 0 && 'hidden'}`}>
                  Others products from {serviceData.user.name}
                </h2>
                {!otherUserServicesData ? (
                  <div className='flex justify-center my-[50px]'>
                    <CircularProgress sx={{ color: 'white' }} size={27} />
                  </div>
                ) : (
                  <div>
                    {otherUserServicesData && otherUserServicesData.services.length > 0 && (
                      <div>
                        <div className='grid grid-cols-1 sm:grid-cols-2 2xl:grid-cols-3 gap-[20px] mt-[20px]'>
                          {otherUserServicesData.services.map((item, i) => (
                            <div key={i}
                              onClick={() => {
                                setserviceData(item)
                                setisCardClicked(true)
                              }}
                            >
                              <MarketplaceCard isOther={true} serviceData={item} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} />
                            </div>
                          ))}
                        </div>
                        {!isFetching && otherUserServicesData && page < otherUserServicesData.totalPages && (
                          <div className='my-[40px] flex justify-center'>
                            <h2 className='text-center text-[14px] text-white bg-gray-700 w-fit px-[15px] py-[4px] rounded-[5px] cursor-pointer'
                              onClick={() => setpage(prev => prev + 1)}
                            >
                              Show More
                            </h2>
                          </div>
                        )}

                        {isFetching && (
                          <div className='my-[40px] flex justify-center'>
                            <CircularProgress sx={{ color: 'white' }} size={29} />
                          </div>
                        )}

                      </div>
                    )}
                  </div>
                )}


                <h2 className={`text-white font-bold text-[20px] ${otherUserServicesData && otherUserServicesData.services.length !== 0 && 'mt-[30px]'} ${categoryData && categoryData.services.length === 0 && 'hidden'} `}>
                  Similars products
                </h2>

                {!categoryData ? (
                  <div className='flex justify-center my-[50px]'>
                    <CircularProgress sx={{ color: 'white' }} size={27} />
                  </div>
                ) : (
                  <div>
                    {categoryData && categoryData.services.length > 0 && (
                      <div>
                        <div className='grid grid-cols-1 sm:grid-cols-2 2xl:grid-cols-3  gap-[20px] mt-[20px]'>
                          {categoryData.services.map((item, i) => (
                            <div key={i}
                              onClick={() => {
                                setserviceData(item)
                                setisCardClicked(true)
                              }}
                            >
                              <MarketplaceCard isOther={true} serviceData={item} CoinsPrice={CoinsPrice} CoinPriceLoading={CoinPriceLoading} />
                            </div>
                          ))}
                        </div>
                        {!SimilarLoading && categoryData && categoryPage < categoryData.totalPages && (
                          <div className='my-[40px] flex justify-center'>
                            <h2 className='text-center text-[14px] text-white bg-gray-700 w-fit px-[15px] py-[4px] rounded-[5px] cursor-pointer'
                              onClick={() => setcategoryPage(prev => prev + 1)}
                            >
                              Show More
                            </h2>
                          </div>
                        )}

                        {SimilarLoading && (
                          <div className='my-[40px] flex justify-center'>
                            <CircularProgress sx={{ color: 'white' }} size={29} />
                          </div>
                        )}

                      </div>
                    )}
                  </div>
                )}

              </div>
              <div className='lg:flex-[0.6] hidden lg:block'>
                <div>
                  <ReviewsContainer serviceId={serviceId} userId={serviceData.user._id} />
                </div>
              </div>
            </div>


          </div>
        </div>
      </motion.div >

    </div >
  )
}

export default ServiceDetail