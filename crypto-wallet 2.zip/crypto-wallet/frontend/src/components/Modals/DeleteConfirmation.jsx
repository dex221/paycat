import React, { useContext, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useDeleteServiceAdminMutation, useDeleteServiceMutation } from '../../helpers/ServiceApi';
import { CircularProgress } from '@mui/material';
import StatesContext from '../../context/StatesContext';


const DeleteConfirmation = ({ open, setopen, serviceId }) => {

    const [deleteService, res] = useDeleteServiceMutation()
    const [deleteServiceAdmin, response] = useDeleteServiceAdminMutation()

    const context = useContext(StatesContext)
    const { setsuccess, userData } = context

    const handleClick = () => {

        if (userData && userData.isAdmin) {
            deleteServiceAdmin(serviceId)
        } else {
            deleteService(serviceId)
        }

    }

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setopen(false)
            setsuccess('Service deleted successfully!')
        }
        if (response.status === 'fulfilled') {
            setopen(false)
            setsuccess('Service deleted successfully!')
        }

    }, [res, response])




    return (
        <div>
            {open && (
                <div
                    className="fixed top-0 left-0 w-full h-full z-30"
                    style={{
                        backgroundColor: 'rgba(12, 140, 233, 0.05)',
                    }}
                    onClick={() => setopen(false)}
                />
            )}

            {open && (
                <div
                    className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full z-[9999]  max-w-[600px]"
                >
                    <motion.div
                        whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                        transition={{ duration: 0.5, ease: 'easeInOut' }}
                        initial='hidden'
                        style={{ opacity: 0 }}
                        viewport={{ once: true }}
                    >
                        <div
                            className='w-[95%] mx-auto sm:w-[400px] bg-[#020F32] border border-[#000] rounded-[10px] py-[10px]'
                            style={{
                                boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)'
                            }}

                        >
                            <div className='w-[325px] mx-auto py-[15px]'>
                                <h2 className='text-white text-[16px] text-center '>
                                    Are you sure you want to delete this service?
                                </h2>
                                <div className='flex justify-end gap-[10px] mt-[10px]'>
                                    <button
                                        className='w-[70px] h-[25px] bg-gray-500 text-white text-[14px] font-semibold rounded-[5px]'
                                        onClick={() => {
                                            setopen(false)
                                        }
                                        }
                                    >
                                        No
                                    </button>
                                    <button
                                        className='w-[70px] h-[25px] bg-[#0C8CE9] disabled:cursor-not-allowed text-white text-[14px] font-semibold rounded-[5px]'
                                        onClick={() => handleClick()}
                                        disabled={res.isLoading}
                                    >
                                        {res.isLoading ? <CircularProgress sx={{ color: 'white' }} size={17} /> : 'Yes'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};

export default DeleteConfirmation;
