import { XMarkIcon } from '@heroicons/react/24/solid'
import React, { useContext, useEffect, useState } from 'react'
import CustomSelect from '../CustomSelect'
import { Country } from 'country-state-city'
import { motion } from 'framer-motion';
import StatesContext from '../../context/StatesContext';
import { useCreateOrdersMutation } from '../../helpers/OrderApi';
import { CircularProgress } from '@mui/material';
import { useAccount, useNetwork } from 'wagmi';
import { BNB_CONTRACT_ABI, BNB_CONTRACT_ADDRESS, BUSD_ADRESS, ETH_ADDRESS, ETH_CONTRACT_ABI, ETH_CONTRACT_ADDRESS, TOKEN_ABI, USDC_ADDRESS, USDT_ADDRESS, WBNB_ADDRESS, WBTC_ADDRESS } from '../../constants/constants';
import { ethers } from 'ethers';
import { readContract, waitForTransaction, writeContract, prepareWriteContract } from 'wagmi/actions';

const ShippingModal = ({ setopenShippingModal, coinList, serviceData, CoinsPrice }) => {

    const { address } = useAccount()

    const { chain } = useNetwork()

    const context = useContext(StatesContext)
    const { seterror, setsuccess, setisApprovedFailed } = context

    const [country, setcountry] = useState('')
    const [coins, setcoins] = useState('')
    const [email, setemail] = useState('')
    const [number, setnumber] = useState('')
    const [homeAddress, sethomeAddress] = useState('')
    const [loading, setloading] = useState(false)


    const [isCountryOpen, setisCountryOpen] = useState(false)
    const [iscoinsOpen, setiscoinsOpen] = useState(false)

    const [createOrders, res] = useCreateOrdersMutation()

    const handleSubmit = async (e) => {


        e.preventDefault()

        if (!country) {
            seterror('Country is required')
        } else if (!coins) {
            seterror('Payment Coin is required')
        } else {

            try {

                setloading(true)

                const activeToken = coins

                if (activeToken === 'WBTC' || activeToken === 'ETH' || activeToken === 'USDT' || activeToken === 'USDC') {
                    if (chain && chain.id === 97) {
                        seterror('Switch you network to Ethereum')
                        setloading(false)
                        return
                    }
                } else {
                    if (chain && chain.id !== 97) {
                        seterror('Switch you network to BNB Smart Chain')
                        setloading(false)
                        return
                    }
                }

                let tokenAddress = '';
                let ActiveTokenPrice
                let contractAddress
                let contractAbi

                switch (coins) {
                    case 'WBTC':
                        tokenAddress = WBTC_ADDRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.wbtcUsd).toFixed(8)
                        }
                        contractAddress = ETH_CONTRACT_ADDRESS
                        contractAbi = ETH_CONTRACT_ABI
                        break;
                    case 'ETH':
                        tokenAddress = ETH_ADDRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.ethUsd).toFixed(8)
                        }
                        contractAddress = ETH_CONTRACT_ADDRESS
                        contractAbi = ETH_CONTRACT_ABI
                        break;
                    case 'BSUD':
                        tokenAddress = BUSD_ADRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.busdUsd).toFixed(8)
                        }
                        contractAddress = BNB_CONTRACT_ADDRESS
                        contractAbi = BNB_CONTRACT_ABI
                        break;
                    case 'USDT':
                        tokenAddress = USDT_ADDRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.usdtUsd).toFixed(8)
                        }
                        contractAddress = ETH_CONTRACT_ADDRESS
                        contractAbi = ETH_CONTRACT_ABI
                        break;
                    case 'BNB':
                        tokenAddress = WBNB_ADDRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.wbnbUsd).toFixed(8)
                        }
                        contractAddress = BNB_CONTRACT_ADDRESS
                        contractAbi = BNB_CONTRACT_ABI
                        break;
                    case 'USDC':
                        tokenAddress = USDC_ADDRESS
                        if (CoinsPrice) {
                            ActiveTokenPrice = (serviceData.price / CoinsPrice.usdcUsd).toFixed(8)
                        }
                        contractAddress = ETH_CONTRACT_ADDRESS
                        contractAbi = ETH_CONTRACT_ABI
                        break;
                    default:
                        break;
                }

                const tokenValue = await readContract({
                    address: tokenAddress,
                    abi: TOKEN_ABI,
                    functionName: 'balanceOf',
                    args: [address],
                })

                const requiredAmount = ethers.utils.parseUnits(ActiveTokenPrice.toString(), 'ether');

                if (Number(tokenValue) < Number(requiredAmount.toString())) {
                    setisApprovedFailed(true)
                    setloading(false)
                    return;
                }

                const { request } = await prepareWriteContract({
                    address: tokenAddress,
                    abi: TOKEN_ABI,
                    functionName: 'approve',
                    args: [contractAddress, requiredAmount],
                })

                const { hash } = await writeContract(request)

                await waitForTransaction({
                    hash,
                    confirmations: 1
                })

                const randomFraction = Math.random();

                // Get the current timestamp in milliseconds
                const timestamp = new Date().getTime();

                // Combine the random number and timestamp to create a unique ID
                const uniqueID = Math.floor(randomFraction * timestamp);

                const { request: contractRqst } = await prepareWriteContract({
                    address: contractAddress,
                    abi: contractAbi,
                    functionName: 'FundIntoEscrow',
                    args: [serviceData.user.walletAddress, uniqueID, tokenAddress, requiredAmount]
                })

                const { hash: contractHash } = await writeContract(contractRqst)

                await waitForTransaction({
                    hash: contractHash,
                    confirmations: 1
                })

                createOrders({
                    country,
                    receivedBy: serviceData.user._id,
                    serviceId: serviceData._id,
                    payment: serviceData.price,
                    email,
                    number,
                    orderId: uniqueID,
                    address: homeAddress,
                    paymentCoin: coins,
                    title: serviceData.title
                })

            } catch (error) {
                console.log(error)
                // setisApprovedFailed(true)
            }
            finally {
                setloading(false)
            }

        }
    }

    useEffect(() => {

        if (isCountryOpen) {
            setiscoinsOpen(false)
        }

    }, [isCountryOpen])

    useEffect(() => {

        if (iscoinsOpen) {
            setisCountryOpen(false)
        }

    }, [iscoinsOpen])

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setsuccess('Order booked successfully')
            setopenShippingModal(false)
        }

    }, [res])



    return (
        <div>
            <div
                className="fixed inset-0 w-full h-full z-30 "
                style={{
                    backgroundColor: 'rgba(12, 140, 233, 0.10)',
                }}
            />
            <motion.div
                whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                initial='hidden'
                style={{ opacity: 0 }}
                className='fixed inset-0 flex items-center justify-center z-40'
                viewport={{ once: true }}
            >
                <div className='mx-[20px] sm:mx-0 w-full sm:w-[500px] '
                    style={{
                        border: '1px solid #000',
                        background: '#020F32',
                        boxShadow: '-4px 0px 4px 0px rgba(0, 0, 0, 0.25)'
                    }}
                >
                    <div className='px-[20px] py-[15px] border-b border-white'>
                        <div className='flex justify-between items-center'>
                            <h2 className=' text-[18px] font-bold text-white'>
                                Enter Shipping Details
                            </h2>
                            <div>
                                <XMarkIcon className='text-white h-[21px] cursor-pointer' onClick={() => setopenShippingModal(false)} />
                            </div>
                        </div>
                    </div>

                    <form onSubmit={(e) => handleSubmit(e)} className='py-[30px] px-[20px] space-y-[20px]'>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setemail(e.target.value)}
                            placeholder='Enter your email'
                            required
                            className='placeholder:text-[#D9D9D980] w-full h-[44px] px-[15px] text-white bg-transparent outline-none text-[15px]  font-normal border border-[#D9D9D980] rounded-[10px]'

                        />
                        <input
                            type="number"
                            value={number}
                            onChange={(e) => setnumber(e.target.value)}
                            required
                            placeholder='Enter your number'
                            className='placeholder:text-[#D9D9D980] w-full h-[44px] px-[15px] text-white bg-transparent outline-none text-[15px] font-normal border border-[#D9D9D980] rounded-[10px]'
                        />
                        <input
                            type="text"
                            required
                            value={homeAddress}
                            onChange={(e) => sethomeAddress(e.target.value)}
                            placeholder='Enter your address'
                            className='placeholder:text-[#D9D9D980] w-full h-[44px] px-[15px] text-white bg-transparent outline-none text-[15px] font-normal border border-[#D9D9D980] rounded-[10px]'
                        />
                        <div className='relative z-20'>
                            <div className='relative z-20'>
                                <CustomSelect
                                    open={isCountryOpen}
                                    setopen={setisCountryOpen}
                                    value={country}
                                    onChange={(newValue) => setcountry(newValue)}
                                    options={Country && Country.getAllCountries()}
                                    isCountry={true}
                                    isShippingModal={true}
                                />
                            </div>
                            {!country && (
                                <div className='absolute top-0 bottom-0 left-[50px] flex items-center'>
                                    <h2 className='text-[#D9D9D980] text-[15px] font-normal'>
                                        Choose your country
                                    </h2>
                                </div>
                            )}
                        </div>
                        <div className='relative z-10'>
                            <div
                                className='relative z-10'
                            >
                                <CustomSelect
                                    open={iscoinsOpen}
                                    setopen={setiscoinsOpen}
                                    value={coins}
                                    onChange={(newValue) => setcoins(newValue)}
                                    options={coinList}
                                    fullHeight={true}
                                />
                            </div>
                            {!coins && (
                                <div className='absolute top-0 bottom-0 left-[50px] flex items-center'>
                                    <h2 className='text-[#D9D9D980] text-[15px] font-normal'>
                                        Select Payment Coin
                                    </h2>
                                </div>
                            )}
                        </div>
                        <div className='pt-[20px] py-[5px]'>
                            <button
                                className='w-full  h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                                type='submit'
                            >
                                {res.isLoading || loading ? <CircularProgress sx={{ color: 'white' }} size={20} /> : 'BOOK NOW'}
                            </button>
                        </div>
                    </form>

                </div>
            </motion.div>
        </div>
    )
}

export default ShippingModal