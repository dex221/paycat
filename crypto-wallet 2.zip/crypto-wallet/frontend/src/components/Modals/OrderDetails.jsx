import { XMarkIcon } from '@heroicons/react/24/solid'
import React from 'react'
import { motion } from 'framer-motion';


const OrderDetails = ({ setopen, orderData , receivedBy }) => {
    return (
        <div>
            <div
                className="fixed inset-0 w-full h-full z-30 "
                style={{
                    backgroundColor: 'rgba(12, 140, 233, 0.10)',
                }}
            />
            <motion.div
                whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                initial='hidden'
                style={{ opacity: 0 }}
                className='fixed inset-0 flex items-center justify-center z-40'
                viewport={{ once: true }}
            >
                <div className='mx-[20px] sm:mx-0 w-full sm:w-[500px] '
                    style={{
                        border: '1px solid #000',
                        background: '#020F32',
                        boxShadow: '-4px 0px 4px 0px rgba(0, 0, 0, 0.25)'
                    }}
                >
                    <div className='px-[20px] py-[15px] border-b border-white'>
                        <div className='flex justify-between items-center'>
                            <h2 className=' text-[17px] font-bold text-white'>
                                Order Details
                            </h2>
                            <div>
                                <XMarkIcon className='text-white h-[21px] cursor-pointer' onClick={() => setopen(false)} />
                            </div>
                        </div>
                    </div>

                    <div className='px-[30px] py-[25px] space-y-[15px]'>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px] flex-shrink-0'>
                                Service Title :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] line-clamp-2 break-words w-[70%]'>
                                {orderData.title}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px]'>
                                Email :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] line-clamp-1'>
                                {orderData.email}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px]'>
                                Number :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] '>
                                {orderData.number}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px]'>
                                Token Name :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] '>
                                {orderData.paymentCoin}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px]'>
                                Amount :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] '>
                                $ {orderData.payment}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px]'>
                                Country :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px]'>
                                {orderData.country}
                            </h2>
                        </div>
                        <div className='flex gap-[20px] items-center'>
                            <h2 className='text-white font-medium text-[17px] w-[110px] flex-shrink-0'>
                                Address :
                            </h2>
                            <h2 className='text-gray-200 font-medium text-[14px] break-words w-[90%] sm:w-[70%]'>
                                {orderData.address}
                            </h2>
                        </div>
                    </div>

                </div>
            </motion.div>
        </div>
    )
}

export default OrderDetails