import React, { useContext, useState } from 'react';
import { XMarkIcon } from '@heroicons/react/24/solid';
import { Box, CircularProgress } from '@mui/material';
import { motion } from 'framer-motion';
import exclamation from '../../assets/home/exclamation-circle.png'
import StatesContext from '../../context/StatesContext';


const NotConnectedModal = ({ open, setOpen, handleMetamaskLogin, loading }) => {

    const context = useContext(StatesContext)
    const { connectAction } = context


    return (
        <div>
            {open && (
                <div
                    className="fixed top-0 left-0 w-full h-full z-30"
                    style={{
                        backgroundColor: 'rgba(12, 140, 233, 0.10)',
                    }}
                    onClick={() => setOpen(false)}
                ></div>
            )}

            {open && (
                <div
                    className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full z-40  max-w-[600px]"
                >
                    <motion.div
                        whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                        transition={{ duration: 0.5, ease: 'easeInOut' }}
                        initial='hidden'
                        style={{ opacity: 0 }}
                        viewport={{ once: true }}
                    >
                        <div className='w-[90%] mx-auto sm:w-[450px] lg:w-[500px] xl:w-[550px] 2xl:w-[660px] bg-[#020F32] border border-[#000] rounded-[15px]'
                            style={{
                                boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)'
                            }}

                        >
                            <div className='flex justify-center mt-[35px]'>
                                <img src={exclamation} alt="" className='h-[55px] sm:h-[70px] 2xl:h-[90px]' />
                            </div>
                            <h2 className=' text-center text-[20px] sm:text-[25px] 2xl:text-[32px] font-bold text-[#5E8BFA] mt-[20px]'>
                                Connect to the dapp
                            </h2>
                            <p className='text-center text-white text-[12px] sm:text-[14px] 2xl:text-[18px]  font-bold'>
                                connect to the dapp to {connectAction} !
                            </p>
                            <div className='flex justify-center mt-[20px] mb-[30px] sm:mb-[45px]'>
                                <button
                                    className='w-[110px] sm:w-[138px] h-[30px] sm:h-[34px] bg-[#0C8CE9] text-white text-[12px] sm:text-[14px] font-bold rounded-[10px]'
                                    onClick={() => handleMetamaskLogin()}
                                >
                                    {loading ? <CircularProgress size={21} sx={{ color: 'white' }} /> : 'Connect Wallet'}
                                </button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};

export default NotConnectedModal;
