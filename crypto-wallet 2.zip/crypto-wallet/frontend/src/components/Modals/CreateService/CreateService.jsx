import { XMarkIcon } from '@heroicons/react/24/solid'
import React, { useEffect, useState } from 'react'
import ServiceImageSlider from '../../sliders/ServiceImageSlider'
import plus from '../../../assets/plus.png'
import CreateServiceForm from './CreateServiceForm'
import { motion } from 'framer-motion';


const CreateService = ({ setcreateServiceOpen, serviceData, isEditService, open }) => {

    const [currentSlide, setCurrentSlide] = useState(0)

    const [data, setdata] = useState([])

    const handleImageChnage = (e) => {

        const reader = new FileReader()
        reader.onload = () => {
            if (reader.readyState === 2) {
                let comingdata = {
                    img: reader.result
                }

                setdata(prev => [...prev, comingdata])
            }
        }
        reader.readAsDataURL(e.target.files[0])
    }

    useEffect(() => {

        if (serviceData) {
            let images = []
            for (let i = 0; i < serviceData.images.length; i++) {
                images.push({
                    img: serviceData.images[i]
                })

            }
            setdata(images)
        }

    }, [serviceData])


    return (
        <div>
            {open && (
                <div>
                    <motion.div
                        whileInView={{ opacity: [0, 1] }}
                        transition={{ duration: 0.2, ease: 'easeInOut', delay: 0.2 }}
                        initial='hidden'
                        viewport={{ once: true }}
                        className="fixed top-0 left-0 w-full h-full z-40"
                        style={{
                            opacity: 0,
                            backgroundColor: 'rgba(12, 140, 233, 0.10)',
                        }}
                        onClick={() => setcreateServiceOpen(false)}
                    />

                    <motion.div
                        whileInView={{ opacity: [0, 1] }}
                        transition={{ duration: 0.2, ease: 'easeInOut', delay: 0.2 }}
                        initial='hidden'
                        viewport={{ once: true }}
                        className='fixed z-50 left-[10px] lg:left-[9%] lg:right-[6%] right-[10px] top-[75px] sm:top-[90px] lg:top-[30px] bottom-[0px] sm:bottom-[20px] overflow-auto'
                        style={{
                            opacity: 0
                        }}
                    >
                        <div
                            className='2xl:flex items-center h-full w-full '
                        >
                            <div
                                className=' w-full'
                                style={{
                                    border: '1px solid #000',
                                    background: '#020F32',
                                    boxShadow: '-4px 0px 4px 0px rgba(0, 0, 0, 0.25)'
                                }}
                            >
                                <div className='px-[20px] py-[15px] border-b border-white'>
                                    <div className='flex justify-between items-center'>
                                        <h2 className=' text-[18px] font-bold text-white'>
                                            {isEditService ? 'Service Details' : 'What do you want to sell ?'}
                                        </h2>
                                        <div>
                                            <XMarkIcon className='text-white h-[21px] cursor-pointer' onClick={() => setcreateServiceOpen(false)} />
                                        </div>
                                    </div>
                                </div>

                                <div className='p-[20px]'>
                                    <div className='flex gap-[30px] lg:gap-[70px] flex-col md:flex-row'>

                                        <div className='flex-1 flex-shrink-0'>
                                            {data && data.length === 0 ? (
                                                <div className='h-[200px] sm:h-[300px] md:h-[400px] xl:h-[500px] w-full object-cover rounded-[10px] border border-gray-500 flex justify-center items-center'
                                                >
                                                    <label>
                                                        <div id='image' className='h-[58px] w-[69px] rounded-[10px]  border border-gray-500 flex justify-center items-center cursor-pointer'
                                                        >
                                                            <img src={plus} alt="" />
                                                        </div>
                                                        <input
                                                            type="file"
                                                            htmlFor="image"
                                                            className='hidden'
                                                            accept=".jpg, .jpeg, .png, .gif"
                                                            onChange={(e) => handleImageChnage(e)}
                                                        />
                                                    </label>
                                                </div>
                                            ) : (

                                                <img src={data[currentSlide].img} alt=""
                                                    className='h-[200px] sm:h-[300px] md:h-[400px] xl:h-[500px] w-full object-cover rounded-[10px]'
                                                />
                                            )}
                                            <div className='mt-[25px]'>
                                                <ServiceImageSlider data={data} currentSlide={currentSlide} setCurrentSlide={setCurrentSlide} isCreateService={true} setdata={setdata} />
                                            </div>
                                        </div>

                                        <div className='flex-[0.6]'>
                                            <CreateServiceForm data={data} setcreateServiceOpen={setcreateServiceOpen} serviceData={serviceData} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </div >
    )
}

export default CreateService