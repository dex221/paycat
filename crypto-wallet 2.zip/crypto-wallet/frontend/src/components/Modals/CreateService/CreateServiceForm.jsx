import { Box, CircularProgress, styled } from '@mui/material';
import React, { useContext, useEffect, useState } from 'react'
import { XMarkIcon } from '@heroicons/react/24/solid';

import bnb from '../../../assets/tokens/bnb.png'
import bsud from '../../../assets/tokens/bsud.png'
import eth from '../../../assets/tokens/eth.png'
import usdc from '../../../assets/tokens/usdc.png'
import usdt from '../../../assets/tokens/usdt.png'
import wbtc from '../../../assets/tokens/wbtc.png'

import CustomSelect from '../../CustomSelect';
import { Country } from 'country-state-city';
import StatesContext from '../../../context/StatesContext';
import { useCreateServiceMutation, useUpdateServiceMutation } from '../../../helpers/ServiceApi';


const categoriesData = [
    "Services",
    "Phone & tablet",
    "Smart Watches",
    "Art&Decoration",
    "Computers",
    "Jewelry & Watches",
    "Fashion & Accessories",
    "Home & Garden",
    "Motors",
    "For Free",
    "Video games",
    "Baby & Toys",
    "Multimedia",
    "Job offer",
    "Books/DVD’s",
    "Property",
    "Other",
    'All categories'
];

const coinsData = [
    {
        name: 'WBTC',
        img: wbtc,

    },
    {
        name: 'ETH',
        img: eth,

    },
    {
        name: 'BSUD',
        img: bsud,

    },
    {
        name: 'USDC',
        img: usdc,

    },
    {
        name: 'USDT',
        img: usdt,

    },
    {
        name: 'BNB',
        img: bnb,

    },
]


const CreateServiceForm = ({ data, setcreateServiceOpen, serviceData }) => {

    const context = useContext(StatesContext)
    const { seterror, setsuccess } = context


    const [categories, setcategories] = useState('')
    const [categoriesList, setcategoriesList] = useState([])
    const [coins, setcoins] = useState('')
    const [coinsList, setcoinsList] = useState([])
    const [isCountryOpen, setisCountryOpen] = useState(false)
    const [isCtaegoryOpen, setisCtaegoryOpen] = useState(false)
    const [iscoinsOpen, setiscoinsOpen] = useState(false)
    const [country, setcountry] = useState('')
    const [title, settitle] = useState('')
    const [price, setprice] = useState()
    const [desc, setdesc] = useState('')
    const [loading, setloading] = useState(false)

    const [createService, res] = useCreateServiceMutation()
    const [updateService, response] = useUpdateServiceMutation()

    useEffect(() => {

        if (serviceData) {
            settitle(serviceData.title)
            setdesc(serviceData.desc)
            setcountry(serviceData.country)
            setprice(serviceData.price)
            setcategoriesList(serviceData.category)

            let coinData = []

            for (let i = 0; i < serviceData.paymentCoin.length; i++) {
                let coinsImage
                switch (serviceData.paymentCoin[i]) {
                    case 'WBTC':
                        coinsImage = wbtc
                        break;
                    case 'ETH':
                        coinsImage = eth
                        break;
                    case 'USDT':
                        coinsImage = usdt
                        break;
                    case 'USDC':
                        coinsImage = usdc
                        break;
                    case 'BSUD':
                        coinsImage = bsud
                        break;
                    case 'BNB':
                        coinsImage = bnb
                        break;

                    default:
                        break;
                }
                coinData.push({
                    name: serviceData.paymentCoin[i],
                    img: coinsImage
                })
            }

            setcoinsList(coinData)
        }

    }, [serviceData])


    const handleClick = (item) => {
        setcategoriesList(prev => prev.filter((value) => value != item))
    }
    const handleCoinDel = (item) => {
        setcoinsList(prev => prev.filter((value) => value.name != item.name))
    }

    const CloudinaryUploader = async (file) => {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('upload_preset', 'ojipiz6u');
        const rqst = await fetch(`https://api.cloudinary.com/v1_1/${import.meta.env.VITE_API_CLOUD_NAME}/auto/upload`, {
            method: 'POST',
            body: formData,
        })

        const res = await rqst.json()
        return {
            imageUrl: res.secure_url
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (categoriesList.length === 0) {
            seterror('Select atleast one category')
        } else if (coinsList.length === 0) {
            seterror('Select atleast one coin')
        } else if (!country) {
            seterror('Country is required')
        } else if (data.length === 0) {
            seterror('Select atleast one image')
        } else {

            try {

                setloading(true)
                let images = []
                if (serviceData) {
                    for (let i = 0; i < data.length; i++) {
                        if (data[i].img.startsWith('data:image')) {
                            const { imageUrl } = await CloudinaryUploader(data[i].img)
                            images.push(imageUrl);
                        } else {
                            images.push(data[i].img);
                        }
                    }
                } else {
                    for (let i = 0; i < data.length; i++) {
                        const { imageUrl } = await CloudinaryUploader(data[i].img);
                        images.push(imageUrl);
                    }
                }

                let paymentCoin = []

                for (let i = 0; i < coinsList.length; i++) {
                    paymentCoin.push(coinsList[i].name);

                }
                if (serviceData) {
                    updateService({ images, title, category: categoriesList, paymentCoin, price, country, desc, id: serviceData._id })
                } else {
                    createService({ images, title, category: categoriesList, paymentCoin, price, country, desc })
                }
            } catch (error) {
                console.log(error)
            } finally {
                setloading(false)
            }

        }
    }

    useEffect(() => {
        if (categories && !categoriesList.includes(categories)) {
            setcategoriesList(prev => [...prev, categories]);
        }

    }, [categories]);

    useEffect(() => {
        if (categoriesList.length === 0) {
            setcategories('')
        }
        if (coinsList.length === 0) {
            setcoins('')
        }
    }, [categoriesList, coinsList])

    useEffect(() => {

        if (coins && !coinsList.some(coin => coin.name === coins)) {
            let coinsImage
            switch (coins) {
                case 'WBTC':
                    coinsImage = wbtc
                    break;
                case 'ETH':
                    coinsImage = eth
                    break;
                case 'USDT':
                    coinsImage = usdt
                    break;
                case 'USDC':
                    coinsImage = usdc
                    break;
                case 'BSUD':
                    coinsImage = bsud
                    break;
                case 'BNB':
                    coinsImage = bnb
                    break;

                default:
                    break;
            }
            setcoinsList(prev => [...prev, { name: coins, img: coinsImage }])

        }

    }, [coins])

    useEffect(() => {

        if (isCountryOpen) {
            setiscoinsOpen(false)
            setisCtaegoryOpen(false)
        }

    }, [isCountryOpen])

    useEffect(() => {

        if (iscoinsOpen) {
            setisCountryOpen(false)
            setisCtaegoryOpen(false)
        }

    }, [iscoinsOpen])

    useEffect(() => {

        if (isCtaegoryOpen) {
            setisCountryOpen(false)
            setiscoinsOpen(false)
        }

    }, [isCtaegoryOpen])

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setsuccess('Service created successfully!')
            setcreateServiceOpen(false)
        }

        if (response.status === 'fulfilled') {
            setsuccess('Service updated successfully!')
            setcreateServiceOpen(false)
        }

    }, [res , response])


    return (
        <form onSubmit={(e) => handleSubmit(e)} className='w-full xl:w-[90%] space-y-[25px]'>

            <input
                type="text"
                required
                value={title}
                onChange={(e) => settitle(e.target.value)}
                placeholder='Type the title . . .'
                className='placeholder:text-[#D9D9D980] w-full h-[44px] px-[15px] text-white bg-transparent outline-none text-[15px]  font-normal border border-[#D9D9D980] rounded-[10px]'

            />

            <div>
                <div>
                    <div className='relative z-30 '>
                        <div className='relative z-30 '>
                            <CustomSelect
                                open={isCtaegoryOpen}
                                setopen={setisCtaegoryOpen}
                                value={categories}
                                onChange={(newValue) => setcategories(newValue)}
                                options={categoriesData}
                                createForm={true}
                            />
                        </div>
                        {!categories && (
                            <div className='absolute top-0 bottom-0 left-0 flex items-center'>
                                <h2 className='text-[15px] pl-[18px]  font-normal text-[#D9D9D980]'>
                                    Add a category . . .
                                </h2>
                            </div>
                        )}

                    </div>
                    {categoriesList.length > 0 && (
                        <div className='mt-[10px] flex gap-[10px] flex-wrap'>
                            {categoriesList.map((item, i) => (
                                <div key={i} className='flex items-center gap-[5px] bg-[#122758] border border-[#038AE8] rounded-[99px] py-[2px] px-[5px]'
                                >
                                    <h2 className='text-white text-[9px] font-normal'>
                                        {item}
                                    </h2>
                                    <XMarkIcon className='text-white h-[12px] cursor-pointer'
                                        onClick={() => handleClick(item)}
                                    />
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <div className='relative'>
                <input
                    type="number"
                    value={price}
                    required
                    onChange={(e) => setprice(e.target.value)}
                    placeholder='Type the price'
                    className='placeholder:text-[#D9D9D980] w-full h-[44px] px-[15px] text-white bg-transparent outline-none text-[15px]  font-normal border border-[#D9D9D980] rounded-[10px]'

                />
                <div className='absolute top-0 bottom-0 right-0 w-[70px] flex justify-center items-center'
                    style={{
                        borderRadius: '0px 9px 9px 0px',
                        background: 'rgba(3, 138, 232, 0.18)'
                    }}
                >
                    <h2 className='text-[15px] font-normal text-[#D9D9D980] '>
                        USD
                    </h2>
                </div>
            </div>

            <div>
                <div
                    className='relative z-20 '
                >
                    <div className='relative z-20'>
                        <CustomSelect
                            open={iscoinsOpen}
                            setopen={setiscoinsOpen}
                            value={coins}
                            onChange={(newValue) => setcoins(newValue)}
                            options={coinsData}
                            createForm={true}
                        />
                    </div>
                    {!coins && (
                        <div className='absolute top-0 bottom-0 left-0 flex items-center'>
                            <h2 className='text-[15px] pl-[18px]  font-normal text-[#D9D9D980]'>
                                Add a payment coin
                            </h2>
                        </div>
                    )}
                </div>
                {coinsList.length > 0 && (
                    <div className='mt-[10px] flex gap-[10px] flex-wrap'>
                        {coinsList.map((item, i) => (
                            <div key={i} className='flex items-center gap-[5px] bg-[#122758] border border-[#038AE8] rounded-[99px] py-[2px] px-[5px]'
                            >
                                <img src={item.img} alt="" className='h-[17px]' />
                                <h2 className='text-white text-[9px] font-normal'>
                                    {item.name}
                                </h2>
                                <XMarkIcon className='text-white h-[14px] cursor-pointer'
                                    onClick={() => handleCoinDel(item)}
                                />
                            </div>
                        ))}
                    </div>
                )}
            </div>
            <div>
                <div
                    className='relative z-10 '
                >
                    <div className='relative z-10'>
                        <CustomSelect
                            open={isCountryOpen}
                            setopen={setisCountryOpen}
                            value={country}
                            onChange={(newValue) => setcountry(newValue)}
                            options={Country && Country.getAllCountries()}
                            isCountry={true}
                            createForm={true}
                        />
                    </div>
                    {!country && (
                        <div className='absolute top-0 bottom-0 left-0 flex items-center'>
                            <h2 className='text-[15px] pl-[18px]  font-normal text-[#D9D9D980]'>
                                Choose a country
                            </h2>
                        </div>
                    )}
                </div>

            </div>

            <textarea
                className='w-full px-[18px] py-[10px] h-[220px] rounded-[10px] bg-transparent outline-none text-white placeholder:text-[#D9D9D980] text-[15px]  font-normal'
                placeholder='Type the description . . .'
                value={desc}
                onChange={(e) => setdesc(e.target.value)}
                required
                style={{
                    border: '1px solid rgba(217, 217, 217, 0.50)',
                    resize: 'none'
                }}
            />

            <button
                className='w-full mt-[30px] h-[34px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700 text-[14px] font-bold rounded-[10px] text-white'
                type='submit'
                disabled={loading}
            >
                {loading ? <CircularProgress sx={{ color: 'white' }} size={20} /> : (serviceData ? 'Update' : 'PUT ON SELL')}
            </button>

        </form>
    )
}

export default CreateServiceForm