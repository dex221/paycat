import React, { useContext, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import metamask from '../../assets/metmask.png'
import connect from '../../assets/connect.png'
import trustWallet from '../../assets/trsuWallet.png'
import { useWeb3Modal } from '@web3modal/react';
import { useAccount, useDisconnect } from 'wagmi';
import { disconnect } from 'wagmi/actions';
import { BACKEND_URL } from '../../constants/constants';
import StatesContext from '../../context/StatesContext';
import { useLocation, useNavigate } from 'react-router-dom';

const WalletsModel = ({ open, setopen, setloading }) => {

    const context = useContext(StatesContext)
    const { setnotConntedOpen, setwalletConnected, setuserData } = context
    let { pathname } = useLocation()

    const [reloadRequired, setreloadRequired] = useState(false)


    const { open: modalOpen, isOpen } = useWeb3Modal()
    const { address, isConnected } = useAccount()

    const navigate = useNavigate()

    const handleMetamaskLogin = async () => {

        setloading(true)

        if (isConnected) {
            await disconnect()
        }

        try {

            setreloadRequired(true)
            await modalOpen()
            localStorage.setItem('ButtonClicked', true)

        } catch (error) {
            console.error(error);
        }
        finally {
            setloading(false)
        }
    }

    useEffect(() => {

        if (isConnected && localStorage.getItem('ButtonClicked')) {
            setloading(true)
            try {
                const connectFunction = async () => {

                    const data = { address };

                    const authResponse = await fetch(`${BACKEND_URL}/api/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(data)
                    });

                    const { token, user } = await authResponse.json();

                    if (user) {
                        setnotConntedOpen(false)
                        setwalletConnected(true)
                        setreloadRequired(false)
                        if (pathname === '/') {
                            navigate('/dashboard')
                        }
                        sessionStorage.setItem('Token', token);
                        setuserData(user)
                    }
                }
                connectFunction()
            } catch (error) {
                console.log(error)
            }
            finally {
                setloading(false)
                localStorage.removeItem('ButtonClicked')
            }
        }

    }, [isConnected])

    // useEffect(() => {

    //     if (!isOpen && reloadRequired && !isConnected) {
    //         window.location.reload()
    //     }

    // }, [isOpen])


    return (
        <div className={`${!open && 'hidden'}`}>
            {open && (
                <div
                    className="fixed top-0 left-0 w-full h-full z-30"
                    style={{
                        backgroundColor: 'rgba(12, 140, 233, 0.05)',
                    }}
                    onClick={() => setopen(false)}
                />
            )}

            {open && (
                <div
                    className="fixed bottom-[5px] lg:bottom-[unset] left-0 right-0 lg:top-1/2 lg:left-1/2 lg:transform lg:-translate-x-1/2 lg:-translate-y-1/2 w-full z-[9999]  max-w-[600px]"
                >
                    <motion.div
                        whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                        transition={{ duration: 0.5, ease: 'easeInOut' }}
                        initial='hidden'
                        style={{ opacity: 0 }}
                        viewport={{ once: true }}
                    >
                        <div
                            className='w-[95%] mx-auto sm:w-[400px] bg-[#020F32] border border-[#000] rounded-[10px] py-[10px]'
                            style={{
                                boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)'
                            }}

                        >
                            <div className='w-[325px] mx-auto py-[15px]'>
                                <h2 className='text-white text-[16px]'>
                                    From which wallet you would like to connect?
                                </h2>
                                <div className='flex items-center justify-between space gap-[10px] mt-[20px]'>
                                    <div className='flex flex-col items-center cursor-pointer gap-[10px]'
                                        onClick={() => {
                                            window.open('https://metamask.app.link/paycat.app')
                                            setopen(false)
                                        }}
                                    >
                                        <img src={metamask} alt="" className='h-[60px] w-[60px] rounded-full' />
                                        <h2 className='text-white text-[12px]'>
                                            MetaMask
                                        </h2>
                                    </div>
                                    <div className='flex flex-col items-center cursor-pointer gap-[10px]'
                                        onClick={() => {
                                            window.open('https://link.trustwallet.com/open_url?url=https://www.paycat.app')
                                            setopen(false)
                                        }}
                                    >
                                        <img src={trustWallet} alt="" className='h-[60px] w-[60px] rounded-full' />
                                        <h2 className='text-white text-[12px]'>
                                            Trust Wallet
                                        </h2>
                                    </div>
                                    <div className='flex flex-col items-center cursor-pointer gap-[10px]'
                                        onClick={() => {
                                            let fromModel = true
                                            handleMetamaskLogin(fromModel)
                                            setopen(false)
                                        }}
                                    >
                                        <img src={connect} alt="" className='h-[60px] w-[60px] rounded-full' />
                                        <h2 className='text-white text-[12px]'>
                                            Wallet Connect
                                        </h2>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};

export default WalletsModel;
