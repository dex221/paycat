import React, { useContext, useEffect, useRef, useState } from 'react'
import { ArrowDownTrayIcon, ArrowLeftIcon, XMarkIcon } from '@heroicons/react/24/solid'
import { motion } from 'framer-motion';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { useAllConversationQuery } from '../helpers/conversationApi';
import { CircularProgress, Tooltip, useMediaQuery } from '@mui/material';
import StatesContext from '../context/StatesContext';
import { pusherClient } from '../utils/pusher';
import { useNotificationTypeReadUpdateMutation } from '../helpers/notificationApi';
import ValueLabelComponent from './ValueLabelComponent';
import axios from 'axios';

import backIcon from '../assets/back-icon.png'

const ChatBox = ({ setopenChatBox, fileName, progress, setfileName, setprogress, fromChat }) => {

    const context = useContext(StatesContext)
    const { userData, onlineUsers, notifications, setnotifications, setlastMessage, chatHistoryOpen, setchatHistoryOpen, contactOpen } = context

    const [messages, setMessages] = useState('')
    const [isUserActive, setisUserActive] = useState('')
    const [activeIndex, setactiveIndex] = useState('')
    const [downloadingProgress, setdownloadingProgress] = useState('')
    const [clickedIndex, setclickedIndex] = useState('')
    const [isChanging, setisChanging] = useState(false)

    let { state } = useLocation()
    const { id } = useParams()
    const smallerthen415 = useMediaQuery('(max-width:415px)')
    const smallerthen1024 = useMediaQuery('(max-width:1024px)')
    const navigate = useNavigate()

    const { data, isFetching, refetch } = useAllConversationQuery(id)
    const [updateNotification, res] = useNotificationTypeReadUpdateMutation()

    const formatDate = (date) => {
        const options = {
            weekday: 'short',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
        };

        return new Date(date).toLocaleDateString('en-US', options);
    };

    const bottomRef = useRef();


    const handleDownload = async (fileUrl, filename) => {
        try {
            const response = await axios({
                url: fileUrl,
                method: 'GET',
                responseType: 'arraybuffer',
                onDownloadProgress: (progressEvent) => {
                    const loadedBytes = progressEvent.loaded;
                    const totalBytes = progressEvent.total;
                    const progress = (loadedBytes / totalBytes) * 100;
                    if (filename) {
                        setdownloadingProgress(Math.floor(progress));
                        if (progress === 100) {
                            setdownloadingProgress('')
                        }
                    }
                }
            });

            const blob = new Blob([response.data], { type: response.headers['content-type'] });
            const blobUrl = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = blobUrl;
            a.download = filename || 'downloaded_file';
            document.body.appendChild(a);

            a.click();
            document.body.removeChild(a);

            URL.revokeObjectURL(blobUrl); // Clean up after the download

            a.href = ''
            a.click()

        } catch (error) {
            console.error('Error downloading file:', error);
        }
    };


    useEffect(() => {

        if (onlineUsers) {
            let isActive = onlineUsers.some((data) => data.userId === state.walletAddress);
            setisUserActive(isActive)
        }

    }, [onlineUsers])


    useEffect(() => {

        pusherClient.subscribe(id)

        const messageHandler = (message) => {

            if (message.filename) {
                setfileName('')
                setprogress('')
            }

            setMessages((current) => {
                if (find(current, { id: message.id })) {
                    return current;
                }

                return [...current, message]
            });

            bottomRef.current.scrollIntoView({ block: 'nearest' });
        };

        pusherClient.bind('messages:new', messageHandler)

        return () => {
            pusherClient.unsubscribe(id)
            pusherClient.unbind('messages:new', messageHandler)
        }
    }, [id]);

    useEffect(() => {

        if (data && data.conversations && data.conversations.messages.length > 0) {
            setMessages(data.conversations.messages)
            bottomRef.current?.scrollIntoView({ block: 'nearest' });
            setisChanging(false)
        } else {
            setMessages('')
        }

    }, [data, isChanging, id])

    useEffect(() => {
        if (messages) {
            bottomRef.current?.scrollIntoView({ block: 'nearest' });
        }
    }, [messages, bottomRef, fileName])

    useEffect(() => {

        if (notifications && notifications.some((notification) => notification.senderId._id === state.id && notification.type === 'Unread')) {

            setnotifications(prev => {
                const updatedNotifications = prev.map(notification => {
                    if (notification.senderId._id === state.id && notification.type === 'Unread') {
                        return {
                            ...notification,
                            type: 'read'
                        };
                    } else {
                        return notification;
                    }
                });
                return updatedNotifications;
            });

            updateNotification(state.id)
        }

    }, [notifications])

    useEffect(() => {
        setMessages('')
        refetch().then(() => {
            setisChanging(true)

            if (data && data.conversations && data.conversations.messages.length > 0) {
                setMessages(data.conversations.messages)
            }

            bottomRef.current?.scrollIntoView({ block: 'nearest' })
            if (messages.length > 0) {
                const getLastMessage = messages[messages.length - 1]
                setlastMessage(prev => {
                    return {
                        conversationId: id,
                        message: getLastMessage.message ? messages : getLastMessage.image ? 'Sent an picture' : 'Sent an document',
                        createdAt: getLastMessage.createdAt,
                        userData: {
                            _id: state._id,
                            name: state.name,
                            image: state.image,
                            walletAddress: state.walletAddress
                        },
                        unreadCount: 0
                    }
                })
            }
        })

    }, [])

    useEffect(() => {
        if (!chatHistoryOpen || !contactOpen) {
            refetch().then(() => {

                bottomRef.current?.scrollIntoView({ block: 'nearest' });
            })
        }
    }, [id, chatHistoryOpen, contactOpen])


    return (


        <div
            className={`${fromChat ? 'absolute top-[40px] lg:top-[75px] left-0 right-0 bottom-0' : 'absolute bottom-[-58px] z-30 right-[20px] sm:right-[20px] left-[20px] sm:left-[20px] flex justify-end'}  `}
        >
            <div>
                {fromChat && (
                    <div className={`fixed top-[70px] z-20 left-0 right-0 px-[25px] flex items-center gap-[15px] lg:hidden py-[12px] border-b border-white bg-gray-600 dark:bg-transparent`}>

                        <img src={backIcon} alt="" className='h-[28px]' onClick={() => {
                            if (state.fromMarketPlace) {
                                navigate('/')
                            } else {
                                setchatHistoryOpen(true)
                            }
                        }} />
                        <div
                            className='flex items-center gap-[12px] cursor-pointer rounded-[10px]'
                        >
                            <div className='relative h-[36px] w-[36px]'>
                                <img src={state.image} alt="" className='rounded-full border border-[#FFF3F3] h-full w-full object-cover' />
                                {isUserActive && (
                                    <div className='absolute top-0 right-0'>
                                        <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                    </div>
                                )}
                            </div>

                            <div>
                                <h2 className='text-white font-semibold text-[13px]'>
                                    {state.name}
                                </h2>
                                <p className='text-[#D9D9D980] text-[10px] font-light'>
                                    {state.walletAddress.substring(0, 12)}...
                                </p>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            <div className={fromChat ? `w-full h-full ${smallerthen1024 && 'fixed top-[133px] left-0 right-0 bottom-[125px] z-40'} ` : `${smallerthen415 ? 'h-[70vh]' : 'h-[80vh]'} lg:h-[450px] xl:h-[550px] 2xl:h-[717px] w-full max-w-[1000px] mx-auto  py-[26px] px-[15px]`}
                style={{
                    border: !fromChat && '2px solid #0C8CE9',
                    background: 'rgba(2, 15, 50, 0.80)',
                    boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)',
                    borderTopRightRadius: !fromChat && '20px',
                    borderTopLeftRadius: !fromChat && '20px',
                    borderBottomColor: 'transparent'
                }}
            >
                <div className={`flex items-center justify-between ${fromChat && 'hidden'}`}>
                    <div
                        className='flex items-center gap-[12px] cursor-pointer rounded-[10px]'
                    >
                        <ValueLabelComponent img={state.image} >
                            <div className='relative h-[36px] w-[36px]'>
                                <img src={state.image} alt="" className='rounded-full border border-[#FFF3F3] h-full w-full object-cover' />
                                {isUserActive && (
                                    <div className='absolute top-0 right-0'>
                                        <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                    </div>
                                )}
                            </div>
                        </ValueLabelComponent>
                        <div>
                            <h2 className='text-white font-semibold text-[13px]'>
                                {state.name}
                            </h2>
                            <p className='text-[#D9D9D980] text-[10px] font-light'>
                                {state.walletAddress.substring(0, 12)}...
                            </p>
                        </div>
                    </div>
                    <XMarkIcon className='h-[25px] 2xl:h-[30px] cursor-pointer mr-[10px] mb-[10px]'
                        style={{
                            color: 'rgba(217, 217, 217, 0.50)'
                        }}
                        onClick={() => setopenChatBox(false)}
                    />
                </div>
                {isFetching ? (
                    <div className='flex justify-center items-center h-full'>
                        <CircularProgress sx={{ color: 'white' }} />
                    </div>
                ) : (
                    <div className={`space-y-[30px] 2xl:space-y-[37px] ${fromChat ? 'px-[20px] py-[20px] sm:px-[40px] relative z-30  lg:z-0 h-[70vh]' : `px-[10px] py-[10px] ${smallerthen415 ? 'h-[57vh]' : 'h-[62vh]'} sm:h-[340px] xl:h-[420px] 2xl:h-[600px]`}  ${messages ? 'overflow-y-auto' : 'overflow-hidden'}`}>
                        {messages && messages.length > 0 ? messages.map((item, i) => (
                            <div key={i}>
                                <div className={`flex ${item.firstUser !== userData._id ? 'justify-start' : 'justify-end'}`}>
                                    <div className='max-w-[90%] md:max-w-[50%]'>
                                        {item.message ? (
                                            <div
                                                className={`p-[12px] rounded-[25px] ${item.firstUser !== userData._id ? 'bg-[#9747FF]' : 'bg-[#0C8CE9]'}`}
                                            >
                                                <p
                                                    className='text-white text-[12px] 2xl:text-[14px] font-normal'
                                                    style={{
                                                        maxWidth: '100%', // Adjust this value as needed
                                                        wordWrap: 'break-word', // This allows long words to break
                                                    }}
                                                >
                                                    {item.message}
                                                </p>
                                            </div>
                                        ) : item.filename ? (
                                            <div className='bg-slate-700 px-[20px] flex items-center justify-between gap-[20px] py-[12px] rounded-[12px] min-w-[150px]'>
                                                <h2 className='text-white font-semibold text-[15px] break-words w-[80%]'>
                                                    {item.filename}
                                                </h2>
                                                {clickedIndex === i && downloadingProgress ? (
                                                    <h2 className='text-white text-[12px] font-bold w-[40px] text-right'>
                                                        {downloadingProgress}%
                                                    </h2>
                                                ) : (
                                                    <div className='p-[8px] bg-slate-800 hover:scale-110 duration-700 cursor-pointer rounded-full'
                                                        onClick={() => {
                                                            setclickedIndex(i)
                                                            handleDownload(item.document, item.filename)
                                                        }
                                                        }
                                                    >
                                                        <ArrowDownTrayIcon className='text-white h-[15px]'
                                                        />
                                                    </div>
                                                )}
                                            </div>
                                        ) : (
                                            <div className='relative' onMouseEnter={() => setactiveIndex(i)} onMouseLeave={() => setactiveIndex()}>
                                                <img src={item.image} className='h-[130px] rounded-[20px] object-contain'
                                                />
                                                <div>
                                                    {activeIndex === i && (
                                                        <div className='absolute inset-0 rounded-[20px] flex items-center justify-center'
                                                            style={{
                                                                backgroundColor: 'rgba(0,0,0,0.3)'
                                                            }}
                                                        >
                                                            <div className='h-[40px] w-[40px] bg-slate-600 hover:bg-slate-700 duration-700 cursor-pointer hover:scale-110 rounded-full flex justify-center items-center'
                                                                onClick={() => handleDownload(item.image)}
                                                            >
                                                                <ArrowDownTrayIcon className='h-[15px] text-white' />
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <p className={`text-white text-[9px] 2xl:text-[11px] px-[3px] pt-[5px] font-normal ${item.firstUser !== userData._id ? 'text-left' : 'text-right'} `}>
                                    {formatDate(item.createdAt)}
                                </p>
                            </div>
                        )) : (
                            <div className='flex justify-center overflow-hidden items-center h-full'>
                                <motion.div
                                    whileInView={{ opacity: [0, 1] }}
                                    transition={{ duration: 0.7, ease: 'easeInOut', delay: 0.2 }}
                                    initial='hidden'
                                    viewport={{ once: true }}
                                    style={{
                                        opacity: 0
                                    }}
                                >
                                    <h2 className='text-white text-[14px] font-semibold'>
                                        No messages yet!
                                    </h2>
                                </motion.div>
                            </div>
                        )}
                        {fileName && (
                            <div className='flex justify-end'>
                                <div className='bg-slate-700 px-[20px] flex items-center justify-between gap-[20px] py-[12px] rounded-[12px] min-w-[150px]'>
                                    <h2 className='text-white font-semibold text-[15px] break-words w-[80%]'>
                                        {fileName}
                                    </h2>
                                    <h2 className='text-white text-[12px] font-bold w-[40px] text-right'>
                                        {progress}%
                                    </h2>

                                </div>
                            </div>
                        )}

                        <div className="pt-[0px] h-[1px]" ref={bottomRef} />
                    </div>
                )}

            </div >
        </div>
    )
}

export default ChatBox