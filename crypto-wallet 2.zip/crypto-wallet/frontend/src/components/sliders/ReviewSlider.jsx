import React from 'react'
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/autoplay";

import { FormatQuote } from "@mui/icons-material";


import { Pagination, Autoplay } from 'swiper/modules';
import { Box, Rating, styled, useMediaQuery } from '@mui/material';

const ReviewSlider = ({ data }) => {

    const smallerthen640 = useMediaQuery('(max-width:640px)')


    const StyledPortfolioSection = styled(Box)(({ theme }) => ({


        '.swiper-pagination-bullet-active ': {
            backgroundColor: 'white !important',
        },
        '.swiper-pagination-bullet-active-next': {
            backgroundColor: 'white !important',
            opacity: '0.5'
        },
        '.swiper-pagination-bullet-active-prev': {
            backgroundColor: 'white !important',
            opacity: '0.5'
        },

    }))

    return (
        <div>
            {data.reviews.length > 0 && (
                <div className="md:w-full lg:w-[550px] mx-auto mt-[40px] relative rounded-[10px]"
                    style={{
                        border: '1px solid rgba(217, 217, 217, 0.50)',
                        boxShadow: '0px 0px 4px 0px #D9D9D9',
                    }}
                >

                    <StyledPortfolioSection>
                        <Swiper

                            modules={[Pagination, Autoplay]}
                            pagination={{
                                clickable: true,
                                dynamicBullets: true
                            }}
                            spaceBetween={20}
                            slidesPerView={1}
                            autoplay={{
                                pauseOnMouseEnter: true
                            }}
                            speed={1000}
                            style={{
                                "--swiper-navigation-size": "25px",
                                position: 'relative',
                                borderRadius: '10px',
                                padding: '20px 20px',
                            }}
                        >
                            {data.reviews.map((item, i) => (
                                <SwiperSlide key={i} >
                                    <div
                                        className="px-[20px] py-[15px] h-[250px] relative  lg:h-[250px] rounded-[10px]"
                                        style={{
                                            background: 'rgba(255, 255, 255, 0.09)'
                                        }}
                                    >

                                        <div>
                                            <FormatQuote sx={{ transform: 'rotate(180deg)', fontSize: '40px', color: '#757575', transition: 'all 0.6s ease-in-out', '&:hover': { color: 'black' } }} />

                                            <p className={`text-[15px] sm:text-[16px] line-clamp-4 break-words text-gray-500 dark:text-gray-300 mt-1 italic`}>
                                                "{item.comment}"
                                            </p>
                                        </div>

                                        <div className="absolute bottom-0 left-0 right-0">
                                            <div className="flex items-center gap-[10px]  mt-3 px-[20px] pb-[20px]">
                                                <img src={item.ratedBy.image} alt='img' key={i} className={`h-[35px] sm:h-[45px] w-[35px] sm:w-[45px] rounded-full`} />
                                                <div className=' flex flex-col justify-center mt-[2px] sm:mt-0'>
                                                    <h1 className="font-bold text-[12px] sm:text-[15px] text-white">{item.ratedBy.name}</h1>
                                                    <div className="-ml-[4px]">
                                                        <Rating name="half-rating" defaultValue={item.rating} size={'small'} precision={0.5} readOnly
                                                            style={{
                                                                color: '#9747FF',
                                                                fontSize: smallerthen640 ? '15px' : '17px'

                                                            }}
                                                            sx={{
                                                                '& .MuiRating-iconEmpty': {
                                                                    color: '#9747FF',  // Change color of non-active star
                                                                    borderColor: '#9747FF !important', // Change border color of non-active star
                                                                },
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </SwiperSlide>
                            ))}
                        </Swiper>
                    </StyledPortfolioSection>

                </div>
            )}
        </div>
    )
}

export default ReviewSlider