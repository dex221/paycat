import React, { useContext, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { XMarkIcon } from '@heroicons/react/24/solid';



const BigImageSlider = ({ open, setopen, image }) => {


    return (
        <div>
            {open && (
                <div
                    className="fixed top-0 left-0 w-full h-full z-[60]"
                    style={{
                        backgroundColor: 'rgba(12, 140, 233, 0.2)',
                    }}
                    onClick={() => setopen(false)}
                />
            )}

            {open && (
                <div
                    className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full z-[9999] max-w-[900px] "
                >
                    <motion.div
                        whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
                        transition={{ duration: 0.5, ease: 'easeInOut' }}
                        initial='hidden'
                        style={{ opacity: 0 }}
                        viewport={{ once: true }}
                    >

                        <div
                            className='w-[95%] md:w-[800px] lg:w-[900px] mx-auto pb-[30px] md:pb-[50px] bg-[#020F32] border border-[#000] rounded-[10px] py-[10px]'
                            style={{
                                boxShadow: '0px 4px 4px 0px rgba(0, 0, 0, 0.25)'
                            }}

                        >
                            <div className='flex justify-end pt-[4px] pr-[15px] pb-[5px]'>
                                <XMarkIcon className='text-black h-[25px] p-[5px] rounded-full bg-gray-200 cursor-pointer'
                                    onClick={() => setopen(false)}
                                />
                            </div>
                            <div className='px-[10px] md:px-[50px] pt-[20px] flex justify-center items-center'>
                                <img src={image && image} alt="" className='h-[340px] md:h-[450px] object-contain' />
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};

export default BigImageSlider;
