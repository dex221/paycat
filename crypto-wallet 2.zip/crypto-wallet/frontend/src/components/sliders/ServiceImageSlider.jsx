import React, { useEffect, useRef, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Box, styled } from '@mui/material';

import 'swiper/css';
import 'swiper/css/navigation';
import { Navigation } from 'swiper/modules';
import { ChevronLeftIcon, ChevronRightIcon, MinusIcon } from '@heroicons/react/24/solid';

import plus from '../../assets/plus.png'


const ServiceImageSlider = ({ data, currentSlide, setCurrentSlide, isCreateService, setdata }) => {
  const StyledPortfolioSection = styled(Box)(({ theme }) => ({
    '.swiper-button-prev, .swiper-button-next': {
      display: 'none'
    },

  }));


  const swiperRef = useRef(null)

  const handlePrev = () => {
    if (currentSlide === 0) return
    setCurrentSlide(currentSlide - 1)
  }

  const handleNext = () => {
    if (currentSlide === data.length - 1) return
    setCurrentSlide(currentSlide + 1)
  }

  const handleImageChnage = (e) => {

    const reader = new FileReader()
    reader.onload = () => {
      if (reader.readyState === 2) {
        let comingdata = {
          img: reader.result
        }
        setdata(prev => [...prev, comingdata])

        let prevData = data
        prevData.push(comingdata)
        setCurrentSlide(prevData.length - 1)

      }
    }
    reader.readAsDataURL(e.target.files[0])

    e.target.files = ''

  }


  useEffect(() => {

    if (data && data.length > 0) {
      swiperRef.current.swiper.slideTo(currentSlide);
    }


  }, [currentSlide]);

  return (
    <div className='flex gap-[10px]'>
      {data && data.length > 0 && data.length > 2 && (
        <div className='h-[40px] sm:h-[56px] w-[26px] flex justify-center items-center cursor-pointer'
          style={{
            borderRadius: '10px 0 0 10px',
            background: '#122758'
          }}
          onClick={() => handlePrev()}
        >
          <ChevronLeftIcon className='text-[#9747FF] h-[30px] ' />
        </div>
      )}
      {data && data.length > 0 && (
        <div className={`${(!isCreateService || data.length > 2) && 'w-[200px] sm:w-[340px] xl:w-[400px]'} ${isCreateService && data.length === 1 ? 'w-[70px] sm:w-[80px] xl:w-[120px]' : data.length === 2 && 'w-[140px] sm:w-[180px] xl:w-[240px]'}`} >
          <StyledPortfolioSection>
            <Swiper
              initialSlide={currentSlide}
              ref={swiperRef}
              slidesPerView={isCreateService ? (data.length === 1 ? 1 : data.length === 2 ? 2 : 3) : 3}
              spaceBetween={15}
              modules={[Navigation]}
              navigation
            >
              {data && data.length > 0 && data.map((item, i) => (
                <SwiperSlide
                  key={i}
                  onClick={() => setCurrentSlide(i)}
                  className={`h-[40px] sm:h-[56px] w-[67px] cursor-pointer rounded-[5px] ${currentSlide === i && 'border-[3px] border-[#9747FF]'} relative`}
                >
                  <img src={item.img} alt="" className='h-full w-full object-cover rounded-[5px]' />

                  {isCreateService && (
                    <div className='absolute top-[2px] sm:top-[5px] right-[2px] sm:right-[5px]'>
                      <div className='bg-red-500 rounded-full h-[15px] w-[15px] flex justify-center items-center cursor-pointer'
                        onClick={(e) => {
                          e.stopPropagation()
                          setdata(prev => {
                            const newData = [...prev];
                            newData.splice(i, 1); // Remove the image at the clicked index
                            return newData;
                          });
                          if (i !== 0 && i === currentSlide) {
                            setCurrentSlide(i - 1)
                          } else {
                            handlePrev()
                          }
                        }}
                      >
                        <MinusIcon className='text-white w-[8px] sm:w-[10px]' />
                      </div>
                    </div>
                  )}

                </SwiperSlide>
              ))}

            </Swiper>
          </StyledPortfolioSection>
        </div>
      )}

      {isCreateService && (

        <div className='flex justify-center h-full w-[70px] sm:w-[80px] xl:w-[120px]'>
          <label className='w-full'>
            <div id='image' className='h-[40px] sm:h-[56px] w-full rounded-[10px]  border border-gray-500 flex justify-center items-center cursor-pointer'
            >
              <img src={plus} alt="" />
            </div>
            <input
              type="file"
              htmlFor="image"
              className='hidden'
              accept=".jpg, .jpeg, .png, .gif"
              onChange={(e) => handleImageChnage(e)}
            />
          </label>
        </div>
      )}

      {data && data.length > 0 && data.length > 2 && (
        <div className='h-[40px] sm:h-[56px] w-[26px] flex justify-center items-center cursor-pointer'
          style={{
            borderRadius: '0px 10px 10px 0px',
            background: '#122758'
          }}
          onClick={() => handleNext()}
        >
          <ChevronRightIcon className='text-[#9747FF] h-[25px] sm:h-[30px] '
          />
        </div>
      )}
    </div >
  );
};

export default ServiceImageSlider;
