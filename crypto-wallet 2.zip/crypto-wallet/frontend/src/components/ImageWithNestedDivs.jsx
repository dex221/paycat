import React from 'react';
import { useNavigate } from 'react-router-dom';

const ImageWithNestedDivs = ({ images }) => {
    const renderNestedDivs = (index) => {
        if (index !== images.length) {
            return (
                <div className={`absolute top-0 right-0 bottom-0 ${index === 0 ? 'left-0' : 'left-[35px]'}`}>
                    <div className='relative'>
                        {renderNestedDivs(index + 1)}
                        <img
                            src={images[index].member && images[index].member.image}
                            alt=""
                            className='h-[95px] 2xl:h-[118px] w-[95px] 2xl:w-[118px] hover:scale-110 duration-500 cursor-pointer rounded-full object-cover border border-[#0C8CE9]'
                            onClick={() => handleImageClick(images[index].conversationId, images[index].member)}
                        />
                    </div>
                </div>
            );
        }
    };

    const navigate = useNavigate()

    const handleImageClick = (conversationId, member) => {
        navigate(`/conversation/${conversationId}`, {
            state: {
                name: member.name,
                image: member.image,
                walletAddress: member.walletAddress,
                id: member._id
            }
        })

    };

    return (
        <div className='relative'>
            {renderNestedDivs(0)}
        </div>
    );
};

export default ImageWithNestedDivs;
