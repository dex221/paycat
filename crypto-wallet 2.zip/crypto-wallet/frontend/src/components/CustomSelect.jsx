import React, { useEffect, useRef, useState } from 'react'
import downarrow from '../assets/marketplace/downarrow.png'
import menu from '../assets/marketplace/menu.png'

const CustomSelect = ({ value, options, isCountry, open, setopen, onChange, isShippingModal, createForm, fullHeight }) => {

    const optionContainerRef = useRef(null);

    useEffect(() => {
        document.addEventListener("keypress", function (event) {
            if (isCountry) {

                const matchingOption = options && options.find(
                    option => option.name && option.name.toLowerCase().startsWith(event.key.toLowerCase())
                );

                if (matchingOption) {

                    const matchingOptionIndex = options.findIndex(
                        option => option.name && option.name.toLowerCase().includes(matchingOption.name.toLowerCase())
                    );

                    if (matchingOptionIndex !== -1 && optionContainerRef.current) {
                        optionContainerRef.current.scrollTop = matchingOptionIndex * 42.5; // Assuming each option is approximately 32px tall
                    }
                }
            }
        });
        return (
            document.removeEventListener("keypress", function (event) {
                if (isCountry) {

                    const matchingOption = options && options.find(
                        option => option.name && option.name.toLowerCase().startsWith(event.key.toLowerCase())
                    );

                    if (matchingOption) {

                        const matchingOptionIndex = options.findIndex(
                            option => option.name && option.name.toLowerCase().includes(matchingOption.name.toLowerCase())
                        );

                        if (matchingOptionIndex !== -1 && optionContainerRef.current) {
                            optionContainerRef.current.scrollTop = matchingOptionIndex * 42.5; // Assuming each option is approximately 32px tall
                        }
                    }
                }
            })
        )
    }, [isCountry, options]);


    return (
        <div className='relative h-[44px] w-full'>
            <div className='w-full h-full relative cursor-pointer'
                style={{
                    borderRadius: '10px',
                    backgroundColor: 'transprent',
                    border: '1px solid rgba(217, 217, 217, 0.50)',
                    display: 'flex',
                    alignItems: 'center'
                }}
                onClick={() => setopen(!open)}
                onKeyDown={(e) => handleKeyDown(e)}

            >
                <h2 className={`text-[15px] ${createForm ? 'pl-[18px] ' : 'pl-[50px]'} `}
                    style={{
                        color: 'rgba(217, 217, 217, 0.50)',
                    }}
                >
                    {value}
                </h2>
                <div className=' absolute right-[15px] top-0 bottom-0 flex items-center'>
                    <img src={downarrow} alt="" />
                </div>
                {!createForm && (
                    <div className='absolute left-[15px] top-0 bottom-0 flex items-center'>
                        <img src={menu} alt="" />
                    </div>
                )}
            </div>

            {open && (
                <div className={`absolute top-[47px] ${!fullHeight && 'h-[170px] sm:h-[200px]'}  rounded-[5px] z-50 lg:z-20 left-0 right-0 bg-gray-100 overflow-y-auto`}
                    ref={optionContainerRef}
                >

                    <div className=' py-[5px] space-y-[4px]'>

                        {!isShippingModal && isCountry && !createForm && (

                            <div className={`px-[15px] py-[8px] cursor-pointer hover:bg-gray-200 duration-700 ${value === 'All countries' && 'bg-gray-200'}`}
                                onClick={() => {
                                    onChange('All countries')
                                    setopen(false)
                                }}
                            >
                                <h2 className='text-[15px]'>
                                    All countries
                                </h2>
                            </div>
                        )}

                        {options.map((item, i) => (
                            <div className={`px-[15px] flex items-center gap-[10px] py-[8px] cursor-pointer hover:bg-gray-200 duration-700 ${value === item && 'bg-gray-200'}`} key={i}
                                onClick={() => {
                                    if (item.name) {
                                        onChange(item.name)
                                        if (item.flag) {
                                            onChange(`${item.flag} ` + item.name)
                                        }
                                    } else {
                                        onChange(item)
                                    }
                                    setopen(false)
                                }}
                            >
                                {item.img && (
                                    <img src={item.img} className='h-[20px]' />
                                )}
                                {item.name ? (
                                    <h2 className='text-[15px]'>
                                        {item.name}
                                    </h2>
                                ) : (

                                    <h2 className='text-[15px]'>
                                        {item}
                                    </h2>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

        </div>
    )
}

export default CustomSelect