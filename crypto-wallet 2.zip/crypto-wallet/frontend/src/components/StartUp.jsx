import React from 'react'
import bg from '../assets/home/bg.png'
import logo from '../assets/home/logo.png'
import { CircularProgress } from '@mui/material'


const StartUp = () => {
    return (
        <div className='relative h-[100vh] w-[100vw] overflow-hidden flex justify-center items-center'
            style={{
                background: 'rgba(2, 15, 50, 0.81)',
            }}
        >
            <div className='absolute top-0 bottom-0 right-[-20px] left-[-20px]'>
                <img src={bg} alt="" className='w-full h-full object-cover' />
            </div>

            <div className='relative z-20 flex items-center justify-center'>
                {/* <img src={logo} alt="" className='w-[250px] sm:w-[320px] 2xl:w-full' />
                <h2 className=' text-[#5E8BFA] text-center text-[25px] sm:text-[30px] 2xl:text-[36px] font-bold'>
                    PayCat
                </h2>
                <p className='text-[#EBF0FF] text-[15px] sm:text-[20px] 2xl:text-[24px] font-bold text-center animate-pulse duration-700'>
                    Secure your payments
                </p> */}
                <CircularProgress sx={{ color: 'white' }} />

            </div>
        </div>
    )
}

export default StartUp