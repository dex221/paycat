import * as React from 'react';
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Tooltip,
  Category,
  MultiColoredAreaSeries, // Use MultiColoredAreaSeries
} from '@syncfusion/ej2-react-charts';
import { Browser, registerLicense } from '@syncfusion/ej2-base';
import licenseKey from "../syncfusion-license";

const Graph = ({ rawData }) => {
  registerLicense(licenseKey);

  const colorMappingData = [
    rawData
  ];

  return (
    <div>
      <div className="w-full h-[350px]">
        <ChartComponent
          id="charts"
          style={{ textAlign: 'center' }}
          primaryXAxis={{
            valueType: 'Category',
            majorGridLines: { width: 0 },
            labelIntersectAction: Browser.isDevice ? 'None' : 'Trim',
            labelStyle: { color: 'white' },
          }}
          primaryYAxis={{
            labelFormat: '{value} € ',
            lineStyle: { width: 0 },
            majorTickLines: { width: 0 },
            minorTickLines: { width: 0 },
            labelStyle: { color: 'white' },
          }}
          tooltip={{ enable: true, shared: true, format: '${point.x} : <b>${point.y}</b>' }}
          legendSettings={{ visible: false }}
          chartArea={{ border: { width: 0 } }}
          width={'99%'}
          height="100%"
        >
          <Inject services={[MultiColoredAreaSeries, Category, Tooltip]} />
          <SeriesCollectionDirective>
            <SeriesDirective dataSource={colorMappingData[0]} xName="x" yName="y" type="MultiColoredArea"
              fill="url(#areaGradient)" // Use a gradient fill
            />
          </SeriesCollectionDirective>
        </ChartComponent>

        <svg style={{ height: 0 }}>
          <defs>
            <linearGradient id="areaGradient" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor="#9747FF" stopOpacity="0.9" /> {/* Adjust the stop-opacity values */}
              <stop offset="1" stopColor="#9747FF" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>

      </div>
    </div>
  );
};

export default Graph;
