import React, { useEffect, useState } from 'react'
import search from '../../assets/search.png'
import map from '../../assets/map.png'
import { motion } from 'framer-motion';
import { useAddFriendMutation } from '../../helpers/contactApi';
import { XMarkIcon } from '@heroicons/react/24/solid'
import { CircularProgress } from '@mui/material';


const NewContact = ({ setopenEditContact, refetch , UserProfile}) => {

    const [walletAddress, setwalletAddress] = useState('')

    const [addFriend, res] = useAddFriendMutation()

    const handleSubmit = async (e) => {
        e.preventDefault()
        addFriend(walletAddress)
    }

    useEffect(() => {

        if (res.status === 'fulfilled') {
            setopenEditContact(false)
            if (refetch) {
                refetch()
            }
        }

    }, [res])

    return (
        <motion.div
            whileInView={{ scale: [0.7, 1], opacity: [0, 1] }}
            transition={{ duration: 0.7, ease: 'easeInOut' }}
            initial='hidden'
            viewport={{ once: true }}
            className={`absolute  ${UserProfile ? '' : 'top-[-15px]'} left-[20px] md:left-0 right-[20px] md:right-0 h-[190px] z-20 p-[25px] bg-[#020F32]`}
            style={{
                opacity: 0,
                boxShadow: '0px 0px 6px 1px rgba(12, 140, 233, 0.74)'
            }}
        >
            <h2 className='text-white text-[18px] 2xl:text-[20px] font-bold'>
                Add new Contact
            </h2>
            <div className='absolute right-[12px] top-[15px]'>
                <XMarkIcon className='cursor-pointer h-[20px] text-white'
                    onClick={() => setopenEditContact(false)}
                />
            </div>

            <form onSubmit={(e) => handleSubmit(e)}>
                <div className='relative mt-[15px]'>
                    <input
                        type="text"
                        className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                        placeholder='Public Address'
                        value={walletAddress}
                        required
                        onChange={(e) => setwalletAddress(e.target.value)}
                        style={{
                            border: '1px solid rgba(217, 217, 217, 0.50)'
                        }}
                    />
                    <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                        <img src={map} alt="" className='h-[13px]' />
                    </div>
                </div>
                {/* <div className='relative mt-[10px]'>
                <input
                    type="text"
                    className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                    placeholder='Name'
                    style={{
                        border: '1px solid rgba(217, 217, 217, 0.50)'
                    }}
                />
                <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                    <img src={search} alt="" className='h-[13px]' />
                </div>
            </div> */}
                <div className='mt-[10px]'>
                    {res.error && (
                        <h2 className='text-red-500 font-medium text-[12px]'>
                            {res.error.data.message}
                        </h2>
                    )}

                    <button
                        className='rounded-[10px] bg-[#0C8CE9] hover:bg-[#0862a7] duration-700  w-full h-[25px] text-[14px] font-bold text-white'
                        type='submit'
                        disabled={res.isLoading}
                    >
                        {res.isLoading ? <CircularProgress size={15} sx={{ color: 'white' }} /> : 'Save'}
                    </button>
                </div>
            </form>
        </motion.div>
    )
}

export default NewContact