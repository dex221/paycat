import adduser from '../../assets/adduser.png'
import searchicon from '../../assets/searchicon.png'
import contact from '../../assets/contact.png'
import bluecontact from '../../assets/bluecontact.png'
import backIcon from '../../assets/back-icon.png'

import { useContext, useEffect, useState } from 'react'
import NewContact from './NewContact'
import { useLocation, useNavigate } from 'react-router-dom'
import { XMarkIcon } from '@heroicons/react/24/solid'
import StatesContext from '../../context/StatesContext'

import Checkbox from '@mui/material/Checkbox';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import Favorite from '@mui/icons-material/Favorite';
import { useAllFriendsQuery, useUpdateFriendsFvrtMutation } from '../../helpers/contactApi'
import { CircularProgress } from '@mui/material'

const Contact = () => {
    const context = useContext(StatesContext);
    const { setcontactOpen, isComingFromChat, allFriends, userData, setallFriends, fvrtUpdated, setfvrtUpdated, filteredFriends, setfilteredFriends, onlineUsers, setchatHistoryOpen } = context;

    const [openEditContact, setopenEditContact] = useState(false);
    const { data, isFetching, refetch, isLoading } = useAllFriendsQuery((userData && userData._id && userData._id) || '');
    const [updateFvrt, res] = useUpdateFriendsFvrtMutation();
    const navigate = useNavigate();

    const [isSmallScreen, setisSmallScreen] = useState(false);
    const [search, setsearch] = useState('')
    const [fvrtOpen, setfvrtOpen] = useState(false)

    let { pathname, state } = useLocation()
    const location = pathname.split('/')[1] === 'conversation'

    useEffect(() => {
        const handleScreenSizeChange = () => {
            setisSmallScreen(window.matchMedia('(min-width: 768px)').matches);
        };

        // Initial check
        handleScreenSizeChange();

        // Add event listener to update state when the screen size changes
        window.addEventListener('resize', handleScreenSizeChange);

        // Clean up the event listener when the component is unmounted
        return () => {
            window.removeEventListener('resize', handleScreenSizeChange);
        };
    }, []);

    useEffect(() => {

        if (fvrtUpdated) {
            refetch()
            setfvrtUpdated(false)
        }

    }, [])

    const handleCheckboxChange = (e, friendId) => {

        // Find the friend object with the specific friendId
        const friendToUpdate = allFriends.find((friend) => friend.userId._id === friendId) || filteredFriends?.find((friend) => friend.userId._id === friendId);

        if (friendToUpdate) {
            const updatedIsFavrt = !friendToUpdate.isFavrt;
            const updateduserId = friendToUpdate.userId._id;
            updateFvrt({ updateduserId, updatedIsFavrt });
        }

        // Update the isFavrt property in the allFriends state
        setallFriends((prevState) =>
            prevState.map((friend) => (friend.userId._id === friendId ? { ...friend, isFavrt: !friend.isFavrt } : friend))
        );

        // Update the isFavrt property in the filteredFriends state if applicable
        if (filteredFriends) {
            setfilteredFriends((prevState) =>
                prevState.map((friend) => (friend.userId._id === friendId ? { ...friend, isFavrt: !friend.isFavrt } : friend))
            );
        }

        setfvrtUpdated(true)
    };

    const handleClick = (e, item) => {

        navigate(`/conversation/${item.conversation}`, {
            state: {
                name: item.userId.name,
                image: item.userId.image,
                walletAddress: item.userId.walletAddress,
                id: item.userId._id,
                fromChat: isComingFromChat && true
            }
        })
        if (!isSmallScreen) {
            setcontactOpen(false)
        }
    }

    const filterFriendsData = () => {
        let filteredData = allFriends;
        if (search && fvrtOpen) {
            filteredData = filteredData.filter(
                (item) => item.userId.name.toLowerCase().includes(search.toLowerCase()) && item.isFavrt
            );
        } else if (search) {
            filteredData = filteredData.filter((item) => item.userId.name.toLowerCase().includes(search.toLowerCase()));
        } else if (fvrtOpen) {
            filteredData = filteredData.filter((item) => item.isFavrt === true);
        }
        return filteredData;
    };

    useEffect(() => {
        if (data && data.friends) {
            setallFriends(data.friends);
            setfilteredFriends(data.friends)
        }
    }, [data]);

    useEffect(() => {
        setfilteredFriends(filterFriendsData());
    }, [search, fvrtOpen]);

    const reversedFilteredFriends = Array.isArray(filteredFriends) ? [...filteredFriends].reverse() : [];
    return (
        <div
            className={`${location && 'lg:fixed top-0 left-0'} min-h-screen lg:border-r border-[#D9D9D9]`}
        >
            <div
                className={`fixed top-0 right-0 bottom-0 min-h-screen dark:bg-[#020F32] bg-gray-700 dark:lg:bg-transparent w-full flex-shrink-0 lg:w-[250px] md:relative z-40  ${location && 'lg:ml-[140px] xl:ml-[145px] 2xl:ml-[170px]'}`}
            >
                <div className='w-full border-b border-[#D9D9D9] flex justify-between items-center py-[24px] 2xl:py-[26px] px-[15px]'>
                    <div className='flex items-center gap-[20px] '>
                        <img src={contact} alt="" className='h-[25px] 2xl:h-[32px]' />
                        <h5 className='text-[#F1F1F1] text-[18px] 2xl:text-[20px] font-medium'>
                            Contacts
                        </h5>
                    </div>
                    <XMarkIcon
                        onClick={() => {
                            setcontactOpen(false)
                            navigate('/')
                        }}
                        className='w-[30px] text-white lg:hidden'
                    />
                </div>
                <div className='border-b border-[#D9D9D9] py-[15px] 2xl:py-[20px]'>
                    <div className='relative px-[20px] flex justify-center lg:justify-start items-center gap-[30px] lg:gap-[16px]'>
                        <div className='cursor-pointer' onClick={() => setopenEditContact(!openEditContact)}>
                            <img src={openEditContact ? bluecontact : adduser} alt="" className='w-[15px] 2xl:w-[21px]' />
                        </div>
                        <div className='w-[1px] h-[15px]'
                            style={{
                                background: 'rgba(217, 217, 217, 0.50)'
                            }}
                        />
                        <h2
                            onClick={() => setfvrtOpen(false)}
                            className={`${!fvrtOpen ? 'text-[#0C8CE9]' : 'text-[#F1F1F1]'} font-normal text-[11px] 2xl:text-[13px] cursor-pointer`}>
                            All
                        </h2>
                        <div className='w-[1px] h-[15px] '
                            style={{
                                background: 'rgba(217, 217, 217, 0.50)'
                            }}
                        />
                        <h2
                            onClick={() => setfvrtOpen(true)}
                            className={`${fvrtOpen ? 'text-[#0C8CE9]' : 'text-[#F1F1F1]'}  text-[11px] 2xl:text-[13px] font-normal cursor-pointer`}>
                            Favoris
                        </h2>

                        {isComingFromChat && (
                            <div className='lg:hidden absolute top-0 bottom-0 left-[20px] flex items-center'>
                                <img src={backIcon} alt="" className='h-[25px]'
                                    onClick={() => {
                                        setcontactOpen(false)
                                        setchatHistoryOpen(true)
                                    }}
                                />
                            </div>
                        )}

                    </div>
                </div>

                <div className='px-[20px] relative'>
                    <div className='relative h-[37px] 2xl:h-[40px] mt-[15px]'>
                        <input
                            type="text"
                            className='h-full w-full outline-none rounded-[99px] px-[10px] pl-[40px] relative z-20 bg-transparent text-[13px] py-[5px] placeholder:text-[#D9D9D980] text-white'
                            placeholder='Rechercher...'
                            value={search}
                            onChange={(e) => setsearch(e.target.value)}
                            style={{
                                border: '1px solid rgba(217, 217, 217, 0.50)'
                            }}
                        />
                        <div className='absolute top-[5px] left-[15px] bottom-0 right-0  rounded-[99px] flex items-center'>
                            <img src={searchicon} alt="" className='h-[16px]' />
                        </div>
                    </div>
                    {openEditContact && (
                        <NewContact setopenEditContact={setopenEditContact} refetch={refetch} />
                    )}
                </div>
                <div className='mt-[35px] md:mt-[25px] '>
                    {isLoading ? (
                        <div className='flex justify-center mt-[200px]'>
                            <CircularProgress sx={{ color: 'white' }} size={34} />
                        </div>
                    ) : (
                        <div className='h-[400px] sm:h-[450px] 2xl:h-[600px] overflow-y-auto '>
                            {filteredFriends && filteredFriends.length > 0 ? (
                                reversedFilteredFriends.map((item, i) => {

                                    let isActive = false

                                    if (onlineUsers) {
                                        isActive = onlineUsers.some((data) => data.userId === item.userId.walletAddress);
                                    }


                                    return (
                                        <div className='overflow-hidden' key={i}>
                                            <div className='flex items-center justify-between px-[35px] md:px-[20px] py-[15px] sm:border-b border-gray-700 hover:bg-slate-800 duration-500 cursor-pointer'
                                                onClick={(e) => handleClick(e, item)}
                                            >
                                                <div
                                                    className='flex items-center gap-[12px] cursor-pointer rounded-[10px]'

                                                >
                                                    <div className='relative w-[36px] h-[36px]'>
                                                        <img src={item.userId.image} alt="" className='rounded-full h-full w-full object-cover border border-[#FFF3F3] ' />
                                                        {isActive && (
                                                            <div className='absolute top-0 right-0'>
                                                                <div className='bg-[#28C95F] h-[10px] w-[10px] rounded-full' />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div>
                                                        <h2 className='text-white font-semibold text-[13px]'>
                                                            {item.userId.name.length > 25 ? `${item.userId.name.substring(0, 25)}...` : item.userId.name}

                                                        </h2>

                                                        <p className='text-[#D9D9D980] text-[10px] font-light'>
                                                            {item.userId.walletAddress.substring(0, 12)}...
                                                        </p>
                                                    </div>
                                                </div>
                                                <div onClick={(e) => e.stopPropagation()}>
                                                    <Checkbox
                                                        checked={item.isFavrt}
                                                        onChange={(e) => handleCheckboxChange(e, item.userId._id)}
                                                        icon={<FavoriteBorder sx={{ color: 'white', fontSize: '20px' }} />}
                                                        checkedIcon={<Favorite sx={{ color: 'white', fontSize: '20px' }} />}
                                                    />
                                                </div>
                                            </div>
                                            <div className='w-full ml-[83px] sm:hidden h-[1px] bg-gray-700' />
                                        </div>
                                    )
                                })
                            ) : (
                                <div>
                                    {filteredFriends && filteredFriends.length === 0 && (
                                        <p className='text-white text-center text-[12px] mt-[200px]'>No friends found!</p>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Contact;
