import React from 'react'
import { ChartComponent, SeriesCollectionDirective, SeriesDirective, Inject, ColumnSeries, Category, Tooltip, Legend, RangeColorSettingsDirective, RangeColorSettingDirective } from '@syncfusion/ej2-react-charts';
import licenseKey from "../syncfusion-license";
import { Browser, registerLicense } from '@syncfusion/ej2-base';


const AreaGraph = ({ filterHistory, isBigGraph }) => {

    registerLicense(licenseKey);


    const colorMappingData = [
        filterHistory
    ];

    const ColorMappingPrimaryXAxis = {
        valueType: 'Category',
        majorGridLines: { width: 0 },
        labelStyle: { color: 'white' },
        labelIntersectAction: Browser.isDevice ? 'None' : 'Trim',

    };

    const ColorMappingPrimaryYAxis = {
        lineStyle: { width: 0 },
        majorTickLines: { width: 0 },
        minorTickLines: { width: 0 },
        labelFormat: '{value} € ',
        labelStyle: { color: 'white' },
    };

    const rangeColorMapping = [
        {
            label: '1 €  to 10 € ',
            start: '1',
            end: '10',
            colors: colorMappingData[1]
        },


    ];


    return (
        <ChartComponent
            id="charts"
            primaryXAxis={ColorMappingPrimaryXAxis}
            primaryYAxis={ColorMappingPrimaryYAxis}
            chartArea={{ border: { width: 0 } }}
            tooltip={{ enable: true }}
            width={'99%'}
            height={isBigGraph ? "90%" : '140px'}

        >
            <Inject services={[ColumnSeries, Tooltip, Category]} />
            <SeriesCollectionDirective>
                <SeriesDirective
                    dataSource={colorMappingData[0]}
                    xName="x"
                    yName="y"
                    type="Column"
                    fill="url(#areaGradient)"
                    cornerRadius={{
                        topLeft: 10,
                        topRight: 10,
                    }}
                />
            </SeriesCollectionDirective>
            <RangeColorSettingsDirective>
                {rangeColorMapping.map((item, index) => <RangeColorSettingDirective key={index} {...item} />)}
            </RangeColorSettingsDirective>

            <svg style={{ height: 0 }}>
                <defs>
                    <linearGradient id="areaGradient" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0" stopColor="#038AE8" />
                        <stop offset="1" stopColor="#B613C7" />
                    </linearGradient>
                </defs>
            </svg>
        </ChartComponent>
    )
}

export default AreaGraph