import { Bars3BottomRightIcon, HomeIcon, XMarkIcon } from '@heroicons/react/24/solid'
import logo from '../assets/home/blacklogo.png'
import { motion } from 'framer-motion';
import { textVariant } from '../utils/motion';
import { useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import StatesContext from '../context/StatesContext';
import Contact from './Contact/Contact';
import ChatHistory from './ChatHistory';


const MobNav = ({ isOpen, setisOpen, setnotConntedOpen, unreadCount }) => {

    const context = useContext(StatesContext)
    const { setcontactOpen, contactOpen, data, walletConnected, setisComingFromChat, chatHistoryOpen, setchatHistoryOpen, setconnectAction , userData } = context

    const navigate = useNavigate()

    return (
        <div >
            {isOpen && (

                <div className='fixed top-0 left-0 right-0 bottom-[0px] bg-gray-700 dark:bg-[#020F32] z-50 px-[20px] py-[20px]'>
                    <div className='relative h-full'>
                        <div className='flex justify-between items-center'>
                            <img src={logo} alt="logo" className='h-[55px]' />

                            <div className='flex items-center gap-[10px]'>

                                <XMarkIcon
                                    onClick={() => setisOpen(!isOpen)} className='w-[30px] text-white'
                                />
                            </div>
                        </div>
                        <motion.div
                            initial="hidden"
                            whileInView="show"
                            viewport={{ once: true }}
                            className='lg:pt-[90px]'
                        >
                            <div className={`mt-[50px] flex flex-col gap-[25px] ${userData && userData.isAdmin && 'h-[430px] overflow-auto'}`}>
                                {data.map((item, i) => {
                                    if (item.title === 'Settings') return
                                    return <motion.div
                                        variants={textVariant(0.2 * (i + 1))}
                                        className={' flex items-center  gap-[20px] bg-slate-800 w-[280px] px-[15px] py-[5px] rounded-[10px] mx-auto'}
                                        viewport={{ once: true }}

                                        key={i}
                                        onClick={() => {
                                            setisOpen(false)
                                            if (walletConnected) {
                                                if (item.title === 'Crypto Payment') {
                                                    setcontactOpen(true)
                                                    setisComingFromChat(false)
                                                }
                                                if (item.title === 'Chat') {
                                                    setchatHistoryOpen(true)
                                                }
                                                if (item.route) {
                                                    navigate(item.route)
                                                }
                                            } else {
                                                setchatHistoryOpen(false)
                                                if (item.title === 'Market-place' || item.title === 'Home') {
                                                    navigate(item.route)
                                                } else {
                                                    setnotConntedOpen(true)
                                                    if (item.title === 'Chat') {
                                                        setconnectAction(`${item.title}`)
                                                    } else if (item.title === 'Crypto Payment') {
                                                        setconnectAction(`do ${item.title}`)
                                                    } else {
                                                        setconnectAction(`access your ${item.title}`)
                                                    }
                                                }
                                            }
                                        }}

                                    >
                                        {item.img ? (
                                            <div className='relative'>
                                                <img src={item.img} alt="" className='w-[25px]' />
                                                {item.title === 'Chat' && (
                                                    <div>
                                                        {unreadCount > 0 && (
                                                            <div className='absolute top-[-7px] right-[-9px] z-50'>
                                                                <div className='px-[6px] py-[2px] rounded-[69px] bg-[#E0115F]'>
                                                                    <h2 className='text-white text-[8px] font-bold'>
                                                                        {unreadCount > 99 ? '99+' : unreadCount}
                                                                    </h2>
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        ) : (
                                            <div >
                                                {item.icon}

                                            </div>
                                        )}
                                        <h2 className='text-[22px] font-bold text-center text-white list-none'>
                                            {item.title}
                                        </h2>
                                    </motion.div>
                                })}

                            </div>
                        </motion.div>

                    </div>
                </div>

            )}

            {contactOpen && (
                <div className='md:hidden'>
                    <Contact />
                </div>
            )}

            {chatHistoryOpen && (
                <div className='md:hidden'>
                    <ChatHistory />
                </div>
            )}

        </div>

    )
}

export default MobNav