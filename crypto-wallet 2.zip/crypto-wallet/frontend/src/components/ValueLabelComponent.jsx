import { Tooltip, styled } from "@mui/material";



const CustomTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} classes={{ popper: className }} />
))({
    '& .MuiTooltip-tooltip': {
        backgroundColor: '#424242',
        fontSize: '14px', // Set the font size for the tooltip text
        textAlign: 'center', // Set the text alignment for the tooltip text,
        fontWeight: '500',
        // border: '1px solid white'
    },
    '& .MuiTooltip-arrow': {
        color: '#424242'
    },
});

const ValueLabelComponent = ({ children, img }) => {

    const handleDownload = () => {

        fetch(img) // Fetch the image URL
            .then((response) => response.blob()) // Convert the response to a Blob
            .then((blob) => {
                const blobUrl = URL.createObjectURL(blob); // Create a URL for the Blob
                const link = document.createElement("a");
                link.href = blobUrl;
                link.download = "downloaded_image.jpg";

                // Simulate a click on the anchor element to trigger the download
                link.click();

                // Clean up the URL created for the Blob
                URL.revokeObjectURL(blobUrl);
            })
            .catch((error) => {
                console.error("Error downloading image:", error);
            });

    };

    return (
        <CustomTooltip enterTouchDelay={0} placement="bottom" arrow

            title={
                <div
                    onClick={handleDownload}
                >
                    <p className='text-white text-[10px] font-medium cursor-pointer'>Download</p>
                </div>
            }
        >
            {children}
        </CustomTooltip>
    );
};

export default ValueLabelComponent