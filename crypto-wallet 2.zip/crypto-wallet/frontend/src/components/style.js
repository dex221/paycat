import { Box, styled, } from "@mui/material";



const StyledCalendar = styled(Box)(({ theme }) => ({

    "& .MuiOutlinedInput-input": {
        color: 'white',
        backgroundColor: 'transparent',
        fontSize: '15px',
        padding: '10px 20px',

    },
    "& .MuiInputLabel-root": {
        color: 'white !important',
        fontSize: '15px',
        '&:focus': {
            color: 'white !important',
        },
        '&:invalid': {
            color: 'white !important',
        },

    },
    "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        color: 'white',
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
        borderRadius: '20px',
        '&:invalid': {
            border: '1px solid rgba(217, 217, 217, 0.50) !important',
        },
        '&:active': {
            border: '1px solid rgba(217, 217, 217, 0.50) !important',
        },
    },
    "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
    },
    "&:focus .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
    },

    '& .MuiSvgIcon-root': {
        color: 'white',
        fontSize: '20px',
        marginRight: '5px'
    },
}))


const StyledSelect = styled(Box)(({ theme }) => ({

    "& .MuiOutlinedInput-input": {
        fontFamily: 'Roboto',
        width: '100%',
        color: 'rgba(217, 217, 217, 0.50)',
        fontSize: 15,
        borderRadius: '10px !important',
        backgroundColor: 'transprent',
        padding: '0',
        height: '44px !important',
        paddingLeft: '50px',
        paddingRight: '30px',
        border: '1px solid rgba(217, 217, 217, 0.50)',
        position: 'relative',
        zIndex: 99,
        display: 'flex',
        alignItems: 'center',
        gap: '5px'
    },
    "& .MuiInputLabel-root": {
        color: 'rgba(217, 217, 217, 0.50)',
        fontSize: 15,


    },
    "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
        borderRadius: '10px !important',
        color: 'rgba(217, 217, 217, 0.50)',

        '&:active': {
            border: '1px solid rgba(217, 217, 217, 0.50) !important',
            borderRadius: '10px !important',
        },

    },
    "&:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
        borderRadius: '10px !important',
    },
    "&:focus .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
        border: '1px solid rgba(217, 217, 217, 0.50) !important',
        borderRadius: '10px !important',
    },

    '& .MuiSvgIcon-root': {
        display: 'none'
    },


}))



export {
    StyledCalendar,
    StyledSelect
}