import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
import { BrowserRouter as Router } from 'react-router-dom';
import OverAllStates from './context/OverallStates';
import { Provider } from 'react-redux';
import store from './store/store';
import { EthereumClient, w3mConnectors, w3mProvider } from '@web3modal/ethereum';
import { Web3Modal } from '@web3modal/react';
import { configureChains, createConfig, WagmiConfig } from 'wagmi'
import { goerli, bscTestnet } from 'wagmi/chains'
import { publicProvider } from 'wagmi/providers/public'


const chains = [goerli, bscTestnet];
const projectId = '3bc9b13ede2c46a106c03bfadb9129e8';

const { publicClient, webSocketPublicClient } = configureChains(chains, [w3mProvider({ projectId }), publicProvider()]);
const wagmiConfig = createConfig({
  autoConnect: true,
  connectors: w3mConnectors({
    projectId,
    chains,
  }),
  publicClient,
  webSocketPublicClient
});
const ethereumClient = new EthereumClient(wagmiConfig, chains);

function AppInitializer() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);
  }, []);

  if (!ready) {
    return null;
  }

  return (
    <Router>
      <WagmiConfig config={wagmiConfig}>
        <Provider store={store}>
          <OverAllStates>
            <App />
          </OverAllStates>
        </Provider>
      </WagmiConfig>
    </Router>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AppInitializer />
    <Web3Modal projectId={projectId} ethereumClient={ethereumClient}
      defaultChain={goerli}
    />
  </React.StrictMode>
);