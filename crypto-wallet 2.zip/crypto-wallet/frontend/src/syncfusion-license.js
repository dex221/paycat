
const licenseKey = 'Ngo9BigBOggjHTQxAR8/V1NGaF5cXmpCf1FpRmJGdld5fUVHYVZUTXxaS00DNHVRdkdgWXhcdXVVQmRcVkd/WUc='
export default licenseKey;