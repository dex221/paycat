import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const host = '192.168.100.124';
const port = 3000;

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      './runtimeConfig': './runtimeConfig.browser',
    },
  },
  // server: {
  //   host, // Bind to the specified IP address
  //   port, // Use the same port as in your Vite.js application
  // },
})
