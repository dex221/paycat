const jwt = require('jsonwebtoken')
const asyncErrors = require('../middleware/asyncErrors')
const UserModel = require('../models/userModel')
const ErrorHander = require('../utils/ErrorHander')


exports.isAuthenticatedUser = asyncErrors(async (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return next(new ErrorHander('Please login to access this resource', 401))
    }

    const token = authHeader.split(' ')[1];

    const decodedData = jwt.verify(token, process.env.JWT_SECRET)

    if (!decodedData) {
        return next(new ErrorHander('Token is not valid', 403))
    }

    req.user = await UserModel.findById(decodedData.id)
    next();

})

exports.verifyUser = (req, res, next) => {
    this.isAuthenticatedUser(req, res, next, () => {
        if (req.user.id === req.params.id) {
            next()
        } else {
            return next(new ErrorHander('You are not authorized', 403))
        }
    })
}

exports.authorizeUser = (isAdmin) => {
    return (req, res, next) => {
        if (!isAdmin) {
            return next(new ErrorHander(`Access denied. User is not an admin.`, 403));
        }
        next();
    };
};