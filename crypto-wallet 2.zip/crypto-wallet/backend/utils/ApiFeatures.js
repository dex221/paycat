class ApiFeatures {
    constructor(query, querystr) {
        this.query = query;
        this.querystr = querystr;
    }

    search() {
        const filters = {};

        if (this.querystr.title) {

            filters.title = {
                $regex: this.querystr.title,
                $options: 'i'
            };
        }
        

        if (this.querystr.category) {
            filters.category = {
                $regex: this.querystr.category,
                $options: 'i'
            };
        }

        if (this.querystr.paymentCoin) {
            filters.paymentCoin = {
                $regex: this.querystr.paymentCoin,
                $options: 'i'
            };
        }

        if (this.querystr.country) {

            filters.country = {
                $eq: this.querystr.country
            };
        }

        // Include the user filter
        if (this.querystr.userId) {
            filters.user = {
                $ne: this.querystr.userId
            };
        }

        // Include the category filter
        if (this.querystr.categories) {
            const categoryFilter = this.querystr.categories.split(',');
            filters.category = {
                $in: categoryFilter
            };
        }

        this.query = this.query.find(filters);
        return this;
    }


    pagination(resutPerPage) {
        const currentPage = Number(this.querystr.page) || 1;
        const skip = (resutPerPage) * (currentPage - 1);
        this.query = this.query.limit(resutPerPage).skip(skip)
        return this;
    }


}
module.exports = ApiFeatures