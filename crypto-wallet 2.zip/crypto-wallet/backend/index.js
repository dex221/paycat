const app = require('./app')
const ConnectDatabase = require('./config/dataBase')
const http = require("http");


//Handling uncaught exception
process.on('uncaughtException', (err) => {
    console.log(`Error: ${err.message}`)
    console.log('Shutting down the server due to uncaught exception')
    process.exit(1)
})

//config
if (process.env.NODE_ENV !== 'PRODUCTION') {

    require('dotenv').config({ path: './config.env' })
}

//connecting to database
ConnectDatabase()

let server = http.createServer(app);

const io = require("socket.io")(server, {
    cors: {
        origin: [process.env.APP_URL, 'https://crypto-wallett.netlify.app', 'http://127.0.0.1:5173', 'https://www.paycat.app'],
        maxHttpBufferSize: 1e8,
    },
});


let activeUsers = [];

io.on("connection", (socket) => {
    // add new User
    socket.on("new-user-add", (newUserId) => {
        // if user is not added previously
        if (!activeUsers.some((user) => user.userId === newUserId)) {
            activeUsers.push({ userId: newUserId, socketId: socket.id });
            // console.log("New User Connected", activeUsers);
            console.log(newUserId)
        }
        // send all active users to new user
        io.emit("get-users", activeUsers);
    });

    socket.on("disconnect", () => {
        // remove user from active users
        activeUsers = activeUsers.filter((user) => user.socketId !== socket.id);
        console.log("User Disconnected");
        // send all active users to all users
        io.emit("get-users", activeUsers);
    });

    socket.on("logout", () => {
        // remove user from active users
        activeUsers = activeUsers.filter((user) => user.socketId !== socket.id);
        console.log("User Disconnected");
        // send all active users to all users
        io.emit("get-users", activeUsers);
    });

    socket.on("offline", () => {
        // remove user from active users
        activeUsers = activeUsers.filter((user) => user.socketId !== socket.id);
        console.log("User Disconnected");
        // send all active users to all users
        io.emit("get-users", activeUsers);
    });

});


server = server.listen(process.env.PORT, () => {
    console.log(`Server is listening on port http://localhost:${process.env.PORT}`)
})


//Unhandled Promise rejection
process.on('unhandledRejection', (err) => {
    console.log(`Error: ${err.message}`)
    console.log('Shutting down the server due to unhandled promise rejection')

    server.close(() => {
        process.exit(1)
    })
})


