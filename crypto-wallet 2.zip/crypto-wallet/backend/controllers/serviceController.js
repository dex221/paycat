const asyncErrors = require('../middleware/asyncErrors')
const ServiceModel = require('../models/serviceModel')
const UserModel = require('../models/userModel')
const LikesModel = require('../models/stats/LikesModel')
const ViewsModel = require('../models/stats/viewsModel')
const ApiFeatures = require('../utils/ApiFeatures')

exports.createService = asyncErrors(async (req, res, next) => {

    const service = await ServiceModel.create({
        ...req.body,
        user: req.user.id
    })

    res.json({
        success: true,
        service
    })

})

exports.getTokensPrice = asyncErrors(async (req, res, next) => {

    let ethUsd, wbtcUsd, usdcUsd, busdUsd, wbnbUsd, usdtUsd

    let fetch = await import('node-fetch');

    const ethRes = await fetch.default(`https://quantifycrypto.com/api/v1/coins/ETH`, {
        headers: {
            "QC-Access-Key": "5O88C8WXCHSBNBRNN3OP",
            "QC-Secret-Key": "nNy5UfgKFyeNBwiZGQUCdvG0khnCWtdw20OBaNftCgI7ATcm"
        }
    });
    const ethData = await ethRes.json();
    ethUsd = ethData.data.coin_price

    console.log(ethData)

    const wbtcRes = await fetch.default(`https://quantifycrypto.com/api/v1/coins/WBTC`, {
        headers: {
            "QC-Access-Key": "5O88C8WXCHSBNBRNN3OP",
            "QC-Secret-Key": "nNy5UfgKFyeNBwiZGQUCdvG0khnCWtdw20OBaNftCgI7ATcm"
        }
    });
    const wbtcData = await wbtcRes.json();
    wbtcUsd = wbtcData.data.coin_price

    console.log(wbtcUsd)

    const wbnbRes = await fetch.default(`https://quantifycrypto.com/api/v1/coins/BNB`, {
        headers: {
            "QC-Access-Key": "5O88C8WXCHSBNBRNN3OP",
            "QC-Secret-Key": "nNy5UfgKFyeNBwiZGQUCdvG0khnCWtdw20OBaNftCgI7ATcm"
        }
    });
    const wbnbData = await wbnbRes.json();
    wbnbUsd = wbnbData.data.coin_price

    res.json({
        success: true,
        ethUsd,
        wbtcUsd,
        usdcUsd: 1,
        busdUsd: 1,
        wbnbUsd,
        usdtUsd: 1,
    })
})

exports.getAllService = asyncErrors(async (req, res, next) => {

    let resultPerPage = 16
    const totalServicesCount = await ServiceModel.countDocuments()

    const apiFeatures = new ApiFeatures(ServiceModel.find().populate('user').sort({ createdAt: -1 }), req.query).search()

    let services = await apiFeatures.query;
    let filteredServicesCount = services.length
    apiFeatures.pagination(resultPerPage)

    services = await apiFeatures.query.clone();

    res.json({
        success: true,
        services,
        filteredServicesCount,
        totalServicesCount,
        resultPerPage
    })

})

exports.getAllServiceOfUser = asyncErrors(async (req, res, next) => {

    let resultPerPage = 16

    if (req.query.resultPerPage) {
        resultPerPage = req.query.resultPerPage
    }

    const totalServicesCount = await ServiceModel.countDocuments({ user: req.params.userId })
    const apiFeatures = new ApiFeatures(ServiceModel.find({ user: req.params.userId }).populate('user').sort({ createdAt: -1 }), req.query)

    let services = await apiFeatures.query;
    let filteredServicesCount = services.length
    apiFeatures.pagination(resultPerPage)

    services = await apiFeatures.query.clone();

    res.json({
        success: true,
        services,
        filteredServicesCount,
        totalServicesCount,
        resultPerPage
    })

})

exports.getSimilarServices = asyncErrors(async (req, res, next) => {

    let resultPerPage = 6

    const totalServicesCount = await ServiceModel.countDocuments({ user: req.query.userId, _id: { $ne: req.query.serviceId } });
    const apiFeatures = new ApiFeatures(ServiceModel.find({ user: req.query.userId, _id: { $ne: req.query.serviceId } })
        .populate('user').sort({ createdAt: -1 }), req.query)

    let services = await apiFeatures.query;

    let filteredServicesCount = services.length
    apiFeatures.pagination(resultPerPage)

    services = await apiFeatures.query.clone();

    const totalPages = Math.ceil(totalServicesCount / resultPerPage);

    res.json({
        success: true,
        services,
        filteredServicesCount,
        totalServicesCount,
        resultPerPage,
        totalPages
    })

})

exports.getSimilarCategoryServices = asyncErrors(async (req, res, next) => {

    let resultPerPage = 6

    const categoryFilter = req.query.categories ? req.query.categories.split(',') : [];

    const totalServicesCount = await ServiceModel.countDocuments({
        user: { $ne: req.query.userId },
        category: { $in: categoryFilter }
    });


    const apiFeatures = new ApiFeatures(ServiceModel.find()
        .populate('user').sort({ createdAt: -1 }), req.query).search()

    let services = await apiFeatures.query;

    let filteredServicesCount = services.length
    apiFeatures.pagination(resultPerPage)

    services = await apiFeatures.query.clone();

    const totalPages = Math.ceil(totalServicesCount / resultPerPage);

    res.json({
        success: true,
        services,
        filteredServicesCount,
        totalServicesCount,
        resultPerPage,
        totalPages
    })

})

exports.deleteService = asyncErrors(async (req, res, next) => {

    await ServiceModel.findByIdAndDelete(req.params.serviceId)

    res.json({
        success: true,
        message: 'Service has been deleted'
    })

})


exports.updateService = asyncErrors(async (req, res, next) => {

    await ServiceModel.findByIdAndUpdate(req.params.serviceId, req.body, { new: true, runValidators: true })

    res.json({
        success: true,
        message: 'Service has been updated'
    })

})

exports.createLike = asyncErrors(async (req, res, next) => {
    const { serviceId } = req.body;

    try {
        const service = await ServiceModel.findById(serviceId);

        if (!service) {
            return res.status(404).json({ success: false, message: 'Service not found' });
        }

        // Check if the user has already liked the service
        const hasLiked = service.likes.includes(req.user.id);

        if (hasLiked) {
            // If the user has already liked the service, remove the like
            const indexOfUser = service.likes.indexOf(req.user.id);
            if (indexOfUser !== -1) {
                service.likes.splice(indexOfUser, 1);
                await service.save();
            }

            return res.json({
                success: true,
                message: 'Like has been removed',
            });
        } else {
            // If the user hasn't liked the service, add the like
            service.likes.push(req.user.id);
            await service.save();

            return res.json({
                success: true,
                message: 'Like has been added',
            });
        }
    } catch (error) {
        // Handle any errors
        console.error(error);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
});


exports.createViews = asyncErrors(async (req, res, next) => {

    const { serviceId } = req.body

    let service = await ServiceModel.findById(serviceId)

    const existingView = await ViewsModel.findOne({ User: req.user.id, service: serviceId });

    if (!existingView) {
        const newView = new ViewsModel({ User: req.user.id, service: serviceId });
        await newView.save();
        service.views = service.views + 1
        await service.save()
    }

    res.json({
        success: true,
        message: 'View has been updated',
    });

})

//admin 
exports.adminDeleteService = asyncErrors(async (req, res, next) => {

    await ServiceModel.findByIdAndDelete(req.params.serviceId)

    res.json({
        success: true,
        message: 'Service has been deleted'
    })

})
