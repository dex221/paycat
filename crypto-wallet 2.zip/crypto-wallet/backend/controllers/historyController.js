
const asyncErrors = require('../middleware/asyncErrors')
const HistoryModel = require('../models/historyModel')


//Get users history
exports.userHistory = asyncErrors(async (req, res, next) => {

    let history = []

    const data = await HistoryModel.find({ user: req.params.id }).sort({ createdAt: -1 })
    if (data) {
        history = data
    }

    res.json({
        success: true,
        history
    })

})

// Get users monthly history
exports.monthlyHistory = asyncErrors(async (req, res, next) => {

    const today = new Date();
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(today.getMonth() - 6);

    let filteredData = await HistoryModel.find({
        createdAt: {
            $gte: sixMonthsAgo,
            $lt: new Date()
        },
        user: req.params.id
    }).sort({ createdAt: -1 });

    const monthAmounts = {};

    // Initialize monthAmounts with all months
    const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    monthNames.forEach(monthName => {
        monthAmounts[monthName] = 0;
    });

    filteredData.forEach((entry) => {
        const createdAt = new Date(entry.createdAt);
        const monthName = getMonthName(createdAt);

        // Replace 'entry.amount' with your actual data property
        monthAmounts[monthName] += entry.amount;
    });

    const currentMonth = today.getMonth();
    const lastSixMonths = [];

    for (let i = 5; i >= 0; i--) {
        const monthIndex = (currentMonth - i + 12) % 12;
        lastSixMonths.push(monthNames[monthIndex]);
    }

    filteredData = lastSixMonths.map(monthName => ({
        x: monthName,
        y: monthAmounts[monthName]
    }));


    res.json({
        success: true,
        history: filteredData,
    });
});


const getDayName = (date) => {
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return dayNames[date.getDay()];
};

const getMonthName = (date) => {
    const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return monthNames[date.getMonth()];
};

//Get all history
exports.allHistory = asyncErrors(async (req, res, next) => {

    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    const data = await HistoryModel.find({
        createdAt: {
            $gte: oneYearAgo,
            $lt: new Date()
        }
    }).sort({ createdAt: -1 });

    let formattedFilteredHistory
    const { activeTime } = req.query

    if (data) {

        if (activeTime === '1 week') {
            const oneWeekAgo = new Date();
            oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

            const filteredData = data.filter(entry => {
                const createdAt = new Date(entry.createdAt);
                return createdAt >= oneWeekAgo;
            });

            const dayAmounts = {};

            // Initialize dayAmounts with all days of the week
            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            dayNames.forEach(dayName => {
                dayAmounts[dayName] = 0;
            });

            const currentDayIndex = new Date().getDay();
            const reorderedDayNames = [
                ...dayNames.slice(currentDayIndex + 1),
                ...dayNames.slice(0, currentDayIndex + 1)
            ];

            filteredData.forEach((entry) => {
                const createdAt = new Date(entry.createdAt);
                const dayName = getDayName(createdAt);

                // Replace 'entry.amount' with your actual data property
                dayAmounts[dayName] += entry.amount;
            });

            formattedFilteredHistory = reorderedDayNames.map(dayName => ({
                x: dayName,
                y: dayAmounts[dayName]
            }));

        }

        if (activeTime === '6 months') {
            const today = new Date();
            const sixMonthsAgo = new Date();
            sixMonthsAgo.setMonth(today.getMonth() - 6);

            const filteredData = data.filter(entry => {
                const createdAt = new Date(entry.createdAt);
                return createdAt >= sixMonthsAgo;
            });

            const monthAmounts = {};

            // Initialize monthAmounts with all months
            const monthNames = [
                'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
            ];
            monthNames.forEach(monthName => {
                monthAmounts[monthName] = 0;
            });

            filteredData.forEach((entry) => {
                const createdAt = new Date(entry.createdAt);
                const monthName = getMonthName(createdAt);

                // Replace 'entry.amount' with your actual data property
                monthAmounts[monthName] += entry.amount;
            });

            const currentMonth = today.getMonth();
            const lastSixMonths = [];

            for (let i = 5; i >= 0; i--) {
                const monthIndex = (currentMonth - i + 12) % 12;
                lastSixMonths.push(monthNames[monthIndex]);
            }

            formattedFilteredHistory = lastSixMonths.map(monthName => ({
                x: monthName,
                y: monthAmounts[monthName]
            }));

        }
        if (activeTime === '1 year') {
            const today = new Date();
            const oneYearAgo = new Date();
            oneYearAgo.setFullYear(today.getFullYear() - 1);

            const filteredData = data.filter(entry => {
                const createdAt = new Date(entry.createdAt);
                return createdAt >= oneYearAgo;
            });

            const monthAmounts = {};

            // Initialize monthAmounts with all months
            const monthNames = [
                'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
            ];
            monthNames.forEach(monthName => {
                monthAmounts[monthName] = 0;
            });

            filteredData.forEach((entry) => {
                const createdAt = new Date(entry.createdAt);
                const monthName = getMonthName(createdAt);

                // Replace 'entry.amount' with your actual data property
                monthAmounts[monthName] += entry.amount;
            });

            const currentMonth = today.getMonth();
            const lastTwelveMonths = [];

            for (let i = 11; i >= 0; i--) {
                const monthIndex = (currentMonth - i + 12) % 12;
                lastTwelveMonths.push(monthNames[monthIndex]);
            }

            formattedFilteredHistory = lastTwelveMonths.map(monthName => ({
                x: monthName,
                y: monthAmounts[monthName]
            }));

        }

    } else {

        if (activeTime === '1 week') {
            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            const today = new Date();
            const lastSevenDays = [];

            for (let i = 6; i >= 0; i--) {
                const date = new Date(today);
                date.setDate(date.getDate() - i);
                const dayName = dayNames[date.getDay()];
                lastSevenDays.push(dayName);
            }

            formattedFilteredHistory = lastSevenDays.map(dayName => ({
                x: dayName,
                y: 0
            }));
        } else if (activeTime === '6 months') {
            const today = new Date();
            const monthNames = [
                'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
            ];
            const lastSixMonths = [];

            for (let i = 5; i >= 0; i--) {
                const monthIndex = (today.getMonth() - i + 12) % 12;
                lastSixMonths.push(monthNames[monthIndex]);
            }

            formattedFilteredHistory = lastSixMonths.map(monthName => ({
                x: monthName,
                y: 0
            }));
        } else if (activeTime === '1 year') {
            const today = new Date();
            const monthNames = [
                'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
            ];
            const lastTwelveMonths = [];

            for (let i = 11; i >= 0; i--) {
                const monthIndex = (today.getMonth() - i + 12) % 12;
                lastTwelveMonths.push(monthNames[monthIndex]);
            }

            formattedFilteredHistory = lastTwelveMonths.map(monthName => ({
                x: monthName,
                y: 0
            }));
        }
    }

    res.json({
        success: true,
        history: formattedFilteredHistory
    });
});



