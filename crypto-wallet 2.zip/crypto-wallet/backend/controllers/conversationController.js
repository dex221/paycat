const asyncErrors = require('../middleware/asyncErrors')
const UserModel = require('../models/userModel')
const ConversationModel = require('../models/conversationModel')
const NotificationModel = require('../models/notificationModel')
const RecentDealModel = require('../models/recentDealModel')
const ErrorHander = require('../utils/ErrorHander')
const Pusher = require('pusher');

const pusherServer = new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_APP_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: 'eu',
    useTLS: true,
});


//get all coversation
exports.allConversations = asyncErrors(async (req, res, next) => {

    const conversations = await ConversationModel.findById(req.params.id)

    res.status(200).json({
        success: true,
        conversations
    });

})

//send an message
exports.sendMessage = asyncErrors(async (req, res, next) => {
    try {
        const { message, image, document, filename } = req.body;

        // Validate input if necessary

        const conversation = await ConversationModel.findById(req.params.conversationId);

        if (!conversation) {
            return res.status(404).json({ success: false, message: 'Conversation not found' });
        }

        const secondUser = await UserModel.findById(req.user.id)

        const newMessage = {
            firstUser: req.user.id,
            secondUser: req.params.userId,
            message,
            image,
            document,
            filename,
            createdAt: Date.now(),
        };

        const newNotification = {
            message: image ? 'Sent an picture' : document ? 'Sent an document' : message,
            createdAt: Date.now(),
            type: 'Unread',
            senderId: {
                image: secondUser.image,
                name: secondUser.name,
                walletAddress: secondUser.walletAddress,
                _id: secondUser._id,
            },
            isSeen: false,
            conversationId: req.params.conversationId
        }

        const notifications = await NotificationModel.findOne({ user: req.params.userId })

        if (notifications) {
            notifications.notifications.unshift({
                createdAt: Date.now(),
                type: 'Unread',
                senderId: req.user.id,
                message: image ? 'Sent an picture' : document ? 'Sent an document' : message,
                conversationId: req.params.conversationId
            })
            await notifications.save()
        }

        conversation.messages.push(newMessage);

        await conversation.save();

        await pusherServer.trigger(req.params.conversationId, 'messages:new', newMessage);

        await pusherServer.trigger(req.params.userId, 'notifications:new', newNotification);

        // pushing in their recent Deals

        let firstUserRecentDeal = await RecentDealModel.findOne({ user: req.user.id })

        if (!firstUserRecentDeal) {
            await RecentDealModel.create({
                user: req.user.id,
                members: {
                    member: req.params.userId,
                    conversationId: req.params.conversationId
                }
            })
        } else {
            let memberData = {
                member: req.params.userId,
                conversationId: req.params.conversationId
            }
            await firstUserRecentDeal.updateMembersArray(memberData)
        }

        let SecondUserRecentDeal = await RecentDealModel.findOne({ user: req.params.userId })

        if (!SecondUserRecentDeal) {
            await RecentDealModel.create({
                user: req.params.userId,
                members: {
                    member: req.user.id,
                    conversationId: req.params.conversationId
                }
            })
        } else {
            let memberData = {
                member: req.user.id,
                conversationId: req.params.conversationId
            }
            await SecondUserRecentDeal.updateMembersArray(memberData)
        }


        return res.status(200).json({ success: true, message: 'Message sent successfully' });
    } catch (error) {
        // Handle any errors that occurred during the process
        console.error('Error sending message:', error);
        return res.status(500).json({ success: false, message: 'Something went wrong' });
    }
});

//get all active users
exports.activeUsers = asyncErrors(async (req, res, next) => {

    const socketId = req.body.socket_id;
    const channel = req.body.channel_name;


    const data = {
        user_id: req.user.id,
    };

    const authResponse = pusherServer.authorizeChannel(socketId, channel, data);

    res.status(200).json({
        success: true,
        authResponse
    });

})

//get all recent Deals
exports.recentDeals = asyncErrors(async (req, res, next) => {

    const recentDeals = await RecentDealModel.findOne({ user: req.params.id }).populate('members.member')

    if (!recentDeals) {
        throw new Error('Recent deals does not exists')
    }

    res.status(200).json({
        success: true,
        recentDeals
    });

})





