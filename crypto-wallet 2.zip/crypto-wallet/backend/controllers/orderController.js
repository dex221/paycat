const asyncErrors = require('../middleware/asyncErrors')
const notificationModel = require('../models/notificationModel')
const OrdersModel = require('../models/ordersModel')
const UserModel = require('../models/userModel')
const ApiFeatures = require('../utils/ApiFeatures')

const Pusher = require('pusher');

const pusherServer = new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_APP_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: 'eu',
    useTLS: true,
});



exports.createOrders = asyncErrors(async (req, res, next) => {

    const { title, receivedBy } = req.body

    await OrdersModel.create({
        ...req.body,
        bookedBy: req.user.id
    })

    const user = await UserModel.findById(req.user.id)

    const newNotification = {
        message: `has just placed an order for the service '${title}'`,
        createdAt: Date.now(),
        type: 'Received',
        senderId: {
            image: user.image,
            name: user.name,
            walletAddress: user.walletAddress,
            _id: user._id,
        },
        isSeen: false,
    }

    const notifications = await notificationModel.findOne({ user: receivedBy })

    if (notifications) {
        notifications.notifications.unshift({
            createdAt: Date.now(),
            type: 'Received',
            senderId: req.user.id,
            message: `has just placed an order for the service '${title}'`,
        })
        await notifications.save()
    }

    await pusherServer.trigger(receivedBy, 'notifications:new', newNotification);

    res.json({
        success: true,
        message: 'Order created successfully'
    })

})


exports.getAllOrders = asyncErrors(async (req, res, next) => {

    let { serviceType, userId } = req.query

    let orders

    if (serviceType === 'Booked') {
        orders = await OrdersModel.find({ bookedBy: userId }).sort({ createdAt: -1 }).populate('receivedBy')
    } else {
        orders = await OrdersModel.find({ receivedBy: userId }).sort({ createdAt: -1 }).populate('receivedBy')
    }


    res.json({
        success: true,
        orders,
    })

})


exports.updateOrderStatus = asyncErrors(async (req, res, next) => {

    const order = await OrdersModel.findById(req.body.orderId)
    order.status = req.body.status
    await order.save()

    const user = await UserModel.findById(req.user.id)

    const date = new Date()

    if (req.body.status === 'delivered') {

        const newNotification = {
            message: `The '${order.title}' service has been successfully delivered. Please approve it'`,
            createdAt: date,
            type: 'DeliveredService',
            senderId: {
                image: user.image,
                name: user.name,
                walletAddress: user.walletAddress,
                _id: user._id,
            },
            isSeen: false,
        }

        const notifications = await notificationModel.findOne({ user: order.bookedBy })

        if (notifications) {
            notifications.notifications.unshift({
                createdAt: date,
                type: 'DeliveredService',
                senderId: req.user.id,
                message: `The '${order.title}' service has been successfully delivered. Please approve it'`,
            })
            await notifications.save()
        }

        await pusherServer.trigger(order.bookedBy.toString(), 'notifications:new', newNotification);

    } else if (req.body.status === 'approved') {

        const user = await UserModel.findById(order.bookedBy)

        const newNotification = {
            message: `You order for service ${order.title} has been approved successfully'`,
            createdAt: date,
            type: 'Approved',
            senderId: {
                image: user.image,
                name: user.name,
                walletAddress: user.walletAddress,
                _id: user._id,
            },
            isSeen: false,
        }

        const notifications = await notificationModel.findOne({ user: order.receivedBy })

        if (notifications) {
            notifications.notifications.unshift({
                createdAt: date,
                type: 'Approved',
                senderId: req.user.id,
                message: `You order for service ${order.title} has been approved successfully'`,
            })
            await notifications.save()
        }

        await pusherServer.trigger(order.receivedBy.toString(), 'notifications:new', newNotification);

    }
    res.json({
        success: true,
        message: 'Order updated successfully',
    })

})

//admin
exports.getAllOrdersAdmin = asyncErrors(async (req, res, next) => {

    const orders = await OrdersModel.find({
        status: { $in: ['processing', 'delivered'] }
    }).sort({ createdAt: -1 }).populate('receivedBy').populate('bookedBy');

    res.json({
        success: true,
        orders,
    })

})

//admin
exports.updateAdminOrder = asyncErrors(async (req, res, next) => {

    const order = await OrdersModel.findById(req.body.orderId)
    order.status = 'Dismissed'
    await order.save()

    res.json({
        success: true,
        message: 'Order updated successfully'
    })

})