const asyncErrors = require('../middleware/asyncErrors')
const HomeSliderModel = require('../models/HomeSliderModel')


// Create
exports.createSlider = asyncErrors(async (req, res, next) => {

    await HomeSliderModel.create(req.body)

    res.json({
        success: true,
    })

})

// ALl
exports.allSlider = asyncErrors(async (req, res, next) => {

    const slider = await HomeSliderModel.find({ type: req.query.type })

    res.json({
        success: true,
        slider
    })

})

//Delete 
exports.deleteSlider = asyncErrors(async (req, res, next) => {

    const findSlider = await HomeSliderModel.findById(req.params.sliderId)

    if (findSlider) {
        await HomeSliderModel.findByIdAndDelete(req.params.sliderId)
    }

    else {
        throw new Error('Slider does not exits with this id.')
    }

    res.status(201).json({
        success: true,
        message: 'Slider has been deleted'

    })

})

//Update Slider
exports.updateSlider = asyncErrors(async (req, res, next) => {

    const findSlider = await HomeSliderModel.findById(req.params.sliderId)

    if (!findSlider) {
        throw new Error('Slider does not exit with this id.')
    }

    await HomeSliderModel.findByIdAndUpdate(req.params.sliderId, req.body, {
        new: true,
        runValidators: true,

    })

    res.status(200).json({
        success: true,
        message: 'Slider updated successfully',
    })
})