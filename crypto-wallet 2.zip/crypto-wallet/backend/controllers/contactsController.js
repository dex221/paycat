const asyncErrors = require('../middleware/asyncErrors')
const UserModel = require('../models/userModel')
const FriendListModel = require('../models/friendListModel')
const ConversationModel = require('../models/conversationModel')
const ErrorHander = require('../utils/ErrorHander')


//Add Friends
exports.addFriends = asyncErrors(async (req, res, next) => {
    const { walletAddress } = req.body;

    const userExists = await UserModel.findOne({ walletAddress });

    if (!userExists) {
        return next(new ErrorHander('User not found!', 404));
    }

    const firstUser = await UserModel.findById(req.user.id);

    if (firstUser.walletAddress === walletAddress) {
        return next(new ErrorHander('Please give another address!', 404));
    }

    const coversation = await ConversationModel.create({})

    if (firstUser.friends) {
        // If the friend list exists for the first user, update it.
        const friendList = await FriendListModel.findById(firstUser.friends);
        if (friendList) {
            // Check if the friend already exists in the friend list
            const existingFriend = friendList.friends.find((friend) =>
                friend.userId.equals(userExists._id)
            );

            if (!existingFriend) {
                friendList.friends.push({
                    userId: userExists._id,
                    conversation: coversation._id
                });
                await friendList.save();
            } else {
                return next(new ErrorHander('User already exists!', 404));
            }
        }
    } else {
        // If the friend list does not exist for the first user, create a new one.
        const friendList = await FriendListModel.create({
            user: req.user.id,
            friends: {
                userId: userExists._id,
                conversation: coversation._id
            },
        });

        firstUser.friends = friendList._id;
        await firstUser.save();
    }

    //friendlist for second user
    if (userExists.friends) {
        // If the friend list exists for the first user, update it.
        const friendList = await FriendListModel.findById(userExists.friends);
        if (friendList) {
            // Check if the friend already exists in the friend list
            const existingFriend = friendList.friends.find((friend) =>
                friend.userId.equals(req.user.id)
            );

            if (!existingFriend) {

                friendList.friends.push({
                    userId: req.user.id,
                    conversation: coversation._id,
                });

                await friendList.save();
            }
        }
    } else {
        // If the friend list does not exist for the second user, create a new one.

        const friendList = await FriendListModel.create({
            user: userExists._id,
            friends: {
                userId: req.user.id,
                conversation: coversation._id
            },
        });

        userExists.friends = friendList._id;
        await userExists.save();
    }


    res.status(200).json({
        success: true,
        user: firstUser,
    });
});

//get friend list 
exports.allFriends = asyncErrors(async (req, res, next) => {

    const friendList = await FriendListModel.findOne({ user: req.params.id }).populate('friends.userId')

    let friends = []
    if (friendList) {

        friends = friendList.friends
    }

    res.status(200).json({
        success: true,
        friends
    });

})

exports.updateIsFvrt = asyncErrors(async (req, res, next) => {

    const { updateduserId, updatedIsFavrt } = req.body;

    const friendList = await FriendListModel.findOne({ user: req.user.id }).populate('friends.userId');

    if (friendList) {
        // Update the isFavrt property for the specific friend
        friendList.friends.forEach((f) => {
            if (f.userId._id.toString() === updateduserId.toString()) {
                f.isFavrt = updatedIsFavrt;
            }
        });

        await friendList.save();

        res.status(200).json({
            success: true,
            message: 'Updated successfully',
        });
    } else {
        res.status(404).json({
            success: false,
            message: 'Friend list not found',
        });
    }
});


exports.getConversationHistory = asyncErrors(async (req, res, next) => {
    const friendList = await FriendListModel.findOne({ user: req.params.id }).populate('friends.userId');
    let sortedData

    let friends = [];
    if (friendList) {
        for (const friend of friendList.friends) {
            // Find the conversation
            const conversation = await ConversationModel.findOne({ _id: friend.conversation })
                .populate('messages.firstUser messages.secondUser')
                .exec();

            if (conversation.messages.length > 0) {
                const lastMessage = conversation.messages[conversation.messages.length - 1];

                const { firstUser, secondUser, message, document, filename, createdAt, image } = lastMessage;

                // Check if firstUser matches req.params.id
                if (firstUser._id.toString() === req.params.id) {

                    // Add the conversation data to the friends array
                    friends.push({
                        userData: secondUser,
                        message, document, filename, createdAt, image,
                        unreadCount: 0,
                        conversation: friend.conversation,
                        _id: friend._id
                    });

                }
                // Check if secondUser matches req.params.id
                else if (secondUser._id.toString() === req.params.id) {
                    // Add the conversation data to the friends array
                    friends.push({
                        message, document, filename, createdAt, image,
                        userData: firstUser,
                        unreadCount: 0,
                        conversation: friend.conversation,
                        _id: friend._id
                    });

                }
            }
        }
    }

    if (friends.length > 0) {

        // Sort the conversations 
        sortedData = [...friends.values()].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    res.status(200).json({
        success: true,
        friends: sortedData
    });
});


//create and get conversationId
exports.getConversationId = asyncErrors(async (req, res, next) => {

    const { userId } = req.params;
    const userExists = await UserModel.findById(userId);

    if (!userExists) {
        return next(new ErrorHander('User not found!', 404));
    }

    const firstUser = await UserModel.findById(req.user.id);

    let conversationExists
    let userExistsFriendList
    if (userExists.friends) {
        userExistsFriendList = await FriendListModel.findById(userExists.friends.toString());
        conversationExists = userExistsFriendList.friends.filter((item) => item.userId.toString() === req.user.id)
    }


    let conversationId

    if (conversationExists && conversationExists.length > 0) {
        conversationId = conversationExists[0].conversation
    } else {

        const coversation = await ConversationModel.create({})
        conversationId = coversation._id

        if (firstUser.friends) {
            // If the friend list exists for the first user, update it.
            const friendList = await FriendListModel.findById(firstUser.friends);
            if (friendList) {
                // Check if the friend already exists in the friend list
                const existingFriend = friendList.friends.find((friend) =>
                    friend.userId.equals(userExists._id)
                );

                if (!existingFriend) {
                    friendList.friends.push({
                        userId: userExists._id,
                        conversation: coversation._id
                    });
                    await friendList.save();
                } else {
                    return next(new ErrorHander('User already exists!', 404));
                }
            }
        } else {
            // If the friend list does not exist for the first user, create a new one.
            const friendList = await FriendListModel.create({
                user: req.user.id,
                friends: {
                    userId: userExists._id,
                    conversation: coversation._id
                },
            });

            firstUser.friends = friendList._id;
            await firstUser.save();
        }

        //friendlist for second user
        if (userExists.friends) {
            // If the friend list exists for the first user, update it.
            const friendList = userExistsFriendList;
            if (friendList) {
                // Check if the friend already exists in the friend list
                const existingFriend = friendList.friends.find((friend) =>
                    friend.userId.equals(req.user.id)
                );

                if (!existingFriend) {

                    friendList.friends.push({
                        userId: req.user.id,
                        conversation: coversation._id,
                    });

                    await friendList.save();
                }
            }
        } else {
            // If the friend list does not exist for the second user, create a new one.

            const friendList = await FriendListModel.create({
                user: userExists._id,
                friends: {
                    userId: req.user.id,
                    conversation: coversation._id
                },
            });

            userExists.friends = friendList._id;
            await userExists.save();
        }
    }




    res.status(200).json({
        success: true,
        conversationId,
    });
});

