
const asyncErrors = require('../middleware/asyncErrors')
const NotificationModel = require('../models/notificationModel')
const HistoryModel = require('../models/historyModel')
const UserModel = require('../models/userModel')
const Pusher = require('pusher');

const pusherServer = new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_APP_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: 'eu',
    useTLS: true,
});

//Get users Notifications
exports.userNotifications = asyncErrors(async (req, res, next) => {

    const notifications = await NotificationModel.findOne({ user: req.params.id }).populate('notifications.senderId')

    res.json({
        success: true,
        notifications
    })

})

//push payment notifications
exports.paymentNotifications = asyncErrors(async (req, res, next) => {

    const notifications = await NotificationModel.findOne({ user: req.user.id })

    let createdAt = new Date()

    notifications.notifications.unshift({
        createdAt: createdAt,
        type: 'approvals',
        senderId: req.body.id,
        amount: req.body.amount,
        tokenName: req.body.tokenName,
    })
    await notifications.save()

    res.json({
        success: true,
        createdAt
    })

})

//payment notifications approved
exports.paymentNotificationsUpdate = asyncErrors(async (req, res, next) => {

    const { senderId, createdAt, amount, tokenName } = req.body

    const notifications = await NotificationModel.findOne({ user: req.user.id }).populate('notifications.senderId')

    const updatedNotifications = notifications.notifications.map(notification => {
        if (notification.senderId.walletAddress === senderId && new Date(notification.createdAt).getTime() === new Date(createdAt).getTime()) {
            return {
                ...notification,
                type: 'approved'
            };
        } else {
            return notification;
        }
    });

    notifications.notifications = updatedNotifications
    await notifications.save()

    const senderUser = await UserModel.findById(req.user.id)

    const newNotification = {
        message: `You have received ${amount} ${tokenName} from `,
        createdAt: Date.now(),
        type: 'received',
        senderId: {
            image: senderUser.image,
            name: senderUser.name,
            walletAddress: senderUser.walletAddress,
            _id: senderUser._id,
        },
        isSeen: false,
    }

    const receiptUser = await UserModel.findOne({ walletAddress: senderId })
    const receiptNotifications = await NotificationModel.findOne({ user: receiptUser._id })

    if (receiptNotifications) {
        receiptNotifications.notifications.unshift({
            message: `You have received ${amount} ${tokenName} from `,
            createdAt: Date.now(),
            type: 'received',
            senderId: req.user.id,
        })
        await receiptNotifications.save()
    }

    await pusherServer.trigger(receiptUser._id.toString() , 'notifications:new', newNotification);

    await HistoryModel.create({
        user: req.user.id,
        amount,
        receiptAddress: senderId,
        tokenName
    })

    res.json({
        success: true,
    })

})

//Update Notifications seen
exports.notificationSeen = asyncErrors(async (req, res, next) => {

    const notifications = await NotificationModel.findOne({ user: req.params.id })

    if (notifications.notifications.length) {

        const updatedNotifications = notifications.notifications.map(notification => ({
            ...notification,
            isSeen: true,
        }));

        notifications.notifications = updatedNotifications
        await notifications.save()

    }

    res.json({
        success: true,
        message: 'Notifications Seen updated'
    })

})

//Update Notifications type read
exports.notificationTypeReadUpdate = asyncErrors(async (req, res, next) => {

    const notifications = await NotificationModel.findOne({ user: req.user.id })

    if (notifications.notifications.length) {

        const updatedNotifications = notifications.notifications.map(notification => {
            if (notification.senderId.toString() === req.params.userId && notification.type === 'Unread') {
                return {
                    ...notification,
                    type: 'read'
                };
            } else {
                return notification;
            }
        });

        notifications.notifications = updatedNotifications
        await notifications.save()

    }

    res.json({
        success: true,
        message: 'Notifications Type read updated'
    })

})

exports.deleteNotification = asyncErrors(async (req, res, next) => {

    const notifications = await NotificationModel.findOne({ user: req.user.id })

    const updated = notifications.notifications.filter(value =>
        new Date(value.createdAt).getTime() !== new Date(req.body.createdAt).getTime()
    );

    notifications.notifications = updated

    await notifications.save()


    res.json({
        success: true,
    })

})