const asyncErrors = require('../middleware/asyncErrors')
const ReviewModel = require('../models/ReviewModel')
const serviceModel = require('../models/serviceModel')
const UserModel = require('../models/userModel')
const OrdersModel = require('../models/ordersModel')
const ApiFeatures = require('../utils/ApiFeatures')

exports.createReview = asyncErrors(async (req, res, next) => {

    const { ratedTo, serviceId } = req.body

    await ReviewModel.create({
        ...req.body,
        ratedBy: req.user.id,
        service: serviceId
    })

    //update user ratings

    const ratedToUser = await UserModel.findById(ratedTo)
    const UserTotalReviews = ratedToUser.totalReviews + 1
    ratedToUser.totalReviews = UserTotalReviews

    const ratedToUserReviews = await ReviewModel.find({ ratedTo })

    let avg = 0;

    ratedToUserReviews.forEach((rev) => {
        avg += rev.rating;
    });

    ratedToUser.ratings = avg / UserTotalReviews;
    await ratedToUser.save()

    //update Service Ratings

    const ratedService = await serviceModel.findById(serviceId)
    const ratedServiceTotalReviews = ratedService.totalReviews + 1
    ratedService.totalReviews = ratedServiceTotalReviews

    const ratedServiceReviews = await ReviewModel.find({ service: serviceId })

    let ratedAvg = 0;

    ratedServiceReviews.forEach((rev) => {
        ratedAvg += rev.rating;
    });

    ratedService.ratings = ratedAvg / ratedServiceTotalReviews;
    await ratedService.save()

    res.json({
        success: true
    })

})

exports.ReviewsByService = asyncErrors(async (req, res, next) => {

    let resultPerPage = 6
    const totalReviewsCount = await ReviewModel.countDocuments({ service: req.query.serviceId })

    const apiFeatures = new ApiFeatures(ReviewModel.find({ service: req.query.serviceId }).populate('ratedBy').sort({ createdAt: -1 }), req.query)

    let reviews = await apiFeatures.query;
    let filteredReviewsCount = reviews.length
    apiFeatures.pagination(resultPerPage)

    reviews = await apiFeatures.query.clone();
    const totalPages = Math.ceil(totalReviewsCount / resultPerPage);

    res.json({
        success: true,
        reviews,
        filteredReviewsCount,
        totalReviewsCount,
        resultPerPage,
        totalPages
    })

})

exports.reviewCheck = asyncErrors(async (req, res, next) => {

    const { bookedBy, serviceId } = req.query

    const order = await OrdersModel.countDocuments({ bookedBy, serviceId, status: 'approved' })

    const totalReviewsCount = await ReviewModel.countDocuments({ service: serviceId, ratedBy: bookedBy })

    let canReview = false

    if (totalReviewsCount < order) {
        canReview = true
    }

    res.json({
        success: true,
        canReview
    })

})

exports.ReviewsByUser = asyncErrors(async (req, res, next) => {

    let resultPerPage = 15

    const apiFeatures = new ApiFeatures(ReviewModel.find({ ratedTo : req.query.userId }).populate('ratedBy').sort({ createdAt: -1 }), req.query)

    let reviews = await apiFeatures.query;
    apiFeatures.pagination(resultPerPage)

    reviews = await apiFeatures.query.clone();

    res.json({
        success: true,
        reviews,

    })

})