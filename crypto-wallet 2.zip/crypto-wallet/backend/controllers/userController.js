const ethers = require('ethers')
const jwt = require('jsonwebtoken')
const asyncErrors = require('../middleware/asyncErrors')
const UserModel = require('../models/userModel')
const NotificationModel = require('../models/notificationModel')


//Generate Nonuce
exports.generateNonce = asyncErrors(async (req, res, next) => {

    const message = `Sign this message to prove you have access to this wallet in order to sign in to ${process.env.APP_URL}.\n\nThis won't cost you any Ether.\n\nTimestamp:${new Date().getTime()}`

    res.json({
        success: true,
        nonce: message
    })

})

//Creating or logging in a User
exports.loginUser = asyncErrors(async (req, res, next) => {

    const { address } = req.body;

    let user

    const findUser = await UserModel.findOne({ walletAddress: address })
    if (findUser) {
        user = findUser
        if (!user.notifications) {
            const notifications = await NotificationModel.create({
                user: user._id
            })
            user.notifications = notifications._id
            await user.save()
        }
    } else {

        user = await UserModel.create({
            walletAddress: address,
            image: 'https://res.cloudinary.com/doytf8ce3/image/upload/v1693086923/dummy_fxiudh.jpg',
            name: 'PAYCAT User'
        })

        const notifications = await NotificationModel.create({
            user: user._id
        })
        user.notifications = notifications._id
        await user.save()
    }

    // Generate the JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });

    res.json({
        success: true,
        token,
        user
    })

})


// get user Details
exports.userDetails = asyncErrors(async (req, res, next) => {

    const user = await UserModel.findById(req.user.id)


    res.json({
        success: true,
        user,

    })

})

//Update User
exports.updateUser = asyncErrors(async (req, res, next) => {

    const newUserData = {
        name: req.body.name,
        image: req.body.image,
    }


    const user = await UserModel.findByIdAndUpdate(req.user.id, newUserData, {
        new: true,
        runValidators: true,

    })

    res.status(200).json({
        success: true,
        user
    })
})


//users length
exports.usersLength = asyncErrors(async (req, res, next) => {

    const users = await UserModel.countDocuments()

    res.status(200).json({
        success: true,
        TotalUsers: users
    })
})

//users detail
exports.userDetail = asyncErrors(async (req, res, next) => {

    const user = await UserModel.findById(req.params.id)

    res.status(200).json({
        success: true,
        user
    })
})






