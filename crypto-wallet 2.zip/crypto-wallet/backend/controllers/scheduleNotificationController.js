const asyncErrors = require('../middleware/asyncErrors')
const NotificationModel = require('../models/notificationModel')
const ScheduleNotificationModel = require('../models/scheduleNotificationModel')
const Pusher = require('pusher');
const userModel = require('../models/userModel');

const pusherServer = new Pusher({
    appId: process.env.PUSHER_APP_ID,
    key: process.env.PUSHER_APP_KEY,
    secret: process.env.PUSHER_SECRET,
    cluster: 'eu',
    useTLS: true,
});

//add
exports.addScheduleNotification = asyncErrors(async (req, res, next) => {

    const { senderId, amount, DeadlinesNo, sheduleDate, tokenName } = req.body

    const userNotifications = await NotificationModel.findOne({ user: req.user.id })

    let createdAt = new Date()

    if (userNotifications) {
        userNotifications.notifications.unshift({
            message: `You have scheduled ${amount} ${tokenName} to Mr`,
            createdAt: createdAt,
            type: 'scheduled',
            senderId: senderId,
            tokenName: tokenName,
            scheduledAt: sheduleDate,
        })

        await userNotifications.save()
    }

    const receiverNotification = await NotificationModel.findOne({ user: senderId })

    let receiverCreatedAt = new Date()

    if (receiverNotification) {
        receiverNotification.notifications.unshift({
            message: `has scheduled an payment of ${amount} ${tokenName} to you`,
            createdAt: receiverCreatedAt,
            type: 'scheduledreceiver',
            senderId: req.user.id,
            tokenName: tokenName,
            scheduledAt: sheduleDate,
        })

        await receiverNotification.save()
    }

    const secondUser = await userModel.findById(req.user.id)

    const newNotification = {
        message: `has scheduled an payment of ${amount} ${tokenName} to you`,
        createdAt: receiverCreatedAt,
        type: 'scheduledreceiver',
        senderId: {
            image: secondUser.image,
            name: secondUser.name,
            walletAddress: secondUser.walletAddress,
            _id: secondUser._id,
        },
        isSeen: false,
        scheduledAt: sheduleDate,

    }

    await pusherServer.trigger(senderId, 'notifications:new', newNotification);


    await ScheduleNotificationModel.create({
        user: req.user.id,
        senderId,
        amount,
        DeadlinesNo,
        sheduleDate,
        tokenName
    })

    res.json({
        success: true,
        createdAt
    })

})

setInterval(async () => {

    const scheduleNotification = await ScheduleNotificationModel.find()

    if (scheduleNotification.length) {

        scheduleNotification.map(async (item) => {

            let currentTime = new Date().getTime()
            let presentTime = new Date(item.sheduleDate).getTime()

            if (currentTime > presentTime) {

                const userNotifications = await NotificationModel.findOne({ user: item.user })

                if (userNotifications) {

                    let createdAt = new Date()

                    const secondUser = await userModel.findById(item.senderId)

                    userNotifications.notifications.unshift({
                        createdAt: createdAt,
                        type: 'approvals',
                        senderId: item.senderId,
                        amount: item.amount,
                        tokenName: item.tokenName,
                        DeadlinesNo: item.DeadlinesNo
                    })


                    await userNotifications.save()

                    const newNotification = {
                        createdAt: createdAt,
                        type: 'approvals',
                        amount: item.amount,
                        tokenName: item.tokenName,
                        DeadlinesNo: item.DeadlinesNo,
                        senderId: {
                            image: secondUser.image,
                            name: secondUser.name,
                            walletAddress: secondUser.walletAddress,
                            _id: secondUser._id,
                        },
                        isSeen: false,

                    }

                    await pusherServer.trigger(item.user.toString(), 'notifications:new', newNotification);
                    await ScheduleNotificationModel.findByIdAndDelete(item._id)

                }

            }
        })
    }

}, 60000);
