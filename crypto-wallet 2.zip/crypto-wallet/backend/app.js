const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');

const errorMiddleware = require('./middleware/error');

// Configs
if (process.env.NODE_ENV !== 'PRODUCTION') {
  require('dotenv').config({ path: './config.env' });
}
// Middleware to parse JSON data

app.use(express.json());
app.use(express.urlencoded({ extended: false }));


app.use(cors({
  credentials: true,
  origin: [process.env.APP_URL, 'https://crypto-wallett.netlify.app' , 'http://127.0.0.1:5173' ,'https://www.paycat.app']
}));

// Import routes
const user = require('./routes/userRoute');
const contact = require('./routes/contactRoute');
const conversation = require('./routes/conversationRoute');
const notifications = require('./routes/notificationRoute');
const service = require('./routes/serviceRoute');
const order = require('./routes/ordersRoute');
const review = require('./routes/reviewRoute');
const slider = require('./routes/homeSliderRoute');

app.use('/api', user);
app.use('/api', contact);
app.use('/api', conversation);
app.use('/api', notifications);
app.use('/api', service);
app.use('/api', order);
app.use('/api', review);
app.use('/api', slider);

// Middleware for errors
app.use(errorMiddleware);

module.exports = app;

// /latest
