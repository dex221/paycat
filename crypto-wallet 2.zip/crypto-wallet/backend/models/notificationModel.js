const mongoose = require('mongoose');

const NotificationModel = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    notifications: [
        {
            message: {
                type: String,
            },
            conversationId: {
                type: String,
            },
            DeadlinesNo: {
                type: Number,
            },
            tokenName: {
                type: String
            },
            senderId: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
            },
            createdAt: {
                type: Date
            },
            scheduledAt: {
                type: Date
            },
            isSeen: {
                type: Boolean,
                default: false
            },
            type: {
                type: String
            },
            amount: {
                type: Number
            },
        },
    ],
});


module.exports = mongoose.model('Notification', NotificationModel);
