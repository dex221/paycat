const mongoose = require('mongoose');

const HomeSlider = new mongoose.Schema({

    type: {
        type: String
    },

    imgUrl: {
        type: String
    }

});


module.exports = mongoose.model('HomeSlider', HomeSlider);
