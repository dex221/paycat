const mongoose = require('mongoose');

const RecentModelSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    members: [
        {
            member: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
            },
            conversationId: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Conversation',
            },
        },
    ],
});

// Custom method to handle updating members array
RecentModelSchema.methods.updateMembersArray = async function (memberData) {
    const existingIndex = this.members.findIndex(
        (member) => member.member.equals(memberData.member)
    );

    if (existingIndex >= 0) {
        // If the member already exists in the array, remove it from the current position
        this.members.splice(existingIndex, 1);
    }

    // Add the member to the beginning of the array
    this.members.unshift(memberData);

    // Slice the array to keep only the first 5 elements
    this.members = this.members.slice(0, 5);

    // Save the updated document
    await this.save();
};


module.exports = mongoose.model('RecentModel', RecentModelSchema);
