const mongoose = require('mongoose')

const ReviewModel = new mongoose.Schema({

    ratedTo: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true
    },
    ratedBy: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true
    },
    service: {
        type: mongoose.Schema.ObjectId,
        ref: 'serviceModel',
        required: true
    },
    rating: {
        type: Number,
        required: true
    },
    comment: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }

})


module.exports = mongoose.model('ReviewModel', ReviewModel)