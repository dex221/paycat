const mongoose = require('mongoose')


const userSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    image: {
        type: String
    },
    walletAddress: {
        type: String
    },
    friends: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'FriendList'
    },
    notifications: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Notification'
    },
    totalReviews: {
        type: Number,
        default: 0
    },
    ratings: {
        type: Number,
        default: 0
    },
    isAdmin: {
        type: Boolean,
        default : false
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
})


module.exports = mongoose.model('User', userSchema)