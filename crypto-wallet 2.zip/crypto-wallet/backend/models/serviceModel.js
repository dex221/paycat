const mongoose = require('mongoose')

const serviceModel = new mongoose.Schema({

    title: {
        type: String
    },
    category: {
        type: [String]
    },
    paymentCoin: {
        type: [String]
    },
    price: {
        type: Number
    },
    country: {
        type: String
    },
    desc: {
        type: String
    },
    totalReviews: {
        type: Number,
        default: 0
    },
    ratings: {
        type: Number,
        default: 0
    },
    images: {
        type: [String]
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    views: {
        type: Number,
        default: 0
    },
    likes: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
    ],
    createdAt: {
        type: Date,
        default: Date.now
    }

})


module.exports = mongoose.model('serviceModel', serviceModel)