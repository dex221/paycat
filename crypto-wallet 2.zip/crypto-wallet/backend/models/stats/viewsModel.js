const mongoose = require('mongoose')

const viewsSchema = new mongoose.Schema({
    User: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    service: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'serviceModel',
        required: true
    }
})


module.exports = mongoose.model('viewsSchema', viewsSchema)