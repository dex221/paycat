const mongoose = require('mongoose');

const ScheduleNotificationModel = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    DeadlinesNo: {
        type: Number,
    },
    senderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    tokenName: {
        type: String
    },
    sheduleDate: {
        type: Date
    },
    amount: {
        type: Number
    },
});


module.exports = mongoose.model('ScheduleNotificationModel', ScheduleNotificationModel);
