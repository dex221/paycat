const mongoose = require('mongoose');

const OrdersModel = new mongoose.Schema({
    bookedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    receivedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'serviceModel',
    },
    payment: {
        type: Number
    },
    email: {
        type: String
    },
    title: {
        type: String
    },
    number: {
        type: String
    },
    address: {
        type: String
    },
    orderId: {
        type: Number
    },
    country: {
        type: String
    },
    paymentCoin: {
        type: String
    },
    status: {
        type: String,
        default: 'processing'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }

});


module.exports = mongoose.model('OrdersModel', OrdersModel);
