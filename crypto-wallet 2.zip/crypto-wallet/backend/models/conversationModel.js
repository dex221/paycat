const mongoose = require('mongoose')

const conversationSchema = new mongoose.Schema({
    messages: [
        {
            firstUser: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
                required: true
            },
            secondUser: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
                required: true
            },
            message: {
                type: String
            },
            document: {
                type: String
            },
            filename: {
                type: String
            },
            image: {
                type: String
            },
            isSeen: {
                type: Boolean,
                default: false
            },
            createdAt: {
                type: Date,
            }
        }
    ]
}, { timestamps: true })


module.exports = mongoose.model('Conversation', conversationSchema)