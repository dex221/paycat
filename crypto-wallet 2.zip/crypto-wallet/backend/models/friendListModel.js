const mongoose = require('mongoose');

const friendListModel = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    friends: [
        {
            isFavrt: {
                type: Boolean,
                default: false,
            },
            userId: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'User',
            },
            conversation: {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'Conversation',
            },
        },
    ],
});


module.exports = mongoose.model('FriendList', friendListModel);
