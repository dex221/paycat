const express = require('express');
const router = express.Router();

const { isAuthenticatedUser, verifyUser } = require('../middleware/auth');
const { allConversations, sendMessage, activeUsers, recentDeals } = require('../controllers/conversationController');
const { getConversationId } = require('../controllers/contactsController');


router.route('/conversation/:id').get(isAuthenticatedUser, allConversations)

router.route('/send/message/:conversationId/:userId').post(verifyUser, sendMessage)

router.route('/pusher/auth').post(isAuthenticatedUser, activeUsers)

router.route('/recent-deals/:id').get(isAuthenticatedUser, recentDeals)

router.route('/conversation/retrive/:userId').post(isAuthenticatedUser, getConversationId)


module.exports = router