const express = require('express');
const router = express.Router();

const { verifyUser } = require('../middleware/auth');
const { userNotifications, notificationSeen, notificationTypeReadUpdate, paymentNotifications, paymentNotificationsUpdate, deleteNotification } = require('../controllers/notificationController');
const { userHistory, monthlyHistory, allHistory } = require('../controllers/historyController');
const { addScheduleNotification } = require('../controllers/scheduleNotificationController');



router.route('/notifications/:id').get(verifyUser, userNotifications)

router.route('/notifications/seen/:id').get(verifyUser, notificationSeen)

router.route('/notifications/type/read/:userId').get(verifyUser, notificationTypeReadUpdate)

router.route('/notifications/payments').post(verifyUser, paymentNotifications)

router.route('/notifications/payments/update').post(verifyUser, paymentNotificationsUpdate)

router.route('/notification/delete').delete(verifyUser, deleteNotification)

//history
router.route('/history/:id').get(userHistory)

router.route('/history/monthly/:id').get(monthlyHistory)

router.route('/history').get(allHistory)

//schedule Notification
router.route('/notifications/schedule').post(verifyUser, addScheduleNotification)



module.exports = router