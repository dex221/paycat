const express = require('express');
const router = express.Router();

const { verifyUser, isAuthenticatedUser } = require('../middleware/auth');
const { createReview, ReviewsByService, reviewCheck, ReviewsByUser } = require('../controllers/reviewController');

router.route('/review/create').post(verifyUser, createReview)

router.route('/reviews').get(ReviewsByService)

router.route('/review/check').get(isAuthenticatedUser, reviewCheck)

router.route('/review').get(ReviewsByUser)


module.exports = router