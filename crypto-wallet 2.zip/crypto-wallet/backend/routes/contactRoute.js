const express = require('express');
const router = express.Router();

const {  verifyUser } = require('../middleware/auth');
const { addFriends, allFriends, updateIsFvrt, getConversationHistory } = require('../controllers/contactsController');



router.route('/contact/add').post(verifyUser , addFriends)

router.route('/friends/:id').get(verifyUser , allFriends)

router.route('/conversation-history/:id').get(getConversationHistory)

router.route('/friends/fvrt').post(verifyUser , updateIsFvrt)




module.exports = router