const express = require('express');
const router = express.Router();

const { verifyUser, isAuthenticatedUser, authorizeUser } = require('../middleware/auth');
const { createService, getAllService, getTokensPrice, getAllServiceOfUser, deleteService, updateService, getSimilarServices, getSimilarCategoryServices, adminDeleteService, createLike, createViews } = require('../controllers/serviceController');


router.route('/service/create').post(isAuthenticatedUser, createService)

router.route('/services').get(getAllService)

router.route('/tokens/price').get(getTokensPrice)

router.route('/service/:userId').get(getAllServiceOfUser)

router.route('/similar-services').get(getSimilarServices)

router.route('/similar-services/category').get(getSimilarCategoryServices)

router.route('/service/:serviceId').delete(verifyUser, deleteService).put(verifyUser, updateService)

router.route('/like').put(verifyUser, createLike)

router.route('/view').put(verifyUser, createViews)

//admin
router.route('/service/:serviceId').delete(authorizeUser(true), adminDeleteService)

module.exports = router