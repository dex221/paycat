const express = require('express');
const router = express.Router();

const { authorizeUser } = require('../middleware/auth');
const { createSlider, allSlider, deleteSlider, updateSlider } = require('../controllers/HomeSliderController');


router.route('/slider/create').post(authorizeUser(true), createSlider)

router.route('/sliders').get(allSlider)

router.route('/slider/:sliderId').delete(authorizeUser(true), deleteSlider).put(authorizeUser(true), updateSlider)



module.exports = router