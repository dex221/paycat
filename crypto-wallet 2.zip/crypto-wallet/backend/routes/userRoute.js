const express = require('express');
const router = express.Router();

const { loginUser, generateNonce, userDetails, updateUser, usersLength, userDetail } = require('../controllers/userController');
const { isAuthenticatedUser, verifyUser } = require('../middleware/auth');

router.route('/nonce').get(generateNonce)

router.route('/login').post(loginUser)

router.route('/me').get(verifyUser , userDetails)

router.route('/user/update').post(verifyUser , updateUser)

router.route('/users/length').get(usersLength)

router.route('/user/:id').get(userDetail)


module.exports = router