const express = require('express');
const router = express.Router();

const {  verifyUser, isAuthenticatedUser, authorizeUser } = require('../middleware/auth');
const { createOrders, getAllOrders, updateOrderStatus, getAllOrdersAdmin, updateAdminOrder } = require('../controllers/orderController');

router.route('/orders/create').post(isAuthenticatedUser , createOrders)

router.route('/orders').get(getAllOrders)

router.route('/order/status').put(verifyUser , updateOrderStatus)

router.route('/admin/orders').get(getAllOrdersAdmin).put(authorizeUser(true), updateAdminOrder)

module.exports = router